# 0.2.1: singleplayer recipe-sync crash workaround

Replace the old Living World JAR with `livingworld-26.2-0.2.1-alpha.1.jar`.
Keep MineColonies 0.0.67 and Fabric API unchanged. Only one Living World JAR
should be in the instance's mods folder. The commands and terrain features are
unchanged; follow TEST-0.2.md using this newer JAR.

The supplied crash report showed ConcurrentModificationException in
CustomRecipeManager.resolveTemplates. Bytecode inspection of the exact 0.0.67
JAR confirmed that recipeTemplates belongs to a static singleton, and that the
client's handleCustomRecipeManagerMessage calls reset(), clearing that same map.
The log shows client synchronization and server discovery happening concurrently.

This add-on now applies a client-only Mixin that skips the redundant recipe snapshot
when Minecraft has an integrated server. Singleplayer already shares the server's
manager, so it must not reset that manager with its own network snapshot. Remote
multiplayer clients continue processing recipe packets normally. Dedicated servers
do not load the client Mixin. The original MineColonies JAR is not modified.

The fix is pinned to MineColonies 0.0.67. Compilation and model tests passed;
singleplayer launch and the Mixin's actual in-game application still need retesting.
This addresses the reported reset race, not every potential shared-state issue in
the unofficial port.

Retest: open the same test world, wait 30 seconds, then run `/livingworld list`.
If it opens, continue the survey/build test. The latest.log should include:
"Skipped redundant integrated-server recipe sync; preserving server recipe templates".
If it crashes again, send the new crash report and logs/latest.log.

$ErrorActionPreference = 'Stop'
Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/unknown-wq/minecolonies/125066db1e59ece15247b1eb6c00e7d8e5ddfb4f/dist/minecolonies-26.2-0.0.67.jar' -OutFile (Join-Path $PSScriptRoot 'minecolonies.jar')
Add-Type -AssemblyName System.IO.Compression.FileSystem
$depsPath = Join-Path $PSScriptRoot 'deps'
New-Item -ItemType Directory -Force -Path $depsPath | Out-Null
$archive = [System.IO.Compression.ZipFile]::OpenRead((Join-Path $PSScriptRoot 'minecolonies.jar'))
try {
    foreach ($entry in $archive.Entries) {
        if ($entry.FullName.StartsWith('META-INF/jars/') -and $entry.Name.EndsWith('.jar')) {
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, (Join-Path $depsPath $entry.Name), $true)
        }
    }
} finally { $archive.Dispose() }

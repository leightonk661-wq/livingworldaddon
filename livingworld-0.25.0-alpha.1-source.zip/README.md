# Living World 0.25.0 alpha 1

Requires Fabric 26.2, Fabric API, unofficial MineColonies 0.0.67 and Humanoid Villagers 1.0.3.1. Replace the previous Living World JAR with this one. Use a fresh world for this playtest.

## Town life
- Found your camp normally. Once citizens join, open the Town Ledger and select People.
- Each native citizen has a persistent name, role, personality and observed memories. Nearby meetings on different days develop acquaintances into friends; empty-hand sneak-right-click a citizen to introduce yourself. They remember previous conversations after saving and reloading.
- Healthy, idle adults use morning and afternoon gathering spots and daytime walks near camp, warehouse or home. Native employment, food, sleep and combat take precedence. The steward remains at their post. These are a first layer of routines, not full Skyrim dialogue or household simulation.
- Extra navigation runs only near players and in already loaded terrain. It never generates terrain or adds chunk tickets. Residents outside loaded chunks do not physically walk or simulate conversations.

## Town correspondence
1. Visit two established towns with stewards. Open People to see them. Geographic regions use stable 2048-block cells.
2. Empty-hand sneak-right-click a steward to request a sealed letter. Only previously known towns qualify; destinations in another region are preferred when available.
3. Read the letter to open its journal page and HUD checklist/trail. Drop the correct book beside the destination steward while standing nearby.
4. Carry the signed reply home and drop it beside the source steward. Speak to that steward normally to collect the reserved emerald reward.
5. Complete exchanges build town-to-town trust and player reputation. One active dispatch per player; a one-day cooldown follows completion. Lost books can be reissued by either participating steward. Copies cannot repeat hand-ins or rewards.

Rewards are reserved from the issuing treasury, capped at two emeralds. An empty treasury can offer an unpaid exchange. Existing material requests still use physical supply hand-ins. Correspondence is the first inter-town quest chain; trade caravans, branching disputes and household needs are future work.

## Playtest
- Check native builders keep working while idle adults gather. Check food, sleep and combat still override extra walking.
- Speak to a resident, save/reload and speak again. Watch People across several days for real observed acquaintances.
- Complete both legs of a dispatch, reload between legs, try an old copied letter, and verify the reward pays once.
- Visit a third town in a different region and check destination preference. Stay within previously visited terrain for background work.

Validation: 31 local rules/API test suites. Live navigation, interaction and rendering require the in-game playtest above; no claim of an automated client playthrough.

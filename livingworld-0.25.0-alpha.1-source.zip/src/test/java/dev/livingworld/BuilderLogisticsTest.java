package dev.livingworld;
import org.objectweb.asm.*;
public final class BuilderLogisticsTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    static boolean member(String type,String name,String descriptor,boolean field)throws Exception{
        boolean[] found={false};try(var in=BuilderLogisticsTest.class.getResourceAsStream("/"+type+".class")){
            new ClassReader(in).accept(new ClassVisitor(Opcodes.ASM9){
                @Override public FieldVisitor visitField(int access,String n,String d,String sig,Object value){if(field && n.equals(name) && d.equals(descriptor))found[0]=true;return null;}
                @Override public MethodVisitor visitMethod(int access,String n,String d,String sig,String[] exceptions){if(!field && n.equals(name) && d.equals(descriptor))found[0]=true;return null;}
            },ClassReader.SKIP_CODE|ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        }return found[0];
    }
    public static void main(String[] args)throws Exception{
        check(BuilderLogistics.mayResume(true,true,false),"Managed builders continue after receiving a request without an automatic dump trip");
        check(!BuilderLogistics.mayResume(false,true,false),"Other MineColonies builders retain native behaviour");
        check(!BuilderLogistics.mayResume(true,false,false),"No-work-order trips are retained");
        check(!BuilderLogistics.mayResume(true,true,true),"Actually full inventories retain native unloading");
        check(BuilderLogistics.portableTarget(300,64)==64 && BuilderLogistics.portableTarget(3,64)==3,"Portable batches capped to a stack and actual remaining need");
        check(BuilderLogistics.portableTarget(20,1)==1 && BuilderLogistics.portableTarget(0,64)==0,"Nonstackables and exhausted requirements stay bounded");
        check(BuilderLogistics.prefetchAmount(300,12,64,10)==52,"Top-ups subtract materials already carried");
        check(BuilderLogistics.prefetchAmount(20,32,64,10)==0,"Never prefetch an already fulfilled material");
        check(BuilderLogistics.prefetchAmount(300,0,64,6)==0,"Reserve six empty slots for drops and tools");
        check(BuilderLogistics.prefetchAmount(300,12,64,6)==52,"Existing stacks can still be topped up without occupying reserved slots");
        check(BuilderLogistics.prefetchAmount(300,0,64,7)==64,"A material can use one non-reserved slot");
        String root="com/minecolonies/core/entity/ai/workers/";
        String state="()Lcom/minecolonies/api/entity/ai/statemachine/states/IAIState;";
        check(member(root+"builder/EntityAIStructureBuilder","afterRequestPickUp",state,false),"Exact native pickup hook exists");
        check(member(root+"AbstractEntityAIStructure","pickUpMaterial",state,false),"Exact native material hook exists");
        check(member(root+"AbstractEntityAIStructure","pickUpCount","I",true),"Pickup cursor shadow matches the shipped MineColonies JAR");
        System.out.println("PASS: linked-storage portable batches, reserved slots, genuine-full-inventory protection, scoped resume policy and exact native mixin targets.");
    }
}

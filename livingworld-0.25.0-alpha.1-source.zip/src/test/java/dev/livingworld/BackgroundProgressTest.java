package dev.livingworld;
import java.util.*;
import net.minecraft.world.level.ChunkPos;
import com.google.gson.Gson;
public final class BackgroundProgressTest {
    private static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    private static SitePlan site(String kind){var p=new SitePlan();p.kind=kind;p.pack="Medieval Oak";p.path=kind+".blueprint";p.x=8;p.y=70;p.z=8;p.minY=69;p.width=24;p.height=12;p.depth=24;return p;}
    public static void main(String[] args){
        var s=new Settlement("FirstTown","minecraft:overworld",0,70,0);s.expedition=true;s.autoDevelop=true;s.governorEnabled=true;s.colonyId=1;s.colonyOwner="12345678-1234-1234-1234-123456789abc";s.economyPopulation=1;s.recruitId="99999999-1234-1234-1234-123456789abc";
        check(!BackgroundProgress.eligible(s),"Recording founding does not unlock early departure");
        s.camp=site("camp");s.camp.complete=true;s.founderSpawned=true;
        check(!BackgroundProgress.eligible(s),"A separate spawned citizen does not bypass the escort handoff");s.journeyComplete=true;
        check(BackgroundProgress.eligible(s) && BackgroundProgress.startersPending(s) && BackgroundProgress.nextStarter(s).equals("builder"),"Joined camp starts background work before either hut exists");
        check(!DistantProgress.established(s),"Later paid projects still require real completed starter huts");
        s.starterSites.add(site("builder"));check(BackgroundProgress.eligible(s) && BackgroundProgress.nextStarter(s).equals("townhall"),"A reserved builder hut can continue unattended");
        s.starterSites.getFirst().complete=true;s.starterSites.add(site("townhall"));s.colonyReady=true;
        check(BackgroundProgress.eligible(s) && !DistantProgress.established(s),"Town hall construction stays in the starter phase");
        s.starterSites.getLast().complete=true;check(!BackgroundProgress.startersPending(s) && DistantProgress.established(s) && BackgroundProgress.eligible(s),"Completed huts hand off to the existing distant planner");
        s.governorEnabled=false;check(!BackgroundProgress.eligible(s),"Player pause stops background construction");s.governorEnabled=true;
        s.distantEnabled=false;check(!BackgroundProgress.eligible(s),"Town distant toggle disables its tickets");s.distantEnabled=true;
        s.economyPopulation=0;check(!BackgroundProgress.eligible(s),"No workers means no new background ticket session");s.economyPopulation=1;
        s.dimension="minecraft:the_nether";check(!BackgroundProgress.eligible(s),"Background work remains Overworld-only");s.dimension="minecraft:overworld";
        var restored=new Gson().fromJson(new Gson().toJson(s),Settlement.class);restored.validate();check(BackgroundProgress.eligible(restored),"Background starter eligibility survives saving");
        var p=site("builder");var area=ChunkWorkPlan.siteArea(-32,0,p,48);check(!area.isEmpty() && area.size()<=48,"Exact footprint and camp corridor fit the bounded budget");
        for(int x=(p.minX-16)>>4;x<=(p.minX+p.width+16)>>4;x++)for(int z=(p.minZ-16)>>4;z<=(p.minZ+p.depth+16)>>4;z++)check(area.contains(new ChunkPos(x,z)),"All placement safety-border chunks included");
        check(ChunkWorkPlan.siteArea(-32,0,p,4).isEmpty(),"Oversized work areas refused as a whole");
        var progress=new PlayerJourney();progress.milestones.add("founded");progress.visited.add(s.name);s.founder="owner";
        check(JournalData.project(progress,List.of(s),null,"owner").status.startsWith("Your camp can carry on"),"Founder gets accurate departure guidance");
        check(!JournalData.project(progress,List.of(s),null,"visitor").status.startsWith("Your camp can carry on"),"Other visitors do not see someone else's founding progress");
        System.out.println("PASS: departure after camp handoff, unattended starter gates, pause and dimension checks, exact bounded work areas and transition to distant projects.");
    }
}

package dev.livingworld;
import net.minecraft.world.level.ChunkPos;
public final class ChunkWorkPlanTest {
    private static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args){
        var near=ChunkWorkPlan.route(0,0,48,0,1,64);
        check(near.contains(new ChunkPos(0,0)) && near.contains(new ChunkPos(3,0)),"work corridor includes hut and site");
        check(near.size()<=64,"near route within cap");
        check(ChunkWorkPlan.route(0,0,512,0,2,64).isEmpty(),"long route is refused rather than partly ticketed");
        check(ChunkWorkPlan.route(0,0,0,0,3,64).isEmpty(),"unbounded margin refused");
        check(!ChunkWorkPlan.covered(near,java.util.List.of(new ChunkPos(0,0)),2),"near town does not cover distant worksite");
        check(ChunkWorkPlan.covered(near,java.util.List.of(new ChunkPos(1,0)),5),"player simulation covers full corridor");
        check(!ChunkWorkPlan.covered(near,java.util.List.of(),5),"no player never covers worksite");
        var dynamic=ChunkWorkPlan.workArea(0,0,80,0,true,64);
        check(dynamic.contains(new ChunkPos(0,0)) && dynamic.contains(new ChunkPos(5,0)) && dynamic.contains(new ChunkPos(7,2)),"dynamic area includes builder, route and worksite buffer");
        check(dynamic.size()<=48 && ChunkWorkPlan.workArea(0,0,800,0,true,48).isEmpty(),"two-town work areas fit separate 48-chunk budgets");
        var first=ChunkWorkPlan.rotationOrder(5,0);var second=ChunkWorkPlan.rotationOrder(5,2);var third=ChunkWorkPlan.rotationOrder(5,4);
        check(first.subList(0,2).equals(java.util.List.of(0,1)) && second.subList(0,2).equals(java.util.List.of(2,3))
            && third.subList(0,2).equals(java.util.List.of(4,0)),"five towns receive fair rotating pairs");
        var settings=new LivingWorldSettings();check(settings.maxConcurrentWorkTowns==2 && settings.workWindowTicks==48000,"two Minecraft days per pair by default");
        settings.workWindowTicks=200000;settings.validate();check(settings.workWindowTicks==120000,"rotation window is capped at five Minecraft days");
        settings.maxWorkChunks=18;settings.validate();check(settings.maxWorkChunks==96,"two active towns retain usable construction budgets");
        settings.maxConcurrentWorkTowns=1;settings.maxWorkChunks=18;settings.validate();check(settings.maxWorkChunks==48,"one active town retains a usable construction budget");
        check(ChunkWorkPlan.overworldRegion(java.nio.file.Path.of("world")).equals(java.nio.file.Path.of("world","region")),"Overworld regions live directly under world root");
        System.out.println("PASS: bounded work corridor and whole-corridor player simulation checks.");
    }
}

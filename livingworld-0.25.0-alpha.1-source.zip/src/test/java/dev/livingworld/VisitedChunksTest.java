package dev.livingworld;
import net.minecraft.world.level.ChunkPos;
import java.nio.ByteBuffer;
import java.nio.file.*;
public final class VisitedChunksTest {
    private static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception{
        Path dir=Files.createTempDirectory("livingworld-region-test");
        try{
            VisitedChunks.resetPlayerVisits();
            check(!VisitedChunks.stored(dir,new ChunkPos(-1,-1)),"missing negative region is unvisited");
            byte[] region=new byte[12288];int entry=(31+32*31)*4;
            ByteBuffer.wrap(region).putInt(entry,(2<<8)|1);
            Files.write(dir.resolve("r.-1.-1.mca"),region);
            check(VisitedChunks.stored(dir,new ChunkPos(-1,-1)),"existing location header is visited");
            check(!VisitedChunks.stored(dir,new ChunkPos(-2,-1)),"empty location entry remains unvisited");
            ByteBuffer.wrap(region).putInt((29+32*31)*4,(3<<8)|1);
            Files.write(dir.resolve("r.-1.-1.mca"),region);
            Files.setLastModifiedTime(dir.resolve("r.-1.-1.mca"),java.nio.file.attribute.FileTime.fromMillis(System.currentTimeMillis()+1000));
            check(!VisitedChunks.stored(dir,new ChunkPos(-3,-1)),"incomplete sector range is not considered saved");
            ByteBuffer.wrap(region).putInt((30+32*31)*4,(2<<8)|1);
            Files.write(dir.resolve("r.-1.-1.mca"),region);
            Files.setLastModifiedTime(dir.resolve("r.-1.-1.mca"),java.nio.file.attribute.FileTime.fromMillis(System.currentTimeMillis()+2000));
            check(VisitedChunks.stored(dir,new ChunkPos(-2,-1)),"updated region header becomes available after pregeneration");
            check(!VisitedChunks.playerEntered(new ChunkPos(-1,-1)),"stored or pregenerated chunks are not player visits");
            check(VisitedChunks.recordPlayerEntry(new ChunkPos(-1,-1)),"first player entry is recorded");
            check(!VisitedChunks.recordPlayerEntry(new ChunkPos(-1,-1)),"duplicate entry does not require another save");
            check(!VisitedChunks.playerEntered(new ChunkPos(-2,-1)),"neighboring generated chunk remains unvisited");
            var snapshot=VisitedChunks.playerVisitSnapshot();VisitedChunks.resetPlayerVisits();
            check(!VisitedChunks.playerEntered(new ChunkPos(-1,-1)),"reset clears one world's visits");
            VisitedChunks.loadPlayerVisits(snapshot);
            check(VisitedChunks.playerEntered(new ChunkPos(-1,-1)),"visit survives save and reload");
            check(!VisitedChunks.playerEntered(new ChunkPos(-2,-1)),"saved bitmap does not broaden a visit");
            System.out.println("PASS: Anvil availability and exact, persistent player-entry history stay separate.");
        }finally{Files.deleteIfExists(dir.resolve("r.-1.-1.mca"));Files.deleteIfExists(dir);}
    }
}

package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class CitizenLifeTest {
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 static CitizenLife person(int id,String name){var c=new CitizenLife();c.id=id;c.name=name;c.uuid=UUID.randomUUID().toString();return c;}
 public static void main(String[] args)throws Exception{
  var a=person(1,"Ada");var b=person(2,"Rowan");var town=new Settlement("Oakford","minecraft:overworld",0,64,0);town.residents.put(1,a);town.residents.put(2,b);
  check(!a.meet(a,0),"No self relationships");check(a.meet(b,0) && !a.meet(b,0),"Meet once per day");b.meet(a,0);a.meet(b,1);a.meet(b,2);
  check(a.familiar(town).equals("Rowan (friend)"),"Repeated observed meetings create familiarity");b.present=false;check(!a.familiar(town).contains("Rowan"),"Absent citizens are not presented as present");b.present=true;
  var owner=UUID.randomUUID().toString();check(a.remember(owner,0) && !a.remember(owner,0),"Conversation throttle is persisted per day");
  var restored=new Gson().fromJson(new Gson().toJson(town),Settlement.class);restored.validate();check(restored.residents.get(1).visitors.containsKey(owner) && !restored.residents.get(1).meet(restored.residents.get(2),2),"Identity and memory survive reload without duplicate meetings");
  check(CitizenLife.activity(1000,false,false).contains("Morning") && CitizenLife.activity(10000,false,false).contains("neighbours"),"Daily social phases");
  check(CitizenLife.activity(14000,true,false).equals("At work") && CitizenLife.activity(1000,true,true).equals("Resting at home"),"Native work and sleep take priority");
  check(RegionRules.key(-1,-2048).equals("-1:-1") && RegionRules.key(2048,2047).equals("1:0"),"Region boundaries floor negative coordinates");check(RegionRules.name(0,0).equals(RegionRules.name(2047,2047)),"Stable region names");
  String type="com/minecolonies/core/entity/ai/minimal/EntityAICitizenWander";
  check(BuilderLogisticsTest.member(type,"canUse","()Z",false),"Native wander entry point exists");check(BuilderLogisticsTest.member(type,"citizen","Lcom/minecolonies/core/entity/citizen/EntityCitizen;",true),"Native citizen shadow exists");
  var view=DashboardData.project(town,owner,false);check(view.residents.size()==2 && !new Gson().toJson(view).contains(owner),"Public resident cards omit private visitor memories");DashboardData.compact(view);check(view.residents.isEmpty(),"Unselected town payload bounded");
  System.out.println("PASS: persistent resident identities, observed relationships, remembered visitors, routine priorities, regions, privacy and native wander hook compatibility.");
 }
}

package dev.livingworld;
import com.google.gson.Gson;
public final class EconomyTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    static void building(Settlement s,String kind,boolean complete){var e=new Expansion();e.kind=kind;e.pack="test";e.path="test";e.complete=complete;s.expansions.add(e);}
    public static void main(String[] args){
        var s=new Settlement("Economy","minecraft:overworld",0,70,0);s.colonyId=1;s.colonyOwner="12345678-1234-1234-1234-123456789012";
        s.governorEnabled=true;int wood=s.wood;s.step();check(s.wood==wood,"Partial activation stays frozen");
        s.colonyReady=true;s.step();check(s.wood>wood && s.homes==1 && s.progress==0,"Activated economy does not build phantom cottages");
        s.governorEnabled=false;String before=new Gson().toJson(s);s.step();check(before.equals(new Gson().toJson(s)),"Pause freezes economy");s.governorEnabled=true;
        check(Economy.next(s).equals("residence"),"Housing first");building(s,"residence",true);
        check(Economy.next(s).equals("farmer"),"Food production next");building(s,"farmer",false);
        check(Economy.count(s,"farmer")==0,"Unfinished farm cannot produce");
        s.economyPopulation=32;s.food=0;Economy.step(s);check(s.food==0 && !Economy.affordable(s,"residence"),"Food shortage blocks investment");
        var survival=new Settlement("Survival","minecraft:overworld",0,70,0);survival.colonyReady=true;survival.governorEnabled=true;survival.materialMode=true;survival.economyPopulation=8;survival.food=10;
        Economy.step(survival);check(survival.food<10,"Material mode does not waive citizen rations");
        building(survival,"farmer",true);int hungryFood=survival.food;Economy.step(survival);check(survival.food>hungryFood,"A completed staffed farm restores food production");
        s.economyPopulation=4;s.wood=100;s.stone=80;s.food=80;s.treasury=20;
        Economy.pay(s,"residence");check(s.wood==36 && s.stone==48 && s.food==72 && s.treasury==16,"Construction debits all costs");
        boolean rejected=false;try{Economy.pay(s,"residence");}catch(IllegalArgumentException e){rejected=true;}check(rejected && s.wood==36,"Insufficient funds never partially debit");
        Economy.refund(s,"residence");check(s.wood==100 && s.stone==80 && s.food==80 && s.treasury==20,"Failed anchor placement refunds");
        s.food=Economy.reserve(s)+7;before=new Gson().toJson(s);rejected=false;try{Economy.trade(s,"food",true);}catch(IllegalArgumentException e){rejected=true;}check(rejected && before.equals(new Gson().toJson(s)),"Trade preserves food reserve and atomicity");
        s.wood=512;rejected=false;try{Economy.trade(s,"wood",false);}catch(IllegalArgumentException e){rejected=true;}check(rejected && s.wood==512,"Full stock rejects sales");
        for(int n=0;n<=512;n++){s.wood=n;check(Economy.price(s,"wood",true)>Economy.price(s,"wood",false),"No instant buy/sell arbitrage");}
        s.wood=24;s.food=32;s.treasury=16;s.recruitmentCooldown=20;
        for(int i=0;i<100000;i++)s.step();s.validate();check(s.wood<=512 && s.food<=512 && s.treasury<=4096 && s.recruitmentCooldown==0,"Long-run bounds and recruitment cooldown");
        var copy=new Gson().fromJson(new Gson().toJson(s),Settlement.class);copy.validate();check(copy.economyCycles==s.economyCycles && copy.expansions.size()==2,"Ledger and projects survive reload");
        s.economyPopulation=0;wood=s.wood;s.step();check(s.wood==wood,"Empty colony cannot produce");
        System.out.println("PASS: linked economy, pause, housing/food priorities, completed production, payment/refund, food reserves, market bounds, persistence, and no trade arbitrage.");
    }
}

package dev.livingworld;
import java.util.*;
public final class TownPlannerTest {
    private static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    public static void main(String[] args){
        var buildings=new HashMap<String,Integer>();var sequence=new ArrayList<String>();
        for(int i=0;i<32;i++){
            String next=TownPlanner.next(kind->buildings.getOrDefault(kind,0));
            if(next==null)break;
            sequence.add(next);buildings.merge(next,1,Integer::sum);
            check(DistantProgress.supported(next),"Every planned kind is a supported paid project: "+next);
            check(Economy.cost(next).wood()>0,"Every planned kind has a construction cost");
        }
        check(sequence.size()==20,"Capital has a finite 20-building plan within default limit");
        check(sequence.get(0).equals("residence") && sequence.get(1).equals("farmer"),"Housing and food lead");
        check(buildings.get("residence")==8 && buildings.get("farmer")==3,"Capital has 32 housing places and three farms");
        for(String kind:List.of("lumberjack","miner","hospital","guardtower","school","university","barracks"))check(buildings.get(kind)==1,"Late building present: "+kind);
        check(TownPlanner.next(kind->buildings.getOrDefault(kind,0))==null,"No endless residence loop at end game");
        var emergency=new Settlement("Emergency","minecraft:overworld",0,70,0);emergency.economyPopulation=8;emergency.food=0;
        var counts=new HashMap<String,Integer>();counts.put("residence",2);counts.put("farmer",1);
        check(TownPlanner.next(emergency,k->counts.getOrDefault(k,0)).equals("farmer"),"Food shortage preempts advanced construction");
        emergency.food=512;emergency.pendingMigrants=5;
        check(TownPlanner.next(emergency,k->counts.getOrDefault(k,0)).equals("residence"),"Housing backlog preempts advanced construction");
        var town=new Settlement("Capital","minecraft:overworld",0,70,0);town.expedition=true;town.colonyReady=true;town.economyPopulation=32;
        var camp=new SitePlan();camp.complete=true;town.camp=camp;
        for(int n=0;n<2;n++){var site=new SitePlan();site.complete=true;town.starterSites.add(site);}
        for(String kind:sequence){var e=new Expansion();e.kind=kind;e.complete=true;town.expansions.add(e);}
        check(TownProgress.stage(town).equals("Capital"),"Full built plan and population reach the capital stage");
        town.economyPopulation=24;check(TownProgress.stage(town).equals("City"),"Population remains part of end-game progression");
        System.out.println("PASS: finite shared survival-to-capital plan, workplaces, services, housing and complete costs.");
    }
}

package dev.livingworld;
public final class SupplyRulesTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        check(SupplyRules.acknowledged(35,1,35,64)==35,"Saved builder's 35 cobblestone satisfy the outstanding 1-35 request");
        check(SupplyRules.acknowledged(35,1,0,64)==0,"No phantom delivery when only ledger stock exists");
        check(SupplyRules.acknowledged(35,16,15,64)==0,"Minimum native batch must be present");
        check(SupplyRules.acknowledged(35,1,16,64)==16,"Partial batches acknowledge only physical items");
        check(SupplyRules.acknowledged(120,1,90,64)==64,"Large requests use a bounded delivery stack");
        check(SupplyRules.acknowledged(1,1,3,1)==1,"Tools acknowledge one physical tool");
        check(SupplyRules.batchTarget(35,64,32)==32,"Prefill a portable building batch before confirming");
        check(SupplyRules.batchTarget(9,64,32)==9,"Never fill beyond the native request");
        check(SupplyRules.batchTarget(40,1,32)==1,"Tools remain a single item");
        var s=new Settlement("Starter","minecraft:overworld",0,70,0);s.colonyId=1;s.expedition=true;s.materialMode=true;s.governorEnabled=true;s.economyPopulation=1;
        int wood=s.wood;s.step();check(s.wood==wood,"No founder means no gathering");
        s.founderSpawned=true;s.wood=s.stone=s.food=s.treasury=0;s.step();s.step();
        check(s.wood==8 && s.stone==6 && s.food==6 && s.treasury==1,"Starter replenishes every essential and eats rations before both sites exist");
        s.governorEnabled=false;wood=s.wood;s.step();check(s.wood==wood,"Paused camps do not gather");
        s.governorEnabled=true;s.colonyReady=true;var a=new SitePlan();a.complete=true;var b=new SitePlan();b.complete=true;s.starterSites.add(a);s.starterSites.add(b);
        check(!SupplyRules.bootstrapping(s),"Starter bonus ends after both starter buildings finish");
        wood=s.wood;s.step();check(s.wood==wood+1,"Established colony returns to normal production");
        System.out.println("PASS: real-inventory acknowledgement, native batch minima, saved cobblestone deadlock and autonomous starter gathering.");
    }
}

package dev.livingworld;
import com.google.gson.Gson;
import java.util.*;
public final class RouteSearchTest {
    private static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
    private static void finish(RouteSearch search){for(int i=0;i<500 && !search.done;i++)search.step(24);check(search.done,"Search terminates within bounded work");}
    public static void main(String[] args){
        var start=new RouteSearch.Point(0,70,0);var end=new RouteSearch.Point(8,70,0);
        var route=new RouteSearch(start,end,(x,z)->Math.abs(x)>12 || Math.abs(z)>12 || x==4 && Math.abs(z)<3?null:70);finish(route);
        check(!route.route.isEmpty() && route.route.stream().anyMatch(p->Math.abs(p.z())>=3),"Finds a detour around a protected wall");
        var cliff=new RouteSearch(start,new RouteSearch.Point(8,75,0),(x,z)->Math.abs(x)>12 || Math.abs(z)>2?null:x<4?70:75);finish(cliff);check(cliff.route.isEmpty(),"Cannot jump a cliff");
        var stairs=new RouteSearch(start,new RouteSearch.Point(6,76,0),(x,z)->z!=0 || x<0 || x>6?null:70+x);finish(stairs);check(stairs.route.size()==7,"One-block grades are connected");
        var unloaded=new RouteSearch(start,end,(x,z)->x>3?null:70);finish(unloaded);check(unloaded.route.isEmpty(),"Missing terrain is not treated as traversable");
        var p=new RoadPlan();p.points.addAll(route.route);for(var point:p.points)p.ground.add("natural ground");p.cursor=3;p.issued=true;p.activePath="road_"+p.id+"_3.blueprint";p.validate();
        var copy=new Gson().fromJson(new Gson().toJson(p),RoadPlan.class);copy.validate();check(copy.cursor==3 && copy.issued && copy.points.equals(p.points),"Save/reload preserves route and active segment");
        check(p.intersects(4,4,3,3) || p.intersects(4,4,-3,-3),"Reserved route blocks overlapping building plots");
        copy.points.set(1,new RouteSearch.Point(999,70,999));boolean rejected=false;try{copy.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Invalid disconnected saved route is rejected");
        var json=new Gson().toJsonTree(new Settlement("Old","minecraft:overworld",0,70,0)).getAsJsonObject();json.remove("roads");json.remove("siteReports");
        var legacy=new Gson().fromJson(json,Settlement.class);legacy.validate();check(legacy.roads.isEmpty(),"Old worlds acquire an empty road list without rebuilding");
        System.out.println("PASS: bounded route finding, obstacle detours, cliff rejection, steps, unloaded terrain, reservation protection and save recovery.");
    }
}

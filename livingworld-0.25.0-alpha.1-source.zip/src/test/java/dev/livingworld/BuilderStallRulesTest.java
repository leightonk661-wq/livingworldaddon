package dev.livingworld;
public final class BuilderStallRulesTest {
    private static void check(boolean v,String why){if(!v)throw new AssertionError(why);}
    public static void main(String[] args){
        check(!BuilderStallRules.warn(1199,false),"Ordinary slow build not warned");
        check(BuilderStallRules.warn(1200,false),"Long unchanged cursor warned");
        check(!BuilderStallRules.rescue(3599,false),"No early handover");
        check(BuilderStallRules.rescue(3600,false),"Three-minute silent stall can recover");
        check(!BuilderStallRules.rescue(6000,true),"Open native material requests block handover");
        System.out.println("PASS: native builder stall timing and open-request protection.");
    }
}

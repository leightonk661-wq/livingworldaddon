package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class WayfindingTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        var town=new Settlement("Oakford","minecraft:overworld",100,70,100);town.founder="owner";var journey=new PlayerJourney();
        check(!WaypointRules.known(town,journey,"visitor") && WaypointRules.known(town,journey,"owner"),"Unvisited towns cannot be marked unless founded by this player");
        var unnamed=new Settlement("Hidden","minecraft:overworld",0,64,0);check(!WaypointRules.known(unnamed,journey,""),"Empty ownership never grants location knowledge");
        journey.visited.add(town.name);check(WaypointRules.known(town,journey,"visitor"),"Visited town can be marked");
        check(WaypointRules.arrived("minecraft:overworld",132,100,town) && !WaypointRules.arrived("minecraft:overworld",133,100,town),"Arrival uses a bounded 32-block radius");
        check(!WaypointRules.arrived("minecraft:the_nether",100,100,town),"Coordinates in another dimension are not arrival");
        check(WaypointRules.bearing(0,-100).equals("North") && WaypointRules.bearing(100,0).equals("East") && WaypointRules.bearing(0,100).equals("South") && WaypointRules.bearing(-100,0).equals("West"),"Minecraft cardinal axes are correct");
        check(WaypointRules.bearing(100,-100).equals("Northeast") && WaypointRules.bearing(-100,100).equals("Southwest"),"Diagonal directions are correct");
        journey.waypointTown=town.name;var restored=new Gson().fromJson(new Gson().toJson(journey),PlayerJourney.class);restored.validate();check(restored.waypointTown.equals(town.name),"Trail survives reload");
        var data=JournalData.project(restored,List.of(town),null,"visitor");check(data.waypointTown.equals(town.name) && data.waypointX==100 && data.knownPlaces.size()==1,"Only known destinations enter the journal transport");
        restored.visited.clear();data=JournalData.project(restored,List.of(town),null,"visitor");check(data.waypointTown.isEmpty() && data.knownPlaces.isEmpty(),"Forged destination does not reveal unknown town coordinates");
        check(TownPresentation.relationship(0,false).equals("New acquaintance") && TownPresentation.relationship(20,false).equals("Friend of the town") && TownPresentation.relationship(40,true).equals("Trusted ally"),"Relationship ranks follow real reputation and alliance");
        town.expedition=true;town.governorEnabled=true;town.food=100;town.founderSpawned=true;
        var e=new Expansion();e.kind="residence";e.pack="Oak";e.path="test";town.expansions.add(e);
        var view=DashboardData.project(town,"visitor",false);check(view.projects.getFirst().percent()==-1 && !view.projects.getFirst().complete(),"Unknown native progress is not fabricated");
        town.history.add("Settlement stage: Village");town.history.add("Funded distant residence: raw cost data");view=DashboardData.project(town,"visitor",false);
        check(view.news.getFirst().equals("The council set aside supplies for new construction.") && !view.news.getFirst().contains("raw cost"),"Chronicle presents newest events without raw simulation text");
        DashboardData.compact(view);check(view.projects.isEmpty() && view.news.isEmpty(),"Unselected towns keep transport compact");
        System.out.println("PASS: known-town trails, arrival and dimension checks, compass bearings, persistence, location privacy, relationships and honest progress cards.");
    }
}

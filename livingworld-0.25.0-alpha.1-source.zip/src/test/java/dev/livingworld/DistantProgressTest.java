package dev.livingworld;
import com.google.gson.Gson;
public final class DistantProgressTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    static Settlement town(){
        var s=new Settlement("Distant","minecraft:overworld",0,70,0);s.expedition=true;s.colonyId=1;s.colonyReady=true;s.colonyOwner="00000000-0000-0000-0000-000000000001";
        s.governorEnabled=true;s.distantEnabled=true;s.materialMode=true;s.expansionPack="Oak";s.economyPopulation=1;s.wood=s.stone=s.food=512;s.treasury=200;
        for(String kind:new String[]{"builder","townhall"}){var p=new SitePlan();p.kind=kind;p.pack="Oak";p.path=kind+"1.blueprint";p.width=p.depth=p.height=1;p.complete=true;s.starterSites.add(p);}
        return s;
    }
    static SitePlan site(DistantProject project){var p=new SitePlan();p.kind=project.kind;p.pack=project.pack;p.path=project.kind+"1.blueprint";p.width=p.height=p.depth=1;p.before.add("Block{minecraft:air}");p.autoAssembly=true;return p;}
    public static void main(String[] args){
        LivingWorldSettings.current=new LivingWorldSettings();LivingWorldSettings.current.distantProjectCycles=2;
        var s=town();DistantProgress.step(s,false);check(s.distantProjects.isEmpty(),"Nearby towns do not start abstract projects");
        DistantProgress.step(s);check(s.distantProjects.size()==1 && s.wood==448 && s.stone==480 && s.treasury==196,"Distant project paid once");
        var p=s.distantProjects.getFirst();check(!p.ready(),"Not instantly complete");
        s.governorEnabled=false;DistantProgress.step(s);check(p.progress==0,"Governor pause freezes project");s.governorEnabled=true;
        s.distantEnabled=false;DistantProgress.step(s);check(p.progress==0,"Per-town pause freezes project");s.distantEnabled=true;
        DistantProgress.step(s,false);check(p.progress==1,"Already funded project continues on return");
        s=new Gson().fromJson(new Gson().toJson(s),Settlement.class);s.validate();p=s.distantProjects.getFirst();DistantProgress.step(s);
        check(p.ready() && s.wood==448 && s.stone==480 && s.treasury==196,"Reload preserves progress without repaying");
        int wood=s.wood,stone=s.stone,coins=s.treasury;var e=DistantProgress.reserve(s,p,site(p));s.validate();
        check(s.distantProjects.isEmpty() && e.registrationPending && e.assembly!=null && s.wood==wood && s.stone==stone && s.treasury==coins,"Queue-to-assembly transfer is prepaid and journalled");
        boolean rejected=false;try{DistantProgress.reserve(s,p,site(p));}catch(IllegalArgumentException ex){rejected=true;}check(rejected && s.expansions.size()==1,"Replay cannot duplicate a building");
        s=new Gson().fromJson(new Gson().toJson(s),Settlement.class);s.validate();check(s.expansions.getFirst().registrationPending,"Registration recovery survives reload");
        var recovered=town();var stalled=new Expansion();stalled.kind="residence";stalled.pack="Oak";stalled.path="residence1.blueprint";stalled.x=10;stalled.y=70;stalled.z=10;
        var journal=new SitePlan();journal.kind=stalled.kind;journal.pack=stalled.pack;journal.path=stalled.path;journal.x=stalled.x;journal.y=stalled.y;journal.z=stalled.z;journal.minX=10;journal.minY=70;journal.minZ=10;journal.width=journal.height=journal.depth=1;
        stalled.assembly=journal;recovered.expansions.add(stalled);recovered.validate();
        recovered=new Gson().fromJson(new Gson().toJson(recovered),Settlement.class);recovered.validate();
        check(recovered.expansions.getFirst().assembly!=null && recovered.expansions.getFirst().projectId.isEmpty(),"Native stall recovery can resume a saved automatic journal without inventing a paid project");
        check(Economy.count(s,"residence")==0 && DistantProgress.completed(s,"residence")==1,"Physical completion kept separate from simulated completion");
        s.expansions.getFirst().complete=true;check(DistantProgress.completed(s,"residence")==1,"Materialization does not double-count production");
        check(DistantProgress.next(s).equals("farmer"),"Housing followed by food production");
        var starving=town();starving.food=0;DistantProgress.step(starving);check(starving.distantProjects.isEmpty() && starving.food==0,"Food shortage pauses distant work without negative stock");
        var poor=town();poor.wood=0;DistantProgress.step(poor);check(poor.distantProjects.isEmpty() && poor.treasury==200,"Insufficient resources do not partially charge a project");
        var boot=town();boot.starterSites.getFirst().complete=false;DistantProgress.step(boot);check(boot.distantProjects.isEmpty(),"Bootstrap must finish before distant growth");
        LivingWorldSettings.current.distantQueueLimit=2;var bounded=town();for(int n=0;n<200;n++){bounded.wood=bounded.stone=bounded.food=512;bounded.treasury=200;DistantProgress.step(bounded);}
        check(bounded.distantProjects.size()==2 && bounded.pendingMigrants<=16 && bounded.expansions.isEmpty(),"Long distant simulation remains bounded and never places terrain");
        check(bounded.pendingMigrants>0 && bounded.economyPopulation==1,"Migrants reserved without spawning or inflating real citizen count");
        var duplicated=new Gson().fromJson(new Gson().toJson(bounded),Settlement.class);duplicated.distantProjects.add(duplicated.distantProjects.getFirst());rejected=false;try{duplicated.validate();}catch(IllegalArgumentException ex){rejected=true;}check(rejected,"Duplicate persisted projects rejected");
        var limited=town();for(int n=0;n<23;n++){var existing=new Expansion();existing.kind="residence";existing.pack="Oak";existing.path="residence1.blueprint";existing.complete=true;limited.expansions.add(existing);}
        for(int n=0;n<8;n++){limited.wood=limited.stone=limited.food=512;limited.treasury=200;DistantProgress.step(limited);}
        check(limited.expansions.size()+limited.distantProjects.size()==24,"Combined physical and queued development cap enforced");
        var snapshot=new DashboardData();
        for(int n=0;n<32;n++){
            var view=DashboardData.project(bounded,"viewer",false);
            for(int k=0;k<48;k++)view.buildings.add("Building "+k+" / "+"x".repeat(180));
            for(int k=0;k<50;k++)view.terrain.add("Approach "+k+" / "+"x".repeat(390));
            if(n!=0)DashboardData.compact(view);snapshot.towns.add(view);
        }
        String payload=new Gson().toJson(snapshot);check(payload.length()<262144,"32 large settlements fit dashboard transport with selected details");
        var buf=new net.minecraft.network.FriendlyByteBuf(io.netty.buffer.Unpooled.buffer());
        try{var packet=new DashboardNetwork.Snapshot(payload,true);DashboardNetwork.Snapshot.CODEC.encode(buf,packet);check(DashboardNetwork.Snapshot.CODEC.decode(buf).equals(packet),"Expanded dashboard payload round trip");}finally{buf.release();}
        for(int n=0;n<32;n++){var simulated=town();for(int cycle=0;cycle<400;cycle++){simulated.step();DistantProgress.step(simulated);}check(simulated.distantProjects.size()<=2 && simulated.expansions.isEmpty() && simulated.economyPopulation==1 && simulated.food>=0 && simulated.wood>=0 && simulated.stone>=0,"Long-run distant simulation stays bounded without physical side effects");}
        LivingWorldSettings.current=new LivingWorldSettings();
        check(DashboardData.command("distant","Distant","off").equals("livingworld distant Distant off"),"Dashboard toggle uses allowlisted command");
        System.out.println("PASS: distant funding, bounded timed progress, pause, food shortage, save/reload, prepaid reservation replay protection, virtual/physical counts and migrant reservations.");
    }
}

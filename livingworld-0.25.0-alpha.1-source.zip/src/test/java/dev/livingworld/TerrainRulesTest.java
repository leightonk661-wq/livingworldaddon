package dev.livingworld;
import java.util.*;
public final class TerrainRulesTest {
    static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
    public static void main(String[] args){
        check(TerrainRules.buildable(70,74,72,6),"Moderate hill permits native excavation");
        check(TerrainRules.buildable(70,76,73,6),"Six block relief accepted at supported entrance");
        check(!TerrainRules.buildable(70,77,73,6),"Cliffs rejected");
        check(!TerrainRules.buildable(70,76,75,6),"Raised entrance would leave exposed foundations");
        check(!TerrainRules.buildable(70,74,73,1),"Short foundation cannot bridge slope");
        check(TerrainRules.buildable(70,70,70,0),"Flat sites remain valid");
        var locations=new HashSet<String>();for(int i=0;i<48;i++){var p=TerrainRules.candidate(i);locations.add(p[0]+","+p[1]);check(Math.abs(p[0])<=104 && Math.abs(p[1])<=104,"Search stays in nearby terrain");}
        check(locations.size()==48 && locations.contains("-24,-24"),"All directions, no duplicated candidates");
        var s=new Settlement("Test","minecraft:overworld",0,70,0);s.expedition=true;s.governorEnabled=true;s.camp=new SitePlan();s.camp.complete=true;s.founderSpawned=true;
        var view=DashboardData.project(s,"viewer",true);check(view.milestone==3 && view.phase.contains("builder site"),"Survey blockage visible");
        var site=new SitePlan();site.kind="builder";s.starterSites.add(site);view=DashboardData.project(s,"viewer",true);check(view.milestone==4,"Builder starts without town hall reservation");
        site.complete=true;view=DashboardData.project(s,"viewer",true);check(view.milestone==5,"Hall is next");
        check(MaterialCosts.describe(new MaterialCosts.Price(3,0,0,0)).equals("3 wood"),"Readable costs");
        System.out.println("PASS: slope excavation limits, supported entrances, complete search ring, staged dashboard and readable costs.");
    }
}

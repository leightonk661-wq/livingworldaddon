package dev.livingworld;
import com.google.gson.Gson;
public final class StarterRulesTest {
    private static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        check(StarterRules.trainingIncrease(1)==3 && StarterRules.trainingIncrease(4)==0 && StarterRules.trainingIncrease(8)==0,"Training reaches four without downgrading experienced settlers");
        var p=new SitePlan();p.kind="builder";p.pack="test";p.path="builder1.blueprint";p.width=2;p.depth=2;p.height=2;
        check(StarterRules.automatic(p),"Unfinished builder is automatic");p.kind="townhall";check(StarterRules.automatic(p),"Unfinished hall is automatic");
        p.kind="residence";check(!StarterRules.automatic(p),"Later buildings stay native");p.kind="camp";check(!StarterRules.automatic(p),"Camp retains its existing engine");
        p.kind="builder";p.complete=true;check(!StarterRules.automatic(p),"Finished huts are never rebuilt");p.complete=false;
        p.autoAssembly=true;for(int i=0;i<8;i++)p.before.add("Block{minecraft:dirt}");p.cursor=5;p.validate();
        var copy=new Gson().fromJson(new Gson().toJson(p),SitePlan.class);copy.validate();check(copy.autoAssembly && copy.cursor==5 && copy.before.size()==8,"Partial automatic work and original terrain survive reload");
        copy.before.removeFirst();boolean rejected=false;try{copy.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Partial protection journal cannot resume");
        p.complete=true;p.before.clear();p.cursor=16;p.validate();check(!StarterRules.automatic(p),"Completed state may discard snapshot safely");
        System.out.println("PASS: starter-only assembly, higher skill preservation, completion idempotence and persisted protection journals.");
    }
}

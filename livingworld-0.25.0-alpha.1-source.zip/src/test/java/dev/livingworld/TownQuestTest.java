package dev.livingworld;

import com.google.gson.Gson;

public final class TownQuestTest {
    private static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    public static void main(String[] args){
        var town=new Settlement("QuestTown","minecraft:overworld",0,70,0);
        town.expedition=true;town.colonyReady=true;town.colonyId=1;
        town.colonyOwner="12345678-1234-1234-1234-123456789abc";town.economyPopulation=4;
        town.food=20;town.wood=300;town.stone=300;town.treasury=5;
        check(TownQuests.offer(town,1000)!=null,"Established hungry towns should ask for food");
        var q=town.quest;check(q.resource.equals("food") && q.amount==16,"Food request should ask for a bounded bread delivery");
        check(TownQuests.offer(town,1001)==null && town.quest==q,"A town should never stack duplicate open requests");
        check(TownQuests.acceptableDrop(town,5)==5 && town.food==20 && town.treasury==5,"Checking a dropped stack must not change stock");
        var restored=new Gson().fromJson(new Gson().toJson(town),Settlement.class);restored.validate();
        check(restored.quest!=null && restored.quest.id.equals(q.id),"Open request survives reload");
        check(TownQuests.acceptDrop(restored,"player",5,1090)==0 && restored.quest.progress==5 && restored.food==25,"Partial physical drops persist without premature reward");
        restored=new Gson().fromJson(new Gson().toJson(restored),Settlement.class);restored.validate();
        check(restored.quest.progress==5 && TownQuests.acceptableDrop(restored,16)==11,"Progress survives reload and caps an oversized drop");
        int reward=TownQuests.acceptDrop(restored,"player",11,1100);
        check(reward==1 && restored.food==36 && restored.treasury==4 && restored.relation("player")==5,"Physical drops change stock, reputation and funded reward exactly once");
        try{TownQuests.acceptDrop(restored,"player",1,1101);throw new AssertionError("Quest paid twice");}catch(IllegalArgumentException expected){}
        check(restored.food==36 && restored.treasury==4,"Duplicate completion must not change stock or treasury");
        check(TownQuests.offer(restored,1100+TownQuests.COOLDOWN_TICKS-1)==null,"Cooldown prevents rapid repeat quests");
        restored.food=300;restored.wood=100;restored.stone=300;
        check(TownQuests.offer(restored,1100+TownQuests.COOLDOWN_TICKS).resource.equals("wood"),"Next request responds to the new timber shortage");
        System.out.println("PASS: need-based request books, partial physical deliveries, persistence, single reward and cooldown.");
    }
}

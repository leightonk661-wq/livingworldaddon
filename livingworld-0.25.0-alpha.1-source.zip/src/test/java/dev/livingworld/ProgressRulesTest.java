package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class ProgressRulesTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        check(!ConstructionSafety.blocksWorkType(net.minecraft.world.entity.item.ItemEntity.class),"Dropped seeds/items must not stall construction");
        check(!ConstructionSafety.blocksWorkType(net.minecraft.world.entity.ExperienceOrb.class),"XP drops must not stall construction");
        check(ConstructionSafety.blocksWorkType(net.minecraft.server.level.ServerPlayer.class),"Players protected");
        check(ConstructionSafety.blocksWorkType(net.minecraft.world.entity.LivingEntity.class),"Citizens and animals protected");
        check(ConstructionSafety.blocksWorkType(net.minecraft.world.entity.decoration.ItemFrame.class),"Placed decorations protected");
        var settings=new Gson().fromJson("{}",LivingWorldSettings.class);settings.validate();check(settings.starterBlocksPerTick==8 && settings.supplyBatchSize==32,"Missing settings retain defaults");
        settings.starterBlocksPerTick=1000;settings.campBlocksPerTick=-1;settings.surveyCellsPerTick=9999;settings.validate();check(settings.starterBlocksPerTick==32 && settings.campBlocksPerTick==1 && settings.surveyCellsPerTick==256,"Budgets are bounded");
        Set<String> candidates=new HashSet<>();for(int i=0;i<TerrainRules.SEARCH_SITES;i++)candidates.add(Arrays.toString(TerrainRules.candidate(i)));
        check(candidates.size()==264 && Arrays.equals(TerrainRules.candidate(0),TerrainRules.candidate(264)),"264 unique nearby survey candidates wrap predictably");
        var s=new Settlement("Test","minecraft:overworld",0,70,0);s.expedition=true;
        SurveyMemory.reject(s,"Oak","builder",1,2,100,"test");
        check(SurveyMemory.blocked(s,"Oak","builder",1,2,101) && !SurveyMemory.blocked(s,"Oak","townhall",1,2,101) && !SurveyMemory.blocked(s,"Spruce","builder",1,2,101),"Failure memory isolated by kind and pack");
        check(!SurveyMemory.blocked(s,"Oak","builder",1,2,1300),"Rejected sites expire");
        for(int i=0;i<500;i++)SurveyMemory.reject(s,"Oak","builder",i,2,100,"test");
        check(s.rejectedSites.size()==384 && s.siteReports.size()==16,"Failure memory bounded");
        check(TownProgress.stage(s).equals("Expedition"),"No completed camp yet");s.camp=new SitePlan();s.camp.complete=true;
        check(TownProgress.stage(s).equals("Outpost"),"Camp alone is an outpost");
        for(String kind:new String[]{"builder","townhall"}){var site=new SitePlan();site.kind=kind;s.starterSites.add(site);}
        check(TownProgress.stage(s).equals("Outpost"),"Reservations do not complete milestones");
        s.starterSites.forEach(p->p.complete=true);check(TownProgress.stage(s).equals("Hamlet"),"Both huts required");
        for(String kind:new String[]{"residence","residence","farmer","residence","warehouse","deliveryman"}){var expansion=new Expansion();expansion.kind=kind;expansion.pack="Oak";expansion.path="test";expansion.complete=true;s.expansions.add(expansion);}
        s.economyPopulation=4;check(TownProgress.stage(s).equals("Village"),"Village requires residents and completed production");
        s.economyPopulation=12;check(TownProgress.stage(s).equals("Town"),"Town requires logistics and twelve residents");
        s.expansions.getLast().complete=false;check(TownProgress.stage(s).equals("Village"),"Unfinished courier does not count toward town");
        var legacy=new Settlement("Old","minecraft:overworld",0,70,0);legacy.history=null;legacy.rejectedSites=null;legacy.lifecycleStage=null;legacy.validate();check(legacy.history.isEmpty() && legacy.rejectedSites.isEmpty(),"Legacy saves initialize new fields");
        legacy.colonyReady=true;check(TownProgress.stage(legacy).equals("Established colony"),"Linked legacy colonies are not labelled expeditions");
        for(int i=0;i<40;i++)TownProgress.record(s,"Event "+i);check(s.history.size()==24,"History bounded");
        s.starterSites.getFirst().before.add("private-terrain-journal");s.starterSites.getFirst().cursor=7;
        TownProgress.recover(s);check(s.rejectedSites.isEmpty() && s.autoDevelop && s.governorEnabled && s.starterSites.getFirst().cursor==7 && s.starterSites.getFirst().before.size()==1,"Recovery preserves construction journals and progress");
        String json=new Gson().toJson(DashboardData.project(s,"viewer",true));check(!json.contains("private-terrain-journal"),"History does not leak block journals");
        check(DashboardData.command("recover","Test","").equals("livingworld recover Test"),"Recovery uses restricted command dispatcher");
        System.out.println("PASS: excavation drops, player/entity protection, configuration bounds, dense search, failure cache, lifecycle, recovery and dashboard privacy.");
    }
}

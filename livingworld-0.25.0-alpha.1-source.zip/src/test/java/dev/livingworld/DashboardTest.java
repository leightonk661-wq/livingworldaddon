package dev.livingworld;
import com.google.gson.Gson;
import io.netty.buffer.Unpooled;
import net.minecraft.network.FriendlyByteBuf;
public final class DashboardTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        var s=new Settlement("Oakridge","minecraft:overworld",0,70,0);
        s.reputation.put("viewer",24);s.reputation.put("private-other-player",90);
        var plot=new HousePlan();plot.x=4;plot.y=70;plot.cells.add(new HousePlan.Cell(4,70,0,"private-block-journal","minecraft:oak_planks"));s.plots.add(plot);
        var t=DashboardData.project(s,"viewer",true);String json=new Gson().toJson(t);
        check(t.reputation==24 && !json.contains("private-other-player") && !json.contains("private-block-journal"),"Snapshot excludes private relationships and block journals");
        check(t.finishedPlots==0 && t.plots==1,"Progress reflects actual placement");
        s.colonyId=1;s.economyPopulation=7;check(DashboardData.project(s,"viewer",true).people==7,"Linked view uses real population snapshot");
        for(String action:new String[]{"op","stop","refresh","execute"}){boolean rejected=false;try{DashboardData.command(action,"Oakridge","");}catch(IllegalArgumentException e){rejected=true;}check(rejected,"No arbitrary command execution");}
        boolean rejected=false;try{DashboardData.command("buy","Oakridge\nstop","food");}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Reject command injection through town name");
        rejected=false;try{DashboardData.command("governor","Oakridge","on\nstop");}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Reject injection through value");
        var request=new DashboardNetwork.Request("supply","Oakridge","food");var buf=new FriendlyByteBuf(Unpooled.buffer());
        try{DashboardNetwork.Request.CODEC.encode(buf,request);check(DashboardNetwork.Request.CODEC.decode(buf).equals(request),"Request codec round trip");}finally{buf.release();}
        var data=new DashboardData();for(int i=0;i<32;i++)data.towns.add(t);
        var snapshot=new DashboardNetwork.Snapshot(new Gson().toJson(data),true);buf=new FriendlyByteBuf(Unpooled.buffer());
        try{DashboardNetwork.Snapshot.CODEC.encode(buf,snapshot);check(DashboardNetwork.Snapshot.CODEC.decode(buf).equals(snapshot),"32-town snapshot codec round trip");}finally{buf.release();}
        System.out.println("PASS: dashboard privacy, placement/population projection, action allowlist, injection rejection and network codec round trips.");
    }
}

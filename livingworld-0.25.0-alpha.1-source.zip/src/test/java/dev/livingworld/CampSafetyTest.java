package dev.livingworld;
import java.util.*;
public final class CampSafetyTest {
    public static void main(String[] args){
        var positions=new HashSet<String>();
        for(int i=0;i<24;i++){var offset=CampSafety.candidate(i);if(Math.max(Math.abs(offset[0]),Math.abs(offset[1]))<32)throw new AssertionError("Camp too close");positions.add(Arrays.toString(offset));}
        if(positions.size()!=24)throw new AssertionError("Duplicate camp candidates");
        var p=new SitePlan();p.minX=26;p.minZ=-241;p.width=11;p.depth=12;
        if(!CampSafety.nearFootprint(32,-233,p,3))throw new AssertionError("Player inside reported camp must pause all changes");
        if(CampSafety.nearFootprint(20,-233,p,3))throw new AssertionError("Player beyond buffer must allow resumption");
        if(!CampSafety.nearFootprint(24,-233,p,3))throw new AssertionError("Buffer outside walls must be protected");
        System.out.println("PASS: offset-only camp sites, unique candidates, full-footprint player protection and resume distance.");
    }
}

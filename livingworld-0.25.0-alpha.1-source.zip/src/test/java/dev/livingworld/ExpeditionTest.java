package dev.livingworld;
import com.google.gson.Gson;
public final class ExpeditionTest {
    private static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        var s=new Settlement("Expedition","minecraft:overworld",0,70,0);s.expedition=true;s.autoDevelop=true;s.materialMode=true;
        int wood=s.wood;for(int i=0;i<400;i++)s.step();check(s.wood==wood && s.plots.isEmpty() && s.progress==0,"Expedition never produces test cottages");
        var p=new SitePlan();p.kind="camp";p.pack="Medieval Oak";p.path="decorations/supplies/camp.blueprint";
        p.width=11;p.depth=12;p.height=10;p.x=6;p.y=1;p.z=8;p.cursor=117;for(int i=0;i<1320;i++)p.before.add("Block{minecraft:air}");p.validate();s.camp=p;
        var loaded=new Gson().fromJson(new Gson().toJson(s),Settlement.class);loaded.validate();check(loaded.camp.cursor==117 && loaded.expedition && loaded.materialMode,"Camp resumes from persistent progress");
        var view=DashboardData.project(s,"viewer",true);check(view.expedition && view.buildings.getFirst().startsWith("Supply camp"),"Camp appears in dashboard");
        check(!new Gson().toJson(view).contains("Block{minecraft:air}"),"Camp journal stays off network");
        check(MaterialCosts.quote("minecraft:diamond",1)==null && MaterialCosts.quote("unknown:valuable",1)==null,"Unsupported valuable items cannot be procured");
        check(MaterialCosts.quote("minecraft:oak_planks",16).wood()==4,"Planks spend wood in batches");
        s.wood=4;s.stone=10;s.food=6;s.treasury=0;MaterialCosts.pay(s,MaterialCosts.quote("minecraft:oak_planks",16));check(s.wood==0,"Delivered building materials consume ledger");
        String before=new Gson().toJson(s);boolean rejected=false;try{MaterialCosts.pay(s,MaterialCosts.quote("minecraft:oak_planks",1));}catch(IllegalArgumentException e){rejected=true;}check(rejected && before.equals(new Gson().toJson(s)),"No partial charge on insufficient supply");
        MaterialCosts.pay(s,MaterialCosts.quote("minecraft:bread",2));check(s.food==4,"Real food supply is charged");
        var fee=Economy.planningCost(s,"residence");check(fee.wood()==0 && fee.stone()==0,"Material mode does not also charge fixed wood/stone per plan");
        s.materialMode=false;check(Economy.planningCost(s,"residence").wood()==64,"Legacy ledger still supports old costs until conversion");
        p.width=49;rejected=false;try{p.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Unsafe blueprint footprint rejected");
        System.out.println("PASS: expedition persistence, no legacy cottages, camp projection/privacy, paid material conversion, food charges, no double construction material fee and footprint bounds.");
    }
}

package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class CourierQuestTest {
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 static Settlement town(String name,int x,String steward){var t=new Settlement(name,"minecraft:overworld",x,64,0);t.colonyReady=true;t.questMasterCitizenId=1;t.residents.put(1,CitizenLifeTest.person(1,steward));return t;}
 public static void main(String[] args){
  String owner=UUID.randomUUID().toString(),stranger=UUID.randomUUID().toString();var from=town("Oakford",0,"Ada");var to=town("Stoneford",4096,"Rowan");int initial=from.treasury;
  var q=CourierQuest.issue(owner,from,to,0);q.validate();check(from.treasury==initial-2 && q.sender.equals("Ada") && q.recipient.equals("Rowan"),"Named dispatch reserves funded reward");
  check(!q.accept(stranger,to,from,to,"outbound") && !q.accept(owner,from,from,to,"outbound") && !q.accept(owner,to,from,to,"return"),"Wrong owner, town and book stage cannot deliver");
  check(q.accept(owner,to,from,to,"outbound") && q.phase.equals("return") && from.regionalTrust.get(to.name)==3 && to.regionalTrust.get(from.name)==3,"Outward delivery builds reciprocal trust");
  check(!q.accept(owner,to,from,to,"outbound") && from.regionalTrust.get(to.name)==3,"Copied letter cannot repeat trust");
  var journey=new PlayerJourney();journey.courier=q;journey.trackedCourier=true;journey.visited.add(from.name);journey.visited.add(to.name);
  journey=new Gson().fromJson(new Gson().toJson(journey),PlayerJourney.class);journey.validate();q=journey.courier;
  var view=JournalData.project(journey,List.of(from,to),null,owner);check(view.mode.equals("courier") && view.dispatchPhase.equals("return") && view.dispatchId.equals(q.id) && view.waypointTown.equals(from.name),"Reload retains return stage and exact journal route");
  from.questRewards.put(owner,4096);check(!q.accept(owner,from,from,to,"return") && q.phase.equals("return"),"Reward queue overflow leaves delivery retryable");from.questRewards.clear();
  check(q.accept(owner,from,from,to,"return") && from.questRewards.get(owner)==2 && from.treasury==initial-2,"Return releases reserved reward exactly once");
  check(!q.accept(owner,from,from,to,"return") && from.questRewards.get(owner)==2,"Copied receipt cannot pay twice");
  from.treasury=0;var unfunded=CourierQuest.issue(owner,from,to,1);check(unfunded.escrow==0 && from.treasury==0,"No unfunded emerald creation");
  System.out.println("PASS: funded correspondence, exact owner/town/stage, replay protection, reciprocal trust, saved return routes and overflow-safe reward completion.");
 }
}

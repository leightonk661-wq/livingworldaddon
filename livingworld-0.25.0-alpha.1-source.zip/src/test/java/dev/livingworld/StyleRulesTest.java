package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class StyleRulesTest {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        Set<String> packs=Set.of("Medieval Oak","Medieval Birch","Medieval Spruce","Urban Savanna","Desert Oasis","Jungle Treehouse","Medieval Dark Oak");
        for(var entry:Map.of("plains","Medieval Oak","birch_forest","Medieval Birch","snowy_taiga","Medieval Spruce","savanna","Urban Savanna","desert","Desert Oasis","jungle","Jungle Treehouse","dark_forest","Medieval Dark Oak").entrySet())
            check(StyleRules.choose("minecraft:"+entry.getKey(),Map.of(),packs).equals(entry.getValue()),"Biome style: "+entry.getKey());
        check(StyleRules.choose("minecraft:forest",Map.of("birch",8,"oak",2),packs).equals("Medieval Birch"),"Local logs disambiguate generic forest");
        check(StyleRules.choose("minecraft:desert",Map.of("oak",9),packs).equals("Desert Oasis"),"Desert climate beats incidental log sample");
        check(StyleRules.choose("mod:unknown",Map.of(),Set.of("Only Installed")).equals("Only Installed"),"Installed-only fallback");
        check(StyleRules.choose("minecraft:plains",Map.of(),Set.of()).isEmpty(),"No installed packs must not invent a style");
        check(StyleRules.next(0).equals("residence") && StyleRules.next(2).equals("farmer") && StyleRules.next(3).equals("warehouse") && StyleRules.next(4).equals("deliveryman") && StyleRules.next(5).equals("residence"),"Expansion sequence continues after initial four buildings");
        var s=new Settlement("Test","minecraft:overworld",0,70,0);s.expansionPack="Medieval Birch";s.governorEnabled=true;
        var e=new Expansion();e.pack=s.expansionPack;e.path="fundamentals/residence1.blueprint";e.kind="residence";e.x=40;e.y=70;s.expansions.add(e);
        var copy=new Gson().fromJson(new Gson().toJson(s),Settlement.class);copy.validate();
        check(copy.expansionPack.equals(s.expansionPack) && copy.expansions.size()==1 && !copy.expansions.get(0).complete,"Saved style and pending reservation survive reload");
        System.out.println("PASS: biome/wood matching, installed-only fallbacks, expansion sequence and persistent reservations.");
    }
}

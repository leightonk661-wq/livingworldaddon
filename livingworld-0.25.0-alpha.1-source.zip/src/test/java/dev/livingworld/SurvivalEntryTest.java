package dev.livingworld;

import com.google.gson.Gson;

public final class SurvivalEntryTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        var gson=new Gson();
        var fresh=new LivingWorld.Save();
        check(fresh.version==17 && fresh.autoFound && !DiscoveryRules.unlocked(fresh.settlements),"New worlds allow discovery only after manual founding");
        var old=gson.fromJson("{\"version\":11,\"autoFound\":false,\"settlements\":[]}",LivingWorld.Save.class);
        check(!old.autoFound,"An existing world's disabled discovery choice must survive migration");
        check(old.charters!=null && old.charters.isEmpty(),"Older saves must receive an empty charter ledger");
        var charter=new VillageCharter("12345678-1234-1234-1234-123456789abc","minecraft:overworld",40,80);
        charter.validate();fresh.charters.put("12345678-1234-1234-1234-123456789abc",charter);
        var restored=gson.fromJson(gson.toJson(fresh),LivingWorld.Save.class);
        check(restored.charters.size()==1 && restored.charters.values().iterator().next().farEnough("minecraft:overworld",296,80),"Issued charter survives a save and permits travel");
        check(!charter.farEnough("minecraft:overworld",295,80) && !charter.farEnough("minecraft:the_nether",296,80),"Founding is blocked near or outside the issuing village dimension");
        charter.villagerId="99999999-1234-1234-1234-123456789abc";charter.validate();
        check(gson.fromJson(gson.toJson(charter),VillageCharter.class).villagerId.equals(charter.villagerId),"A recruited villager identity must survive reload");
        check(charter.matchesToken("12345678-1234-1234-1234-123456789abc"),"Issued token should authorize its book");
        check(!charter.matchesToken("87654321-1234-1234-1234-123456789abc"),"Another book token must not authorize founding");
        var settings=new LivingWorldSettings();settings.maxAutomaticSettlements=100;settings.validate();
        check(settings.maxAutomaticSettlements==16,"Automatic colony limit must stay bounded");
        settings.maxAutomaticSettlements=-1;settings.validate();
        check(settings.maxAutomaticSettlements==0,"Operators can disable automatic colonies in config");
        var town=new Settlement("Oakridge","minecraft:overworld",0,70,0);town.founder="owner";town.automatic=true;town.population=1;
        fresh.settlements.add(town);
        check(!DiscoveryRules.unlocked(fresh.settlements),"An automatically spawned town cannot unlock more expeditions");
        var manual=new Settlement("PlayerTown","minecraft:overworld",400,70,0);manual.expedition=true;manual.automatic=false;
        fresh.settlements.add(manual);
        check(DiscoveryRules.unlocked(fresh.settlements) && DiscoveryRules.unlocked(gson.fromJson(gson.toJson(fresh),LivingWorld.Save.class).settlements),"Manual founding unlocks NPC expeditions across reloads");
        town.recruitId=charter.villagerId;town.journeyMessage="Pioneer walking";
        var loadedTown=gson.fromJson(gson.toJson(town),Settlement.class);loadedTown.validate();
        check(loadedTown.recruitId.equals(town.recruitId) && loadedTown.journeyMessage.equals(town.journeyMessage),"An unfinished physical escort must survive reload");
        check(DashboardData.project(town,"owner",true).people==0,"Travelling pioneer is not yet a resident");
        town.founderSpawned=true;
        check(DashboardData.project(town,"owner",true).people==1,"Pioneer appears in population after arrival");
        check(DashboardData.project(town,"owner",true).founder,"Founder should receive town controls");
        check(!DashboardData.project(town,"visitor",true).founder,"Visitors must not receive founder controls");
        check(DashboardData.project(town,"visitor",true).automatic,"Discovery origin remains visible in the dashboard");
        check(TownAutonomyRules.mayWitnessFounding(loadedTown,"visitor"),"A returning visitor can resume an NPC camp after the discovering player leaves");
        check(TownAutonomyRules.mayPlanNearby(loadedTown,false),"An NPC town can plan around a visitor without MineColonies membership");
        check(!TownAutonomyRules.grantOfficer(loadedTown,"visitor") && !TownAutonomyRules.grantOfficer(loadedTown,"owner"),"Discovering or visiting an NPC town does not grant officer permissions");
        loadedTown.automatic=false;
        check(TownAutonomyRules.mayWitnessFounding(loadedTown,"owner") && !TownAutonomyRules.mayWitnessFounding(loadedTown,"visitor"),"A charter expedition still waits for its founder");
        check(!TownAutonomyRules.mayPlanNearby(loadedTown,false) && TownAutonomyRules.mayPlanNearby(loadedTown,true),"A player-owned town still requires colony membership for planning");
        check(TownAutonomyRules.grantOfficer(loadedTown,"owner") && !TownAutonomyRules.grantOfficer(loadedTown,"visitor"),"Only a charter founder receives officer permissions");
        System.out.println("PASS: discovery, village charters, escorted founding, visitor-woken NPC towns, and founder-only colony permissions.");
    }
}


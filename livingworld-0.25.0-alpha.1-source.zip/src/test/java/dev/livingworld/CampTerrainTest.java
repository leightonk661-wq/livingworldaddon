package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class CampTerrainTest {
    private static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);}
    public static void main(String[] args){
        check(CampTerrain.sameSurfaceSoil("Block{minecraft:dirt}","Block{minecraft:grass_block}[snowy=false]"),"Saved camp's naturally spreading grass must not stop path placement");
        check(CampTerrain.sameSurfaceSoil("Block{minecraft:grass_block}[snowy=true]","Block{minecraft:dirt}"),"Grass dying and snow state changes are harmless");
        for(String protectedBlock:List.of("Block{minecraft:stone}","Block{minecraft:chest}","Block{minecraft:oak_planks}","Block{minecraft:farmland}[moisture=7]")){
            check(!CampTerrain.sameSurfaceSoil("Block{minecraft:dirt}",protectedBlock),"Other replacements remain protected");
            check(!CampTerrain.sameSurfaceSoil(protectedBlock,"Block{minecraft:dirt}"),"Other original blocks cannot become soil silently");
        }
        int[] hill={70,71,72,73,74,75,76};int level=CampTerrain.elevation(hill);
        check(level==73,"Six-block slope has a balanced terrace");
        var changes=CampTerrain.plan(hill,7,1,level);var seen=new HashSet<String>();
        for(var c:changes){
            check(seen.add(c.x()+","+c.y()+","+c.z()),"No duplicate edits");
            check(c.x()>=0 && c.x()<7 && c.z()==0,"Groundwork stays in the surveyed footprint");
            check(c.fill()?c.y()<=level:c.y()>level,"Fill below and clear above the terrace");
        }
        for(int x=0;x<7;x++){
            Set<Integer> solid=new HashSet<>();for(int y=65;y<=hill[x];y++)solid.add(y);
            for(var c:changes)if(c.x()==x){if(c.fill())solid.add(c.y());else solid.remove(c.y());}
            check(Collections.max(solid)==73 && solid.contains(72),"Every column has a grounded, supported floor");
        }
        check(CampTerrain.elevation(new int[]{70,70,70,70})==70,"Flat terrain stays at ground height");
        boolean rejected=false;try{CampTerrain.elevation(new int[]{70,77});}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Cliffs are not silently flattened");
        var p=new SitePlan();p.kind="camp";p.pack="test";p.path="camp";p.width=7;p.depth=1;p.height=4;p.y=74;p.minY=73;
        for(int i=0;i<28;i++)p.before.add("Block{minecraft:air}");
        for(var c:changes)p.groundwork.add(new CampTerrain.Change(c.x(),c.y(),c.z(),c.fill(),"Block{minecraft:stone}"));
        p.groundworkCursor=3;p.validate();var gson=new Gson();var restored=gson.fromJson(gson.toJson(p),SitePlan.class);restored.validate();
        check(restored.groundworkCursor==3 && restored.groundwork.size()==changes.size(),"Partially completed earthworks survive reload");
        var legacy=gson.toJsonTree(p).getAsJsonObject();legacy.remove("groundwork");legacy.remove("groundworkCursor");var old=gson.fromJson(legacy,SitePlan.class);old.validate();check(old.groundwork.isEmpty(),"Older partial camps do not get retroactive earthworks");
        restored.groundwork.getFirst().x=99;rejected=false;try{restored.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Out-of-footprint journal rejected");
        var candidates=new HashSet<String>();for(int i=0;i<48;i++)candidates.add(Arrays.toString(CampSafety.candidate(i)));check(candidates.size()==48,"Survey checks 48 distinct sites before resting");
        System.out.println("PASS: balanced camp terraces, grounded floors, bounded excavation, cliff protection, unique sites and saved earthwork recovery.");
    }
}

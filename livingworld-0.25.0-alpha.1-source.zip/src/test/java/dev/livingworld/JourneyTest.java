package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class JourneyTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        var returning=new PlayerJourney();returning.observe("p",false,true,List.of(),List.of());check(returning.objective().title().equals("Choose your new home"),"Existing charter implies village visit");
        var j=new PlayerJourney();check(j.objective().title().equals("Find a village"),"Spawn starts with exploration");
        j.observe("p",true,false,List.of(),List.of());check(j.objective().title().equals("Recruit a pioneer"),"Village observed");
        j.observe("p",true,true,List.of(),List.of());check(j.objective().title().equals("Choose your new home"),"Charter enables escort guidance");
        var t=new Settlement("Oakford","minecraft:overworld",0,64,0);t.expedition=true;t.automatic=true;t.founder="p";
        j.observe("p",false,false,List.of(t),List.of(t));check(!j.milestones.contains("founded"),"Automatic founding is not personal progress");
        t.automatic=false;j.observe("p",false,false,List.of(t),List.of());check(j.objective().title().equals("Establish camp"),"Manual founding advances objective");
        t.camp=new SitePlan();j.observe("p",false,false,List.of(t),List.of());check(!j.milestones.contains("camp"),"Unbuilt camp does not count");
        t.camp.complete=true;j.observe("p",false,false,List.of(t),List.of());check(j.objective().title().equals("Raise the outpost"),"Completed camp counted");
        check(HintRules.ready(j,"camp",0),"Initial hint permitted");j.lastHint="camp";j.hintAt=0;
        check(!HintRules.ready(j,"camp",6000),"No repeating objective spam");check(!HintRules.ready(j,"home",1199),"Minute cooldown");check(HintRules.ready(j,"home",1200),"Changed objective after cooldown");
        j.hintsEnabled=false;check(!HintRules.ready(j,"home",9000),"Off means off");
        var restored=new Gson().fromJson(new Gson().toJson(j),PlayerJourney.class);restored.validate();check(!restored.hintsEnabled && restored.visited.contains("Oakford") && restored.milestones.contains("camp"),"Journal and settings survive reload");
        check(new Gson().fromJson("{}",PlayerJourney.class).hintsEnabled,"Older saves receive default enabled hints");
        var names=new ArrayList<Settlement>();for(int i=0;i<60;i++){String name=TownNames.next("Spruce",names,Integer.MAX_VALUE);check(name.length()<=24 && names.stream().noneMatch(s->s.name.equalsIgnoreCase(name)),"Names unique and command-safe");names.add(new Settlement(name,"minecraft:overworld",0,64,0));}
        String text="A long journey through villages and fields. ".repeat(30);var pages=BookPages.fit(List.of(text));check(pages.stream().allMatch(s->s.length()<=180),"Pages bounded");check(String.join(" ",pages).replaceAll("\\s+"," ").trim().equals(text.trim()),"Page splits preserve words");
        var town=new Settlement("QuestTown","minecraft:overworld",0,70,0);town.expedition=true;town.colonyReady=true;town.colonyId=1;town.food=20;town.wood=300;town.stone=300;town.treasury=5;
        TownQuests.offer(town,1000);TownQuests.acceptDrop(town,"a",12,1001);var q=town.quest;TownQuests.acceptDrop(town,"b",4,1002);
        check(town.relation("a")==4 && town.relation("b")==1 && town.questRewards.getOrDefault("a",0)==1 && !town.questRewards.containsKey("b"),"Shared credit and largest contributor reward");
        check(TownQuests.rewardRecipient(q,"b").equals("a"),"Final item does not steal reward");
        var saved=new Gson().fromJson(new Gson().toJson(town),Settlement.class);check(saved.questRewards.get("a")==1,"Unclaimed reward survives reload");
        System.out.println("PASS: journey milestones, quiet hint cooldowns, persistence, town names, readable book pages and shared quest rewards.");
    }
}

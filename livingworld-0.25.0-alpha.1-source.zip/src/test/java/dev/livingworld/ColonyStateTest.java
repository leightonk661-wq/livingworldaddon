package dev.livingworld;
import com.google.gson.Gson;
public final class ColonyStateTest {
    private static void check(boolean b,String why) {if(!b) throw new AssertionError(why);}
    public static void main(String[] args) {
        var s=new Settlement("Oakridge","minecraft:overworld",0,70,0);
        s.colonyId=7;s.colonyOwner="12345678-1234-1234-1234-123456789012";
        var before=new Gson().toJson(s);
        for(int i=0;i<400;i++)s.step();
        check(new Gson().toJson(s).equals(before),"A partially activated colony cannot also simulate economy or construction");
        s.colonyReady=true;
        var restored=new Gson().fromJson(new Gson().toJson(s),Settlement.class);restored.validate();
        check(restored.colonyId==7 && restored.colonyReady && restored.colonyOwner.equals(s.colonyOwner),"Colony identity persists");
        restored.colonyId=0;boolean rejected=false;
        try {restored.validate();}catch(IllegalArgumentException e){rejected=true;}
        check(rejected,"Cannot load completed activation with missing colony ID");
        System.out.println("PASS: activation freezes simulation, persists colony identity, and rejects invalid linkage.");
    }
}

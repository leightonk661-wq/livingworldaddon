package dev.livingworld;
import com.google.gson.Gson;
import java.util.HashSet;
import java.util.Set;
public final class TerrainPlanTest {
    static void check(boolean b,String why) {if(!b) throw new AssertionError(why);}
    public static void main(String[] args) {
        var p=new HousePlan();p.x=10;p.y=70;p.z=-20;
        Set<String> positions=new HashSet<>();
        for(int y=-2;y<=6;y++) for(int x=-3;x<=3;x++) for(int z=-3;z<=3;z++) {
            String target=HousePlan.blockAt(x,y,z);
            p.cells.add(new HousePlan.Cell(p.x+x,p.y+y,p.z+z,"Block{minecraft:air}",target));
            check(positions.add(x+","+y+","+z),"No duplicate placement coordinates");
        }
        p.validate();
        check(HousePlan.blockAt(0,1,-3).equals("minecraft:air"),"Doorway stays open");
        check(HousePlan.blockAt(0,2,0).equals("minecraft:air"),"Walkable interior");
        check(HousePlan.blockAt(0,-1,0).equals("minecraft:cobblestone"),"Foundation below floor");
        check(HousePlan.blockAt(0,6,0).equals("minecraft:oak_planks"),"Roof ridge exists");
        check(p.target(0,1,0)==p.cells.size(),"Completed home materializes fully");
        check(p.target(1,1,20)==p.cells.size()/2,"Partial home uses saved progress");
        check(p.target(2,1,20)==0,"Future homes stay unbuilt");
        int last=0;for(int i=0;i<40;i++){int next=p.target(1,1,i);check(next>=last,"Progress monotonic");last=next;}
        p.cursor=125;p.blocked="Player changed terrain";
        var copy=new Gson().fromJson(new Gson().toJson(p),HousePlan.class);copy.validate();
        check(copy.cursor==125 && copy.blocked.equals(p.blocked) && copy.cells.equals(p.cells),"Placement journal survives reload");
        var town=new Settlement("Test","minecraft:overworld",0,70,0);town.plots.add(copy);town.surveyed=true;
        town.pendingDeparture=true;town.step();check(town.cycles==0,"Automatic town waits until departure");
        town.pendingDeparture=false;for(int i=0;i<1000;i++) town.step();check(town.homes==1,"Growth respects reserved plot capacity");
        var legacy=new Gson().fromJson("{\"name\":\"Old\",\"dimension\":\"minecraft:overworld\",\"homes\":1,\"population\":4,\"reputation\":{},\"alliances\":{}}",Settlement.class);
        legacy.validate();check(legacy.plots.isEmpty(),"Old saves gain empty plots");
        System.out.println("PASS: cottage geometry, foundations, construction stages, unique cells, saved cursor, pending settlement and plot-limited growth.");
    }
}

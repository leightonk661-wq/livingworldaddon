package dev.livingworld;
import com.google.gson.Gson;
public final class PioneerHandoffTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        var town=new Settlement("Test","minecraft:overworld",0,70,0);town.expedition=true;
        var charter=new VillageCharter("12345678-1234-1234-1234-123456789abc","minecraft:overworld",100,200);
        charter.villagerId="99999999-1234-1234-1234-123456789abc";charter.lastX=2;charter.lastZ=4;
        PioneerHandoff.link(town,charter);check(town.recruitId.equals(charter.villagerId) && town.recruitX==2 && town.recruitZ==4 && !town.journeyComplete,"Founding must transfer the charter recruit, not leave a following charter behind");
        check(!PioneerHandoff.ready(town,true,true),"No conversion before camp completion");town.camp=new SitePlan();town.camp.kind="camp";town.camp.pack="Medieval Oak";town.camp.path="decorations/supplies/camp.blueprint";town.camp.width=town.camp.height=town.camp.depth=1;town.camp.complete=true;
        check(!PioneerHandoff.ready(town,true,true),"No deletion before citizen creation");town.founderSpawned=true;
        check(!PioneerHandoff.ready(town,false,true),"Recruit must physically reach camp");
        check(!PioneerHandoff.ready(town,true,false),"An unloaded or failed native spawn must not consume recruit");
        check(PioneerHandoff.ready(town,true,true),"One successful handoff when both actors are present");
        town.pioneerName="Rowan";town.pioneerCitizenId=7;
        var saved=new Gson().fromJson(new Gson().toJson(town),Settlement.class);saved.validate();
        check(saved.pioneerCitizenId==7 && saved.pioneerName.equals("Rowan") && saved.recruitId.equals(charter.villagerId),"Interrupted handoff retains native citizen identity and recruit name");
        town.journeyComplete=true;check(!PioneerHandoff.ready(town,true,true),"Completed handoff cannot run twice");
        try{PioneerHandoff.link(town,charter);throw new AssertionError("Linked a second recruit");}catch(IllegalArgumentException expected){}
        var automatic=new Settlement("Auto","minecraft:overworld",0,70,0);automatic.expedition=true;automatic.automatic=true;
        try{PioneerHandoff.link(automatic,charter);throw new AssertionError("Recruit attached to independent town");}catch(IllegalArgumentException expected){}
        System.out.println("PASS: charter-to-town handoff, physical arrival, failed-spawn protection, citizen identity persistence and single conversion.");
    }
}

package dev.livingworld;
public final class BuildPriorityTest {
    static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
    static void add(Settlement s,String kind,boolean done){var e=new Expansion();e.kind=kind;e.complete=done;s.expansions.add(e);}
    public static void main(String[] args){
        LivingWorldSettings.current=new LivingWorldSettings();var s=new Settlement("Test","minecraft:overworld",0,70,0);s.wood=s.stone=s.food=512;s.treasury=100;
        check(BuildPriority.roadDelay(s).contains("housing"),"Roads cannot precede first housing");add(s,"residence",true);
        check(BuildPriority.roadDelay(s).contains("food production"),"Roads cannot precede farming");add(s,"farmer",true);
        check(BuildPriority.roadDelay(s).contains("Next building"),"Affordable expansion outranks roads");
        s.wood=0;check(BuildPriority.roadDelay(s).isEmpty(),"Roads can use surplus stone while saving wood for expansion");
        s.stone=20;check(BuildPriority.roadDelay(s).contains("stone"),"Paving cannot exhaust construction reserve");s.stone=512;
        add(s,"warehouse",false);check(BuildPriority.roadDelay(s).contains("Finish buildings"),"Any unfinished building preempts paving");s.expansions.getLast().complete=true;
        var p=new DistantProject();s.distantProjects.add(p);check(BuildPriority.roadDelay(s).contains("Distant"),"Funded queue preempts paving");s.distantProjects.clear();
        s.food=0;check(BuildPriority.roadDelay(s).contains("food reserves"),"Shortages outrank roads");
        System.out.println("PASS: housing, farms, unfinished buildings, distant queue and survival outrank paving; surplus-only paving remains available.");
    }
}

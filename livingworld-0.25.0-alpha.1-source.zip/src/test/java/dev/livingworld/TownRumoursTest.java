package dev.livingworld;
import java.util.*;
public final class TownRumoursTest {
    static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);}
    public static void main(String[] args){
        var a=new Settlement("Oak_Town","minecraft:overworld",0,70,0);a.colonyReady=true;
        check(TownRumours.withinRange(a.dimension,128.5,70,.5,a),"128 boundary included");
        check(!TownRumours.withinRange(a.dimension,129.5,70,.5,a),"Outside rejected");
        check(!TownRumours.withinRange("minecraft:the_nether",.5,70,.5,a),"Dimensions isolated");
        check(TownRumours.villageLoot("minecraft:chests/village/village_plains_house") && !TownRumours.villageLoot("minecraft:chests/simple_dungeon"),"Village loot only");
        var planned=new Settlement("Not_Built",a.dimension,5,70,5);
        var other=new Settlement("Other_Dimension","minecraft:the_nether",0,70,0);other.colonyReady=true;
        var far=new Settlement("Too_Far",a.dimension,9000,70,0);far.colonyReady=true;
        var camp=new Settlement("Camp",a.dimension,100,70,0);camp.camp=new SitePlan();camp.camp.complete=true;
        var pages=TownRumours.pages(List.of(far,other,planned,camp,a),a.dimension,0,0);
        check(pages.size()==3 && pages.get(1).contains("Oak Town") && pages.get(2).contains("supply camp"),"Nearest established towns only");
        check(!pages.toString().contains("Not Built") && !pages.toString().contains("Too Far") && !pages.toString().contains("Other Dimension"),"No fake or unreachable reports");
        check(TownRumours.direction(0,-1).equals("north") && TownRumours.direction(1,0).equals("east") && TownRumours.direction(-1,1).equals("south-west"),"Compass directions");
        check(TownRumours.pages(List.of(planned),a.dimension,0,0).getFirst().contains("No confirmed"),"Honest empty world report");
        check(TownRumours.pages(List.of(a,a,a,a,a),a.dimension,0,0).size()==4,"Book capped at three destinations");
        System.out.println("PASS: 128-block boundary, dimension checks, village-only loot, established-town selection, ordering, book cap and compass directions.");
    }
}

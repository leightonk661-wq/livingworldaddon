package dev.livingworld;
import java.util.*;
import com.google.gson.Gson;
public final class JournalDataTest {
    private static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);}
    public static void main(String[] args){
        var state=new PlayerJourney();var first=JournalData.project(state,List.of(),null);
        check(first.requirements.size()==1 && first.requirements.getFirst().item().equals("minecraft:emerald") && first.requirements.getFirst().amount()==4,"Initial checklist requires recruitment cost");
        var charter=new VillageCharter("12345678-1234-1234-1234-123456789abc","minecraft:overworld",100,200);
        var data=JournalData.project(state,List.of(),charter);
        check(data.requirements.size()==4 && data.requirements.getFirst().exactCharter() && data.charterToken.equals(charter.token),"Only matching charter counts");
        check(data.requirements.get(1).amount()==32 && data.requirements.get(2).amount()==32 && data.requirements.get(3).amount()==16,"Founding kit matches consumed materials");
        var req=data.requirements.get(1);check(!JournalData.ready(req,31) && JournalData.ready(req,32) && !JournalData.ready(req,0),"Checks reflect inventory gaining and losing items");
        state.milestones.add("founded");check(JournalData.project(state,List.of(),null).requirements.isEmpty(),"Founding removes obsolete kit checklist");
        var town=new Settlement("Pineford","minecraft:overworld",42,70,64);town.food=20;town.wood=300;town.stone=300;town.treasury=4;town.expedition=true;town.colonyReady=true;town.colonyId=1;TownQuests.offer(town,1000);
        state.trackedQuest=town.quest.id;TownQuests.acceptDrop(town,"p",5,1001);
        data=JournalData.project(state,List.of(town),null);req=data.requirements.getFirst();
        check(data.mode.equals("quest") && req.delivered()==5 && JournalData.remaining(req)==11,"Quest distinguishes delivered from carried");
        check(!JournalData.ready(req,10) && JournalData.ready(req,11) && town.quest!=null,"Enough in inventory is readiness, not quest completion");
        var roundTrip=new Gson().fromJson(new Gson().toJson(data),JournalData.class);check(roundTrip.requirements.getFirst().delivered()==5,"Transport round trip retains shared delivery progress");
        TownQuests.acceptDrop(town,"p",11,1002);check(JournalData.project(state,List.of(town),null).mode.equals("journey"),"Completed tracked request falls back to journey");
        state.checklistEnabled=false;var restored=new Gson().fromJson(new Gson().toJson(state),PlayerJourney.class);restored.validate();check(!restored.checklistEnabled && restored.trackedQuest.equals(state.trackedQuest),"Tracked request and HUD preference persist");
        check(new Gson().fromJson("{}",PlayerJourney.class).checklistEnabled,"Old journeys get default checklist setting");
        state.visited.add(town.name);data=JournalData.project(state,List.of(town),null);check(data.places.size()==1 && data.places.getFirst().contains("42, 70, 64"),"Visited places show actual coordinates");
        System.out.println("PASS: journal checklist targets, exact charter identity, inventory checks, partial delivery projection, completed requests, transport and persistence.");
    }
}

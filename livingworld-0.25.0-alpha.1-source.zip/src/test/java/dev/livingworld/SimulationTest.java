package dev.livingworld;
import com.google.gson.Gson;
public final class SimulationTest {
    static void check(boolean value,String message) { if(!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        var s=new Settlement("Oakridge","minecraft:overworld",0,64,0);
        s.supply("a","wood",64); s.supply("a","stone",32);
        check(s.relation("a")==12 && s.relation("b")==0,"Independent player reputation");
        s.step(); check(s.progress==1 && s.homes==1,"Construction pays before progressing");
        for(int i=0;i<38;i++) s.step(); check(s.homes==1,"No instant construction");
        s.step(); check(s.homes==2,"Construction completes after 40 cycles");
        boolean rejected=false; try{s.supply("a","wood",-1);}catch(IllegalArgumentException e){rejected=true;}
        check(rejected,"Negative supplies rejected");
        rejected=false; try{s.ally("b");}catch(IllegalArgumentException e){rejected=true;}
        check(rejected,"Alliance requires reputation");
        s.reputation.put("a",40);s.ally("a");
        var restored=new Gson().fromJson(new Gson().toJson(s),Settlement.class);restored.validate();
        check(restored.alliances.get("a") && restored.homes==2 && restored.relation("b")==0,"Save round trip");
        for(int i=0;i<100000;i++) restored.step(); restored.validate();
        check(restored.homes==8 && restored.population<=32,"Growth and stock caps");
        long start=System.nanoTime();
        var settlements=new Settlement[32]; for(int i=0;i<32;i++) settlements[i]=new Settlement("Town"+i,"minecraft:overworld",0,64,0);
        for(int i=0;i<100000;i++) for(var town:settlements) town.step();
        System.out.println("PASS: economy, growth timing, reputation isolation, alliance gating, persistence and bounds.");
        System.out.println("3.2 million background steps: "+((System.nanoTime()-start)/1000000)+" ms (synthetic model only, not Minecraft performance).");
    }
}

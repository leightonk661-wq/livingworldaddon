package dev.livingworld;

import java.util.List;

/** NPC expeditions begin only after a player has founded a real expedition in this world. */
public final class DiscoveryRules {
    private DiscoveryRules(){}
    public static boolean unlocked(List<Settlement> towns){
        return towns!=null && towns.stream().anyMatch(s->s!=null && s.expedition && !s.automatic);
    }
}

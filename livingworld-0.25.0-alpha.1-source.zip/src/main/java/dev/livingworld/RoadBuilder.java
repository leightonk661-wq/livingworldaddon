package dev.livingworld;
import com.ldtteam.structurize.api.RotationMirror;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.blueprints.v1.BlueprintUtil;
import com.ldtteam.structurize.storage.StructurePacks;
import com.minecolonies.api.colony.IColonyManager;
import com.minecolonies.api.colony.workorders.WorkOrderType;
import com.minecolonies.core.colony.workorders.WorkOrderDecoration;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.*;
import java.util.*;

/** Roads are actual paid native builder jobs, submitted in small, recoverable segments. */
public final class RoadBuilder {
    private int clock,turn;
    public void reset(){clock=turn=0;}
    public static boolean pending(Settlement s){return s.roads.stream().anyMatch(r->!r.complete);}
    public static void yieldToBuildings(Settlement s,com.minecolonies.api.colony.IColony colony,Runnable save){
        String reason=BuildPriority.roadDelay(s);if(reason.isEmpty())return;
        String pack="LivingWorldRoads_"+s.colonyOwner.substring(0,8);boolean changed=false;
        for(var order:new ArrayList<>(colony.getWorkManager().getWorkOrders().values())){
            if(!(order instanceof com.minecolonies.api.colony.workorders.IBuilderWorkOrder work) || !pack.equals(work.getStructurePack()))continue;
            for(var road:s.roads){
                String path="road_"+road.id+"_"+road.cursor+".blueprint";
                if(!road.complete && path.equals(work.getStructurePath())){
                    colony.getWorkManager().removeWorkOrder(order);road.issued=false;road.retryAt=0;road.status="Low priority: "+reason;changed=true;break;
                }
            }
        }
        if(changed)save.run();
    }
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save){
        if(++clock<40 || towns.isEmpty())return;clock=0;
        var s=towns.get(Math.floorMod(turn++,towns.size()));
        if(!s.governorEnabled || !s.colonyReady || !pending(s) || s.starterSites.stream().anyMatch(p->!p.complete))return;
        var r=s.roads.stream().filter(p->!p.complete).findFirst().orElseThrow();
        try{
            for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(s.dimension)){
                if(level.players().stream().noneMatch(p->p.distanceToSqr(s.x,s.y,s.z)<192*192))return;
                if(level.getGameTime()<r.retryAt)return;
                var c=ColonyBridge.colony(s,level);yieldToBuildings(s,c,save);
                String delay=BuildPriority.roadDelay(s);if(!delay.isEmpty()){r.status="Low priority: "+delay;return;}
                var builder=c.getServerBuildingManager().getBuildings().get(ColonyBridge.builderHut(s));
                if(builder==null || builder.getBuildingLevel()<1){r.status="Waiting for a completed builder hut";return;}
                int end=Math.min(r.points.size(),r.cursor+12);if(end==r.cursor){r.complete=true;save.run();return;}
                var segment=r.points.subList(r.cursor,end);boolean finished=true;
                for(var p:segment){
                    var chunk=level.getChunkSource().getChunkNow(p.x()>>4,p.z()>>4);if(chunk==null){r.status="Waiting for loaded approach chunks";return;}
                    var pos=new BlockPos(p.x(),p.y(),p.z());
                    if(!chunk.getBlockState(pos).is(Blocks.COBBLESTONE) || !FoundingEngine.soft(chunk.getBlockState(pos.above())) || !FoundingEngine.soft(chunk.getBlockState(pos.above(2))))finished=false;
                }
                String pack="LivingWorldRoads_"+s.colonyOwner.substring(0,8);
                String file="road_"+r.id+"_"+r.cursor+".blueprint";
                var existing=c.getWorkManager().getWorkOrders().values().stream().filter(w->w instanceof com.minecolonies.api.colony.workorders.IBuilderWorkOrder)
                    .map(w->(com.minecolonies.api.colony.workorders.IBuilderWorkOrder)w).filter(w->pack.equals(w.getStructurePack()) && file.equals(w.getStructurePath())).findFirst();
                if(existing.isPresent()){if(!r.issued){r.issued=true;save.run();}r.status="Builder paving approach: "+r.cursor+" / "+r.points.size()+" blocks complete";return;}
                if(finished){r.cursor=end;r.issued=false;r.activePath="";r.complete=end==r.points.size();r.status=r.complete?"Approach complete":"Next approach segment";save.run();return;}
                if(r.issued){r.status="Approach work order ended before completion; inspect site, then Retry paths";return;}
                if(!c.getWorkManager().getWorkOrders().isEmpty()){r.status="Waiting for the builder's current job";return;}
                int minX=segment.stream().mapToInt(RouteSearch.Point::x).min().orElseThrow(),maxX=segment.stream().mapToInt(RouteSearch.Point::x).max().orElseThrow();
                int minZ=segment.stream().mapToInt(RouteSearch.Point::z).min().orElseThrow(),maxZ=segment.stream().mapToInt(RouteSearch.Point::z).max().orElseThrow();
                int minY=segment.stream().mapToInt(RouteSearch.Point::y).min().orElseThrow(),maxY=segment.stream().mapToInt(RouteSearch.Point::y).max().orElseThrow()+2;
                // Native tape/path calculations also need neighbouring chunks. Never load them here.
                for(int x=(minX-16)>>4;x<=(maxX+16)>>4;x++)for(int z=(minZ-16)>>4;z<=(maxZ+16)>>4;z++)if(level.getChunkSource().getChunkNow(x,z)==null){r.status="Load the terrain around this approach";return;}
                for(int i=r.cursor;i<end;i++){
                    var p=r.points.get(i);var pos=new BlockPos(p.x(),p.y(),p.z());var state=level.getBlockState(pos);
                    var claim=IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),pos);
                    if(claim!=null && claim.getID()!=s.colonyId){r.status="Approach now crosses another colony; preserved";return;}
                    if((!state.toString().equals(r.ground.get(i)) && !state.is(Blocks.COBBLESTONE)) || level.getBlockEntity(pos)!=null
                        || !FoundingEngine.soft(level.getBlockState(pos.above())) || !FoundingEngine.soft(level.getBlockState(pos.above(2)))){r.status="Approach changed at "+pos.toShortString()+"; preserved";return;}
                }
                if(s.stone<segment.size()){r.status="Waiting for "+segment.size()+" stone for the next approach segment";return;}
                var bp=new Blueprint((short)(maxX-minX+1),(short)(maxY-minY+1),(short)(maxZ-minZ+1),level.registryAccess());
                var keep=BuiltInRegistries.BLOCK.getValue(Identifier.parse("structurize:blocksubstitution")).defaultBlockState();
                for(int x=0;x<bp.getSizeX();x++)for(int y=0;y<bp.getSizeY();y++)for(int z=0;z<bp.getSizeZ();z++)bp.addBlockState(new BlockPos(x,y,z),keep);
                for(var p:segment){var local=new BlockPos(p.x()-minX,p.y()-minY,p.z()-minZ);bp.addBlockState(local,Blocks.COBBLESTONE.defaultBlockState());bp.addBlockState(local.above(),Blocks.AIR.defaultBlockState());bp.addBlockState(local.above(2),Blocks.AIR.defaultBlockState());}
                bp.setCachePrimaryOffset(BlockPos.ZERO);bp.setName("Settlement approach");bp.setFileName(file);bp.setPackName(pack);
                Path folder=server.getWorldPath(LevelResource.ROOT).resolve("livingworld-structures").resolve(pack);Files.createDirectories(folder);
                if(!Files.exists(folder.resolve("pack.json"))){
                    var meta=new com.google.gson.JsonObject();meta.addProperty("name",pack);meta.addProperty("version","1");meta.addProperty("pack-format","1");meta.addProperty("desc","Living World approach paths");meta.addProperty("icon","");
                    var authors=new com.google.gson.JsonArray();authors.add("Living World");meta.add("authors",authors);var mods=new com.google.gson.JsonArray();mods.add("minecolonies");mods.add("structurize");meta.add("mods",mods);
                    Files.writeString(folder.resolve("pack.json"),meta.toString());
                }
                try(var out=Files.newOutputStream(folder.resolve(file))){BlueprintUtil.writeToStream(out,bp);}
                if(StructurePacks.getStructurePack(pack)==null)StructurePacks.discoverPackAtPath(folder,false,List.of("minecraft","minecolonies","structurize","livingworld"),false,"livingworld");
                if(StructurePacks.getStructurePack(pack)==null)throw new IllegalStateException("Approach pack could not be registered");
                r.activePath=file;save.run();
                var order=WorkOrderDecoration.create(WorkOrderType.BUILD,pack,file,"Settlement approach",new BlockPos(minX,minY,minZ),RotationMirror.NONE,0);
                order.setClaimedBy(builder.getPosition());order.setBlueprint(bp,level);
                c.getWorkManager().addWorkOrder(order,false);
                if(!c.getWorkManager().getWorkOrders().containsValue(order)){r.status="MineColonies refused the approach order; checking again in one minute";r.retryAt=level.getGameTime()+1200;save.run();return;}
                r.issued=true;r.retryAt=0;r.status="Approach queued; materials are paid when delivered";save.run();return;
            }
        }catch(Exception e){r.status="Approach paused: "+DashboardData.clip(e.getMessage());s.governorEnabled=false;save.run();org.slf4j.LoggerFactory.getLogger("livingworld").error("Approach construction stopped",e);}
    }
}

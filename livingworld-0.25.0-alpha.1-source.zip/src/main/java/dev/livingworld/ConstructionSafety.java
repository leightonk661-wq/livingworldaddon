package dev.livingworld;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ExperienceOrb;
/** Loose excavation drops cannot obstruct construction. All other entities remain protected. */
public final class ConstructionSafety {
    public static boolean blocksWork(Entity entity){
        return blocksWorkType(entity.getClass());
    }
    static boolean blocksWorkType(Class<? extends Entity> type){
        return !ItemEntity.class.isAssignableFrom(type) && !ExperienceOrb.class.isAssignableFrom(type);
    }
}

package dev.livingworld;
/** Objectives are shown once per change, never on a repeating timer. */
public final class HintRules {
    public static boolean ready(PlayerJourney state,String key,long now){
        return state.hintsEnabled && !key.equals(state.lastHint) && (now<state.hintAt || now-state.hintAt>=1200);
    }
}

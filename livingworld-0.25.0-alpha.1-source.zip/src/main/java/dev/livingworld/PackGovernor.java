package dev.livingworld;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.minecolonies.api.colony.IColonyManager;
import com.minecolonies.api.tileentities.AbstractTileEntityColonyBuilding;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.storage.StructurePacks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import java.io.InputStreamReader;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public final class PackGovernor {
    private static final Map<String,Map<String,String>> CATALOG;
    static {
        try(var in=new InputStreamReader(Objects.requireNonNull(PackGovernor.class.getResourceAsStream("/livingworld-pack-catalog.json")),java.nio.charset.StandardCharsets.UTF_8)) {
            CATALOG=new Gson().fromJson(in,new TypeToken<Map<String,Map<String,String>>>(){}.getType());
        }catch(Exception e){throw new IllegalStateException("Missing pack catalogue",e);}
    }
    private int clock,turn;
    private Job job;
    private static final class Job {
        Settlement s;ServerLevel level;ServerPlayer player;String kind,path,pack;DistantProject distant;List<String> before=new ArrayList<>();
        CompletableFuture<Blueprint> future;Blueprint blueprint;AccessSurvey access;int anchorGround;int x,z,y,minX,minY,minZ,columns,cursor,ticks,low=Integer.MAX_VALUE,high=Integer.MIN_VALUE;
    }
    public void reset(){job=null;clock=turn=0;}
    public static int[] candidate(int attempt){
        int index=Math.floorMod(attempt,TerrainRules.SEARCH_SITES+16);
        if(index<TerrainRules.SEARCH_SITES)return TerrainRules.candidate(index);
        int i=index-TerrainRules.SEARCH_SITES;int[][] dirs={{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
        return new int[]{dirs[i%8][0]*(80+40*(i/8)),dirs[i%8][1]*(80+40*(i/8))};
    }
    public int[] workTarget(Settlement s){return job!=null && job.s==s?new int[]{job.x,job.z}:null;}
    public static Set<String> available(){var result=new TreeSet<String>();for(var p:StructurePacks.getPackMetas())if(CATALOG.containsKey(p.getName()))result.add(p.getName());return result;}
    public static void select(Settlement s,ServerLevel level) {
        if(s.expansionPack!=null && !s.expansionPack.isEmpty())return;
        if(level.getChunkSource().getChunkNow(s.x>>4,s.z>>4)==null)return;
        String biome=level.getBiome(new BlockPos(s.x,s.y,s.z)).unwrapKey().map(k->k.identifier().toString()).orElse("unknown");
        Map<String,Integer> woods=new HashMap<>();
        for(int dx=-16;dx<=16;dx+=8)for(int dz=-16;dz<=16;dz+=8){
            var chunk=level.getChunkSource().getChunkNow((s.x+dx)>>4,(s.z+dz)>>4);if(chunk==null)continue;
            int top=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,s.x+dx,s.z+dz);
            for(int dy=0;dy<12;dy++){
                String id=BuiltInRegistries.BLOCK.getKey(chunk.getBlockState(new BlockPos(s.x+dx,top-dy,s.z+dz)).getBlock()).getPath();
                if(!id.endsWith("_log"))continue;
                String type=id.contains("dark_oak")?"dark":id.contains("spruce")?"spruce":id.contains("birch")?"birch":id.contains("acacia")?"acacia":id.contains("jungle")?"jungle":"oak";
                woods.merge(type,1,Integer::sum);
            }
        }
        s.expansionPack=StyleRules.choose(biome,woods,available());s.styleReason="Biome "+biome+"; nearby sampled logs "+woods;
    }
    public static void override(Settlement s,String pack){
        if(s.expedition && s.camp!=null && !s.colonyReady)throw new IllegalArgumentException("Finish the expedition starter sites before changing style.");
        if(!available().contains(pack))throw new IllegalArgumentException("Unknown or unsupported installed pack. Use /livingworld styles.");
        if(!s.distantProjects.isEmpty())throw new IllegalArgumentException("Finish funded distant projects before changing style.");
        if(s.expansions.stream().anyMatch(e->!e.complete))throw new IllegalArgumentException("Finish the current expansion before changing style.");
        s.expansionPack=pack;s.styleReason="Manual override";
    }
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save,WorkChunkLoader chunks){
        if(job!=null){
            try{scan(save,chunks);}catch(Exception e){job.s.governorMessage="Survey stopped: "+e.getMessage();job.s.governorEnabled=false;org.slf4j.LoggerFactory.getLogger("livingworld").error("Expansion survey failed",e);job=null;}
            return;
        }
        if(++clock<40 || towns.isEmpty())return;clock=0;
        var s=towns.get(Math.floorMod(turn++,towns.size()));if(!s.governorEnabled || !s.colonyReady)return;
        try{
            ServerLevel level=null;for(var l:server.getAllLevels())if(l.dimension().identifier().toString().equals(s.dimension)){level=l;break;}
            if(level==null)return;
            if(level.players().stream().noneMatch(p->p.distanceToSqr(s.x,s.y,s.z)<192*192) && !chunks.activeFor(s))return;
            var colony=ColonyBridge.colony(s,level);
            ServerPlayer player=null;for(var p:level.players())if(p.distanceToSqr(s.x,s.y,s.z)<192*192 && TownAutonomyRules.mayPlanNearby(s,colony.getPermissions().isColonyMember(p))){player=p;break;}
            if(player==null && DistantProgress.ready(s)!=null && !chunks.activeFor(s))for(var visitor:level.players())if(visitor.distanceToSqr(s.x,s.y,s.z)<192*192){player=visitor;break;}
            if(player==null && !(chunks.activeFor(s) && DistantProgress.ready(s)!=null) && s.expansions.stream().noneMatch(e->!e.complete)){s.governorMessage=s.automatic?"Waiting for a player near the town":"Waiting for a colony member nearby";return;}
            RoadBuilder.yieldToBuildings(s,colony,save);
            select(s,level);
            if(s.expansionPack==null || !CATALOG.containsKey(s.expansionPack) || !available().contains(s.expansionPack)){s.governorMessage="Selected pack unavailable";return;}
            if(s.expedition){
                for(var site:s.starterSites){
                    var b=colony.getServerBuildingManager().getBuildings().get(ColonyBridge.sitePos(site));
                    if(b==null)throw new IllegalArgumentException("Starter hut missing; preserved site reservation");
                    site.complete=b.getBuildingLevel()>=1 && b.isBuilt() && !b.isPendingConstruction();
                    if(!site.complete){
                        s.governorMessage="Automatic starter assembly: "+site.kind;return;
                    }
                }
            }
            if(player!=null || chunks.activeFor(s)){
                recruit(s,level,colony);
                ColonyWorkforce.assign(s,colony,level);
            }
            for(var e:s.expansions)if(!e.complete){
                if(e.assembly!=null){s.governorMessage="Protected automatic completion of "+e.kind;return;}
                var b=colony.getServerBuildingManager().getBuildings().get(new BlockPos(e.x,e.y,e.z));
                if(b==null){s.governorMessage="Reserved hut missing; stopped to avoid a duplicate";s.governorEnabled=false;return;}
                if(b.getBuildingLevel()>=1 && b.isBuilt() && !b.isPendingConstruction()){e.complete=true;TownProgress.record(s,"Completed "+e.kind);save.run();}
                else {
                    if(player==null){s.governorMessage="Loaded native construction; builder continues its existing order";return;}
                    if(!b.isPendingConstruction())b.requestUpgradeTo(player,ColonyBridge.builderHut(s),1);
                    s.governorMessage=b.isPendingConstruction()?"Builder working on "+e.kind:"Work order refused for "+e.kind+"; inspect hut";return;
                }
            }
            if(colony.getServerBuildingManager().getBuildings().values().stream().anyMatch(b->b.isPendingConstruction())){s.governorMessage="Waiting for existing colony work orders";return;}
            s.economyPopulation=colony.getCitizenManager().getCurrentCitizenCount();
            var distant=DistantProgress.ready(s);
            if(distant==null && !s.distantProjects.isEmpty()){s.governorMessage="Preparing funded distant project: "+s.distantMessage;return;}
            String next=distant==null?Economy.next(s):distant.kind;
            if(next==null){s.governorMessage="Capital plan complete; maintaining existing buildings";return;}
            if(distant==null && !Economy.affordable(s,next)){s.governorMessage="Saving for "+next+": "+Economy.planningCost(s,next)+" plus food reserve "+Economy.reserve(s);return;}
            if(s.expansions.size()>=LivingWorldSettings.current.maxExpansions && distant==null){s.governorMessage="Reached the configured expansion limit";return;}
            var j=new Job();j.s=s;j.level=level;j.player=player;j.distant=distant;j.pack=distant==null?s.expansionPack:distant.pack;j.kind=next;
            if(!CATALOG.containsKey(j.pack) || !available().contains(j.pack)){s.governorMessage="Waiting for funded project pack: "+j.pack;return;}
            j.path=CATALOG.get(j.pack).get(j.kind);
            if(level.getGameTime()<s.nextSurveyTick)return;
            boolean found=false;
            for(int n=0;n<TerrainRules.SEARCH_SITES+16;n++){
                int[] offset=candidate(s.siteAttempt++);
                j.x=(s.camp==null?s.x:s.camp.x)+offset[0];j.z=(s.camp==null?s.z:s.camp.z)+offset[1];
                if(!SurveyMemory.blocked(s,j.pack,j.kind,j.x,j.z,level.getGameTime())){found=true;break;}
            }
            if(!found){s.nextSurveyTick=level.getGameTime()+100;s.governorMessage="Waiting for failed-site cooldowns";return;}
            j.future=StructurePacks.getBlueprintFuture(j.pack,j.path,level.registryAccess());
            job=j;s.governorMessage="Surveying "+j.kind+" site at "+j.x+", "+j.z;
        }catch(Exception e){s.governorEnabled=false;s.governorMessage="Paused: "+e.getMessage();org.slf4j.LoggerFactory.getLogger("livingworld").error("Governor paused",e);}
    }
    private void reject(String why){job.s.governorMessage="Seeking another site: "+why;SurveyMemory.reject(job.s,job.pack,job.kind,job.x,job.z,job.level.getGameTime(),why);job=null;}
    private static boolean soft(BlockState b){return FoundingEngine.soft(b);}
    private static boolean natural(BlockState b){return FoundingEngine.natural(b);}
    private boolean loaded(Job j){
        for(int x=(j.minX-16)>>4;x<=(j.minX+j.blueprint.getSizeX()+16)>>4;x++)for(int z=(j.minZ-16)>>4;z<=(j.minZ+j.blueprint.getSizeZ()+16)>>4;z++)if(j.level.getChunkSource().getChunkNow(x,z)==null)return false;
        return true;
    }
    private void scan(Runnable save,WorkChunkLoader chunks)throws Exception{
        var j=job;
        if(!j.s.governorEnabled || (j.distant==null && !j.pack.equals(j.s.expansionPack)) || (j.player==null?!chunks.activeFor(j.s):j.player.hasDisconnected() || j.player.level()!=j.level || j.player.distanceToSqr(j.s.x,j.s.y,j.s.z)>192*192)){job=null;return;}
        if(j.distant!=null && !j.s.distantProjects.contains(j.distant)){job=null;return;}
        if(++j.ticks>2400){reject("survey timed out");return;}
        if(j.blueprint==null){
            if(!j.future.isDone())return;j.blueprint=j.future.join();
            if(j.blueprint==null){reject("blueprint could not be read");return;}
            if(j.blueprint.getSizeX()>48||j.blueprint.getSizeZ()>48||j.blueprint.getSizeY()>64){reject("blueprint exceeds safe alpha survey size");return;}
            var offset=j.blueprint.getPrimaryBlockOffset();j.minX=j.x-offset.getX();j.minZ=j.z-offset.getZ();
            var c=ColonyBridge.colony(j.s,j.level);
            int maxX=j.minX+j.blueprint.getSizeX()-1,maxZ=j.minZ+j.blueprint.getSizeZ()-1;
            for(var b:c.getServerBuildingManager().getBuildings().values()){
                var box=b.getCorners();if(overlap(j.minX,maxX,j.minZ,maxZ,box.getA().getX(),box.getB().getX(),box.getA().getZ(),box.getB().getZ(),6)){reject("too close to another building");return;}
            }
            if(j.s.camp!=null){var p=j.s.camp;if(overlap(j.minX,maxX,j.minZ,maxZ,p.minX,p.minX+p.width-1,p.minZ,p.minZ+p.depth-1,6)){reject("supply camp clearance");return;}}
            for(var road:j.s.roads)if(road.intersects(j.minX,maxX,j.minZ,maxZ)){reject("reserved approach path");return;}
            for(var p:j.s.plots)if(overlap(j.minX,maxX,j.minZ,maxZ,p.x-3,p.x+3,p.z-3,p.z+3,6)){reject("reserved cottage plot");return;}
        }
        if(!loaded(j)){reject("surrounding chunks are not loaded");return;}
        int width=j.blueprint.getSizeX(),depth=j.blueprint.getSizeZ(),height=j.blueprint.getSizeY();
        // At most 128 surface columns or volume cells per tick, across all colonies.
        int budget=LivingWorldSettings.current.surveyCellsPerTick;
        while(j.columns<width*depth && budget-->0){
            int x=j.minX+j.columns%width,z=j.minZ+j.columns/width;j.columns++;
            var chunk=j.level.getChunkSource().getChunkNow(x>>4,z>>4);int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,x,z);
            for(int n=0;n<4 && soft(chunk.getBlockState(new BlockPos(x,y,z)));n++)y--;
            if(!natural(chunk.getBlockState(new BlockPos(x,y,z)))){reject("trees, water or existing structures");return;}
            var claim=IColonyManager.getInstance().getColonyByPosFromDim(j.level.dimension(),new BlockPos(x,y,z));
            if(claim==null || claim.getID()!=j.s.colonyId){reject("site is outside this colony's available land");return;}
            if(x==j.x && z==j.z)j.anchorGround=y;
            j.low=Math.min(j.low,y);j.high=Math.max(j.high,y);if(j.high-j.low>TerrainRules.MAX_RELIEF){reject("terrain exceeds safe excavation depth");return;}
        }
        if(j.columns<width*depth)return;
        if(!TerrainRules.buildable(j.low,j.high,j.anchorGround,j.blueprint.getPrimaryBlockOffset().getY())){reject("foundation would be too exposed");return;}
        j.y=j.anchorGround+1;j.minY=j.y-j.blueprint.getPrimaryBlockOffset().getY();
        if(j.minY<j.level.getMinY()||j.minY+height>=j.level.getMaxY()){reject("height limits");return;}
        while(j.cursor<width*depth*height && budget-->0){
            int index=j.cursor++;int x=j.minX+index%width,z=j.minZ+(index/width)%depth,y=j.minY+index/(width*depth);
            var pos=new BlockPos(x,y,z);var chunk=j.level.getChunkSource().getChunkNow(x>>4,z>>4);var block=chunk.getBlockState(pos);
            if(!natural(block)||chunk.getBlockEntity(pos)!=null){reject("protected existing block at "+pos.toShortString());return;}
            if(j.distant!=null)j.before.add(block.toString());
        }
        if(j.cursor<width*depth*height)return;
        if(j.s.camp!=null){
            if(j.access==null){var p=new SitePlan();p.kind=j.kind;p.pack=j.pack;p.path=j.path;p.x=j.x;p.y=j.y;p.z=j.z;p.minX=j.minX;p.minY=j.minY;p.minZ=j.minZ;p.width=width;p.height=height;p.depth=depth;j.access=new AccessSurvey(j.level,j.s,p,j.blueprint);}
            j.access.tick();j.s.governorMessage=j.access.reason;if(!j.access.done)return;if(j.access.result==null){reject(j.access.reason);return;}
        }
        var anchor=new BlockPos(j.x,j.y,j.z);var state=j.blueprint.getBlockState(j.blueprint.getPrimaryBlockOffset());
        if(!(state.getBlock() instanceof com.minecolonies.api.blocks.AbstractBlockHut)){reject("blueprint has no colony hut anchor");return;}
        if(!soft(j.level.getBlockState(anchor))){reject("hut anchor obstructed");return;}
        var c=ColonyBridge.colony(j.s,j.level);
        if(c.getServerBuildingManager().getBuildings().values().stream().anyMatch(b->b.isPendingConstruction())){reject("another work order started");return;}
        if(j.distant!=null){
            var p=new SitePlan();p.pack=j.pack;p.path=j.path;p.kind=j.kind;p.x=j.x;p.y=j.y;p.z=j.z;p.minX=j.minX;p.minY=j.minY;p.minZ=j.minZ;p.width=width;p.height=height;p.depth=depth;p.before.addAll(j.before);p.autoAssembly=true;p.validate();
            DistantProgress.reserve(j.s,j.distant,p);
            if(j.access!=null)j.s.roads.add(j.access.result);
            TownProgress.record(j.s,"Reserved loaded site for distant "+j.kind+" at "+j.x+", "+j.z);save.run();job=null;return;
        }
        if(!Economy.affordable(j.s,j.kind)){reject("construction reserves changed during survey");return;}
        Economy.pay(j.s,j.kind);
        // Journal the payment and reservation before touching the world. A partial failure stops this
        // settlement instead of silently placing another hut at a different site.
        var e=new Expansion();e.pack=j.pack;e.path=j.path;e.kind=j.kind;e.x=j.x;e.y=j.y;e.z=j.z;j.s.expansions.add(e);save.run();
        if(!j.level.setBlock(anchor,state,3)){j.s.expansions.remove(e);Economy.refund(j.s,j.kind);save.run();reject("could not place hut anchor");return;}
        if(!(j.level.getBlockEntity(anchor) instanceof AbstractTileEntityColonyBuilding tile))throw new IllegalStateException("Hut block entity unavailable");
        tile.setStructurePack(StructurePacks.getStructurePack(j.s.expansionPack));tile.setBlueprintPath(j.path);
        // Level zero: registration must not mistake the unbuilt anchor for a finished level-one building.
        tile.setSchematicName(j.kind+"0");
        var min=new BlockPos(j.minX,j.minY,j.minZ);var max=min.offset(width-1,height-1,depth-1);tile.setSchematicCorners(min.subtract(anchor),max.subtract(anchor));
        var b=c.getServerBuildingManager().addNewBuilding(tile,j.level);if(b==null)throw new IllegalStateException("Could not register expansion hut");
        b.setBuildingLevel(0);b.setStructurePack(j.s.expansionPack);b.setBlueprintPath(j.path);b.setCorners(min,max);b.markDirty();
        if(j.access!=null)j.s.roads.add(j.access.result);
        save.run();
        b.requestUpgradeTo(j.player,ColonyBridge.builderHut(j.s),1);
        j.s.governorMessage=b.isPendingConstruction()?"Queued "+j.kind+" using "+e.pack:"Hut registered; waiting for MineColonies to accept its work order";job=null;
    }
    private static void recruit(Settlement s,ServerLevel level,com.minecolonies.api.colony.IColony colony){
        if(s.recruitmentCooldown>0 || (s.pendingMigrants==0 && (s.food<Economy.reserve(s)+16 || s.treasury<4)))return;
        var manager=colony.getCitizenManager();manager.calculateMaxCitizens();
        int count=manager.getCurrentCitizenCount();
        int capacity=Math.min(32,Math.min(manager.getMaxCitizens(),Economy.count(s,"residence")*4));
        if(count>=capacity)return;
        BlockPos pos;if(s.expedition){pos=ColonyBridge.spawnAtCamp(s,level);if(pos==null)return;}else{var p=s.plots.getFirst();pos=new BlockPos(p.x,p.y+1,p.z);}
        var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
        if(chunk==null || !chunk.getBlockState(pos).isAir() || !chunk.getBlockState(pos.above()).isAir()
            || !level.getEntities(null,new net.minecraft.world.phys.AABB(pos).expandTowards(0,1,0)).isEmpty())return;
        var citizen=s.expedition?manager.<com.minecolonies.api.colony.ICitizenData>spawnOrCreateCivilian(null,level,List.of(pos),true):manager.spawnOrCreateCitizen(null,level,pos);
        if(citizen!=null){citizen.setSaturation(20);if(s.pendingMigrants>0){s.pendingMigrants--;TownProgress.record(s,"A reserved migrant arrived");}else{s.food-=16;s.treasury-=4;}s.recruitmentCooldown=20;s.economyPopulation=manager.getCurrentCitizenCount();
            if(s.questMasterCitizenId==0 && QuestMaster.hall(s)!=null && citizen.getJob()==null && count>=1){s.questMasterCitizenId=citizen.getId();TownProgress.record(s,"Appointed a quest master at the town hall");}
        }
    }
    public static boolean overlap(int ax,int bx,int az,int bz,int cx,int dx,int cz,int dz,int gap){
        return ax<=Math.max(cx,dx)+gap && bx>=Math.min(cx,dx)-gap && az<=Math.max(cz,dz)+gap && bz>=Math.min(cz,dz)-gap;
    }
}

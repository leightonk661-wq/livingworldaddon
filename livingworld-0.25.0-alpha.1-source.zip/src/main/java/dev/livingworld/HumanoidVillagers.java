package dev.livingworld;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.Villager;
/** Resolve the pack's visual mannequin by its exact linkage score, never nearest-villager guessing. */
public final class HumanoidVillagers {
    public static final String MOD="mr_humanoid_villagers";
    public static Villager original(Entity entity,ServerLevel level){
        if(entity instanceof Villager v)return v;
        if(!entity.entityTags().contains("humvil.human"))return null;
        var board=level.getScoreboard();var objective=board.getObjective("humvil.id");if(objective==null)return null;
        var score=board.getPlayerScoreInfo(entity,objective);if(score==null)return null;
        var matches=level.getEntitiesOfClass(Villager.class,entity.getBoundingBox().inflate(3),v->{
            var linked=board.getPlayerScoreInfo(v,objective);
            return v.isAlive() && v.entityTags().contains("humvil.human.transformed") && linked!=null && linked.value()==score.value();
        });
        return matches.size()==1?matches.getFirst():null;
    }
    public static void removeVisual(Villager recruit,ServerLevel level){
        var board=level.getScoreboard();var objective=board.getObjective("humvil.id");if(objective==null)return;
        var score=board.getPlayerScoreInfo(recruit,objective);if(score==null)return;
        for(var visual:level.getEntities(recruit,recruit.getBoundingBox().inflate(3),e->e.entityTags().contains("humvil.human"))){
            var linked=board.getPlayerScoreInfo(visual,objective);if(linked!=null && linked.value()==score.value())visual.discard();
        }
    }
}

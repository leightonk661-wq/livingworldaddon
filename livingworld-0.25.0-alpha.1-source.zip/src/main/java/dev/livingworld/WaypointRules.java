package dev.livingworld;
public final class WaypointRules {
    public static boolean known(Settlement town,PlayerJourney journey,String player){return journey.visited.contains(town.name) || !player.isEmpty() && player.equals(town.founder);}
    public static boolean arrived(String dimension,double x,double z,Settlement town){return town.dimension.equals(dimension) && Math.hypot(town.x-x,town.z-z)<=32;}
    public static String bearing(double dx,double dz){
        if(Math.hypot(dx,dz)<1)return "Here";
        String[] names={"South","Southwest","West","Northwest","North","Northeast","East","Southeast"};
        return names[Math.floorMod((int)Math.round(Math.atan2(-dx,dz)*4/Math.PI),8)];
    }
}

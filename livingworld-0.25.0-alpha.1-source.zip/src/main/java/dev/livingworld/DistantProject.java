package dev.livingworld;
/** A paid abstract project. It has no terrain coordinates until a loaded-world survey accepts it. */
public final class DistantProject {
    public String id,kind,pack;
    public int progress,required;
    public int wood,stone,food,coins;
    public boolean ready(){return progress>=required;}
    public void validate(){
        if(id==null || id.length()>64 || !DistantProgress.supported(kind) || pack==null || pack.length()>100 || required<2 || required>240 || progress<0 || progress>required
            || wood<0 || wood>512 || stone<0 || stone>512 || food<0 || food>512 || coins<0 || coins>4096)throw new IllegalArgumentException("Invalid distant project");
    }
}

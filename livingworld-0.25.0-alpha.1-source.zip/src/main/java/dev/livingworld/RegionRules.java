package dev.livingworld;
public final class RegionRules {
    public static String key(int x,int z){return Math.floorDiv(x,2048)+":"+Math.floorDiv(z,2048);}
    public static String name(int x,int z){
        String[] roots={"Ash","Willow","Stone","Frost","Amber","Oak","Silver","Green"};String[] ends={"march","vale","reach","coast","heights","fields","wood","hollow"};
        int hash=java.util.Objects.hash(Math.floorDiv(x,2048),Math.floorDiv(z,2048));return roots[Math.floorMod(hash,8)]+ends[Math.floorMod(hash/8,8)];
    }
}

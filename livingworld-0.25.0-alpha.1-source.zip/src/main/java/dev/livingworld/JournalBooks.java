package dev.livingworld;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
public final class JournalBooks {
    public static String marker(ItemStack stack,String key){
        if(!stack.is(Items.WRITTEN_BOOK))return "";
        var tag=stack.get(DataComponents.CUSTOM_DATA);return tag==null?"":tag.copyTag().getStringOr(key,"");
    }
    public static boolean supported(ItemStack stack){
        return !marker(stack,"livingworld_dispatch").isEmpty() || !marker(stack,"livingworld_journal").isEmpty() || !marker(stack,"livingworld_charter").isEmpty() || !marker(stack,"livingworld_quest").isEmpty();
    }
}

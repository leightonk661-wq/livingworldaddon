package dev.livingworld;
/** Only acknowledge the matching items physically available, respecting native minimum batches. */
public final class SupplyRules {
    public static int batchTarget(int requested,int maxStack,int batchSize){
        return Math.min(Math.max(0,requested),Math.min(Math.max(1,maxStack),Math.max(1,batchSize)));
    }
    public static int acknowledged(int requested,int minimum,int held,int maxStack){
        int amount=Math.min(Math.max(0,held),Math.min(Math.max(0,requested),Math.max(0,maxStack)));
        return amount>=Math.max(1,minimum)?amount:0;
    }
    public static boolean bootstrapping(Settlement s){
        return s.expedition && s.founderSpawned && (s.starterSites.size()<2 || s.starterSites.stream().anyMatch(p->!p.complete));
    }
}

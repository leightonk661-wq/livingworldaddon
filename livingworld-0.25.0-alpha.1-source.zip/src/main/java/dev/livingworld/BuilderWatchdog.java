package dev.livingworld;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.storage.StructurePacks;
import com.minecolonies.core.colony.buildings.AbstractBuildingStructureBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import java.util.*;
import java.util.concurrent.CompletableFuture;
/** Escalates a genuine native build stall into the existing protected, journalled assembler. */
public final class BuilderWatchdog {
    private static final class Observation {
        String key;long since;CompletableFuture<Blueprint> future;
    }
    private final Map<String,Observation> watches=new HashMap<>();
    private int clock;
    public void reset(){watches.clear();clock=0;}
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save){
        if(++clock<20)return;clock=0;
        for(var s:towns){
            var e=s.expansions.stream().filter(x->!x.complete && x.assembly==null).findFirst().orElse(null);
            if(e==null || !s.governorEnabled || !s.colonyReady){watches.remove(s.name);continue;}
            try{check(server,s,e,save);}catch(Exception ex){
                watches.remove(s.name);
                s.governorMessage="Builder recovery inspection failed: "+DashboardData.clip(ex.getMessage());
                org.slf4j.LoggerFactory.getLogger("livingworld").warn("Could not inspect builder stall at {}",s.name,ex);
            }
        }
    }
    private void check(MinecraftServer server,Settlement s,Expansion e,Runnable save){
        ServerLevel level=null;for(var l:server.getAllLevels())if(l.dimension().identifier().toString().equals(s.dimension)){level=l;break;}
        if(level==null)return;
        var hut=ColonyBridge.builderHut(s);if(level.getChunkSource().getChunkNow(hut.getX()>>4,hut.getZ()>>4)==null)return;
        var site=new BlockPos(e.x,e.y,e.z);if(level.getChunkSource().getChunkNow(e.x>>4,e.z>>4)==null)return;
        var colony=ColonyBridge.colony(s,level);
        var builder=colony.getServerBuildingManager().getBuildings().get(hut);
        var target=colony.getServerBuildingManager().getBuildings().get(site);
        if(!(builder instanceof AbstractBuildingStructureBuilder building) || target==null || !target.isPendingConstruction())return;
        if(builder instanceof com.minecolonies.core.colony.buildings.workerbuildings.BuildingBuilder nativeBuilder){
            var order=nativeBuilder.getWorkOrder();
            if(order==null || !site.equals(order.getLocation())){
                watches.remove(s.name);s.governorMessage="Residence waiting for builder assignment; current order is elsewhere";return;
            }
        }
        var progress=building.getProgress();if(progress==null)return;
        var worker=builder.getAllAssignedCitizen().stream().filter(c->c.getEntity().isPresent()).findFirst().orElse(null);
        if(worker==null)return;
        boolean requestOpen=!builder.getOpenRequests(worker.getId()).isEmpty();
        String key=e.x+":"+e.y+":"+e.z+":"+progress.getA()+":"+progress.getB();
        long now=level.getGameTime();var watch=watches.computeIfAbsent(s.name,k->new Observation());
        if(!key.equals(watch.key) || requestOpen){watch.key=key;watch.since=now;watch.future=null;return;}
        long unchanged=now-watch.since;
        if(!BuilderStallRules.warn(unchanged,false))return;
        s.governorMessage="Builder stalled at residence/worksite "+site.toShortString()+" for "+(unchanged/20)+"s; no item request";
        if(!BuilderStallRules.rescue(unchanged,false))return;
        if(watch.future==null){watch.future=StructurePacks.getBlueprintFuture(e.pack,e.path,level.registryAccess());return;}
        if(!watch.future.isDone())return;
        Blueprint bp=watch.future.join();if(bp==null || bp.getSizeX()>48 || bp.getSizeZ()>48 || bp.getSizeY()>64)throw new IllegalArgumentException("Recovery blueprint unavailable or too large");
        var offset=bp.getPrimaryBlockOffset();var p=new SitePlan();
        p.pack=e.pack;p.path=e.path;p.kind=e.kind;p.x=e.x;p.y=e.y;p.z=e.z;
        p.minX=e.x-offset.getX();p.minY=e.y-offset.getY();p.minZ=e.z-offset.getZ();
        p.width=bp.getSizeX();p.height=bp.getSizeY();p.depth=bp.getSizeZ();
        p.validate();
        e.assembly=p;e.registrationPending=false;
        s.governorMessage="Native builder stalled; checking protected automatic recovery for "+e.kind;
        TownProgress.record(s,s.governorMessage);save.run();watches.remove(s.name);
    }
}

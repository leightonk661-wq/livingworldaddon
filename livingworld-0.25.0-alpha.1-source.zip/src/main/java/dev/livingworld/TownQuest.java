package dev.livingworld;

/** One saved, town-wide delivery request. The server completes it exactly once. */
public final class TownQuest {
    public String id,resource,title,reason;
    public int amount;
    public int progress;
    public java.util.Map<String,Integer> contributions=new java.util.LinkedHashMap<>();
    public long issuedAt;

    public void validate(){
        if(contributions==null)contributions=new java.util.LinkedHashMap<>();
        if(contributions.size()>64 || contributions.entrySet().stream().anyMatch(e->e.getKey()==null || e.getKey().length()>64 || e.getValue()==null || e.getValue()<1 || e.getValue()>64)
            || contributions.values().stream().mapToInt(Integer::intValue).sum()>progress)throw new IllegalArgumentException("Invalid quest contributions");
        if(id==null || id.length()>64 || resource==null || !resource.matches("wood|stone|food")
            || title==null || title.length()>80 || reason==null || reason.length()>240
            || amount<8 || amount>64 || progress<0 || progress>=amount || issuedAt<0)
            throw new IllegalArgumentException("Invalid town quest");
    }
}

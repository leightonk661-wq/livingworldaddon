package dev.livingworld;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.network.Filterable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.WrittenBookContent;

/** Server-issued, one-use permission to leave a village and establish a colony. */
public final class VillageCharter {
    public String token="",dimension="",villagerId="";
    public int x,z,lastX,lastZ;
    public VillageCharter(){}
    public VillageCharter(String token,String dimension,int x,int z){this.token=token;this.dimension=dimension;this.x=x;this.z=z;this.lastX=x;this.lastZ=z;}
    public void validate(){
        if(token==null || dimension==null || !token.matches("[0-9a-f-]{36}") || !dimension.equals("minecraft:overworld"))
            throw new IllegalArgumentException("Invalid village charter");
        if(villagerId==null)villagerId="";
        if(!villagerId.isEmpty())java.util.UUID.fromString(villagerId);
    }
    public boolean farEnough(String dimension,int x,int z){
        return this.dimension.equals(dimension) && (long)(this.x-x)*(this.x-x)+(long)(this.z-z)*(this.z-z)>=256L*256L;
    }
    public boolean matchesToken(String value){return token.equals(value);}
    public boolean matches(ItemStack stack){
        if(!stack.is(Items.WRITTEN_BOOK))return false;
        var data=stack.get(DataComponents.CUSTOM_DATA);
        return data!=null && matchesToken(data.copyTag().getStringOr("livingworld_charter", ""));
    }
    public ItemStack book(){
        var book=new ItemStack(Items.WRITTEN_BOOK);
        var pages=java.util.List.of(
            Filterable.<Component>passThrough(Component.literal("Village Charter\n\nThe bearer may lead one expedition to found a settlement. This charter is valid for one founding.")),
            Filterable.<Component>passThrough(Component.literal("Issuing village: "+x+", "+z+"\n\nTravel at least 256 blocks away. Bring 32 oak logs, 32 cobblestone and 16 bread. Open Living World (J) and choose Found here.")));
        book.set(DataComponents.WRITTEN_BOOK_CONTENT,new WrittenBookContent(Filterable.passThrough("Village Charter"),"Village elder",0,pages,true));
        var tag=new CompoundTag();tag.putString("livingworld_charter",token);
        book.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));
        return book;
    }
}

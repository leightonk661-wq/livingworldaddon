package dev.livingworld.mixin;
import dev.livingworld.BuilderLogistics;
import com.minecolonies.core.entity.ai.workers.AbstractEntityAIStructure;
import com.minecolonies.core.entity.ai.workers.builder.EntityAIStructureBuilder;
import com.minecolonies.api.entity.ai.statemachine.states.IAIState;
import com.minecolonies.api.entity.ai.statemachine.states.AIWorkerState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=AbstractEntityAIStructure.class,remap=false)
public abstract class BuilderMaterialMixin {
    @Shadow(remap=false) private int pickUpCount;
    @Inject(method="pickUpMaterial",at=@At("HEAD"),cancellable=true,remap=false)
    private void livingworld$useCarriedMaterials(CallbackInfoReturnable<IAIState> cir){
        if((Object)this instanceof EntityAIStructureBuilder ai && BuilderLogistics.bucketReady(ai)){
            // Native placement still consumes actual inventory and updates its normal resource accounting.
            ai.building.checkOrRequestBucket(ai.building.getRequiredResources(),ai.getWorker().getCitizenData());
            ai.building.checkOrRequestBucket(ai.building.getNextBucket(),ai.getWorker().getCitizenData());
            pickUpCount=0;cir.setReturnValue(AIWorkerState.START_WORKING);
        }else if((Object)this instanceof EntityAIStructureBuilder ai && BuilderLogistics.prefetchAtWorksite(ai)){
            cir.setReturnValue(AIWorkerState.PICK_UP);
        }
    }
}

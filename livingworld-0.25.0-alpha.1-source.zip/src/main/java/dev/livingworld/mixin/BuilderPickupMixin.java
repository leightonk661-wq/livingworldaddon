package dev.livingworld.mixin;
import dev.livingworld.*;
import com.minecolonies.core.entity.ai.workers.builder.EntityAIStructureBuilder;
import com.minecolonies.api.entity.ai.statemachine.states.IAIState;
import com.minecolonies.api.entity.ai.statemachine.states.AIWorkerState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(value=EntityAIStructureBuilder.class,remap=false)
public abstract class BuilderPickupMixin {
    @Inject(method="afterRequestPickUp",at=@At("HEAD"),cancellable=true,remap=false)
    private void livingworld$keepSupplies(CallbackInfoReturnable<IAIState> cir){
        var ai=(EntityAIStructureBuilder)(Object)this;var worker=ai.getWorker();
        if(BuilderLogistics.mayResume(LivingWorld.builderTown(worker,ai.building.getPosition())!=null,ai.building.hasWorkOrder(),worker.getCitizenInventoryHandler().isInventoryFull()))
            cir.setReturnValue(AIWorkerState.PICK_UP);
    }
}

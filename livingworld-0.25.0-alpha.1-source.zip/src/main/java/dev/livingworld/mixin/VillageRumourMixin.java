package dev.livingworld.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.livingworld.LivingWorld;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.storage.loot.LootTable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RandomizableContainer.class)
public interface VillageRumourMixin {
    // Only the actual loot-generation branch reaches this point. Reopening never repeats it.
    @Inject(method="unpackLootTable",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/storage/loot/LootTable;fill(Lnet/minecraft/world/Container;Lnet/minecraft/world/level/storage/loot/LootParams;J)V",shift=At.Shift.AFTER))
    default void livingworld$rumour(Player player,CallbackInfo ci,@Local ResourceKey<LootTable> table){
        LivingWorld.addVillageRumour((RandomizableContainer)this,table.identifier().toString());
    }
}

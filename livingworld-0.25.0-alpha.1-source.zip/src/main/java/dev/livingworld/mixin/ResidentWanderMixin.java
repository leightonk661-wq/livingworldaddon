package dev.livingworld.mixin;
import dev.livingworld.CitizenLifeService;
import com.minecolonies.core.entity.ai.minimal.EntityAICitizenWander;
import com.minecolonies.core.entity.citizen.EntityCitizen;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Suppress random wandering only while Living World owns an idle adult's safe social route. */
@Mixin(value=EntityAICitizenWander.class,remap=false)
public abstract class ResidentWanderMixin {
    @Shadow(remap=false) @Final protected EntityCitizen citizen;
    @Inject(method="canUse",at=@At("HEAD"),cancellable=true,remap=false)
    private void livingworld$socialRoute(CallbackInfoReturnable<Boolean> cir){if(CitizenLifeService.ownsRoutine(citizen))cir.setReturnValue(false);}
}

package dev.livingworld.mixin;
import dev.livingworld.PioneerEscort;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** The escort controls navigation; vanilla jobs, beds and wandering must not overwrite its path. */
@Mixin(Villager.class)
public abstract class PioneerBrainMixin {
    @Inject(method="customServerAiStep",at=@At("HEAD"),cancellable=true)
    private void livingworld$escortOnly(ServerLevel level,CallbackInfo ci){
        if(PioneerEscort.isPioneer((Villager)(Object)this))ci.cancel();
    }
}

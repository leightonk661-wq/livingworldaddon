package dev.livingworld.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.network.RegistryFriendlyByteBuf;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * MineColonies 0.0.67 uses one static recipe manager in an integrated JVM.
 * Its received client snapshot calls reset(), racing server template expansion.
 * The local client already sees the authoritative manager, so applying its own
 * serialized snapshot is both redundant and destructive. Remote sync is retained.
 * Listed only under "client" in the mixin config, never loaded on dedicated servers.
 */
@Mixin(targets = "com.minecolonies.core.colony.crafting.CustomRecipeManager", remap = false)
public abstract class IntegratedRecipeSyncMixin {
    @Inject(method = "handleCustomRecipeManagerMessage(Lnet/minecraft/network/RegistryFriendlyByteBuf;)V",
            at = @At("HEAD"), cancellable = true, require = 1, remap = false)
    private void livingworld$keepIntegratedRecipes(RegistryFriendlyByteBuf buffer, CallbackInfo ci) {
        if (Minecraft.getInstance().hasSingleplayerServer()) {
            // This is the message's private buffer, already decoded from the network packet.
            // Nothing else reads it after this handler; the shared manager remains authoritative.
            LoggerFactory.getLogger("livingworld").info("Skipped redundant integrated-server recipe sync; preserving server recipe templates");
            ci.cancel();
        }
    }
}

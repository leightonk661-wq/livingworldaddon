package dev.livingworld;

import java.util.HashMap;
import java.util.Map;

/** A bounded economic model. No world, chunk or entity access. */
public final class Settlement {
    public String name, dimension;
    public int x, y, z;
    public Map<Integer,CitizenLife> residents=new java.util.LinkedHashMap<>();
    public Map<String,Integer> regionalTrust=new HashMap<>();
    public int population = 4, homes = 1, wood = 24, stone = 16, food = 32;
    public int treasury = 16, progress, cycles;
    public Map<String, Integer> reputation = new HashMap<>();
    public Map<String, Boolean> alliances = new HashMap<>();
    public java.util.List<HousePlan> plots = new java.util.ArrayList<>();
    public boolean surveyed, pendingDeparture;
    public int colonyId;
    public int questMasterCitizenId;
    public String colonyOwner;
    public boolean colonyReady;
    public String expansionPack="",styleReason="",governorMessage="Not started";
    public boolean governorEnabled;
    public int siteAttempt;
    public boolean expedition,autoDevelop,materialMode,founderSpawned,automatic,journeyComplete;
    public String recruitId="",journeyMessage="No escorted recruit";
    public int recruitX,recruitZ;
    public int pioneerCitizenId;
    public String pioneerName="";
    public boolean pioneerTrained;
    public boolean distantEnabled=true,away;
    public int pendingMigrants;
    public long distantCycles;
    public String distantMessage="Awaiting an established settlement";
    public transient String chunkMessage="Work chunks idle";
    public java.util.List<DistantProject> distantProjects=new java.util.ArrayList<>();
    public String lifecycleStage="";
    public TownQuest quest;
    public Map<String,Integer> questRewards=new HashMap<>();
    public int questSerial;
    public long nextQuestTick;
    public java.util.List<String> history=new java.util.ArrayList<>();
    public java.util.Map<String,Long> rejectedSites=new java.util.LinkedHashMap<>();
    public String founder="",supplyMessage="Not started";
    public long deliveredItems;
    public java.util.List<RoadPlan> roads=new java.util.ArrayList<>();
    public java.util.List<String> siteReports=new java.util.ArrayList<>();
    public int failedSites;
    public long nextSurveyTick;
    public SitePlan camp;
    public java.util.List<SitePlan> starterSites=new java.util.ArrayList<>();
    public int economyPopulation=4,economyCycles,recruitmentCooldown;
    public String economyMessage="Waiting for governor";
    public java.util.List<Expansion> expansions=new java.util.ArrayList<>();

    public Settlement(String name, String dimension, int x, int y, int z) {
        this.name = name; this.dimension = dimension; this.x = x; this.y = y; this.z = z;
    }

    public void step() {
        if(colonyId>0){Economy.step(this);return;}
        if(expedition)return;
        if(pendingDeparture) return;
        cycles++;
        wood = Math.min(512, wood + 2);
        stone = Math.min(512, stone + 1);
        food = Math.min(512, food + 2 + population / 5);
        if (cycles % 5 == 0) food = Math.max(0, food - population);
        // One house takes 20 minutes of active server time, with resources paid up front.
        if (homes < (surveyed ? plots.size() : 8) && food >= population) {
            if (progress == 0 && wood >= 64 && stone >= 32) {
                wood -= 64; stone -= 32; progress = 1;
            } else if (progress > 0 && ++progress >= 40) {
                homes++; progress = 0;
            }
        }
        if (cycles % 20 == 0 && population < homes * 4 && food >= 16) {
            population++; food -= 8;
        }
    }

    public int relation(String player) { return reputation.getOrDefault(player, 0); }
    public int stock(String kind) {
        return switch (kind) { case "wood" -> wood; case "stone" -> stone; case "food" -> food; default -> -1; };
    }
    public void add(String kind, int amount) {
        switch (kind) { case "wood" -> wood += amount; case "stone" -> stone += amount; case "food" -> food += amount; default -> throw new IllegalArgumentException("Unknown resource"); }
    }
    public void supply(String player, String kind, int amount) {
        if (amount < 8 || amount > 64 || stock(kind) < 0 || stock(kind) + amount > 512)
            throw new IllegalArgumentException("Supply 8–64 items, with space in the settlement stockpile (maximum 512).");
        add(kind, amount);
        reputation.put(player, Math.min(100, relation(player) + amount / 8));
    }
    public void ally(String player) {
        if (relation(player) < 40) throw new IllegalArgumentException("Earn 40 reputation through supplies first.");
        alliances.put(player, true);
    }
    public void validate() {
        if(residents==null)residents=new java.util.LinkedHashMap<>();if(regionalTrust==null)regionalTrust=new HashMap<>();
        if(residents.size()>128 || regionalTrust.size()>32)throw new IllegalArgumentException("Too many resident or town relationships");
        for(var e:residents.entrySet()){if(e.getKey()==null || e.getValue()==null || e.getKey()!=e.getValue().id)throw new IllegalArgumentException("Invalid resident identity");e.getValue().validate();}
        for(var e:regionalTrust.entrySet())if(e.getKey()==null || !e.getKey().matches("[A-Za-z0-9_-]{1,24}") || e.getValue()==null || e.getValue()<0 || e.getValue()>100)throw new IllegalArgumentException("Invalid regional relationship");

        if(questRewards==null)questRewards=new HashMap<>();
        if(questRewards.size()>4096 || questRewards.entrySet().stream().anyMatch(e->e.getKey()==null || e.getKey().length()>64 || e.getValue()==null || e.getValue()<1 || e.getValue()>4096))throw new IllegalArgumentException("Invalid pending quest rewards");
        if(questSerial<0 || nextQuestTick<0)throw new IllegalArgumentException("Invalid quest schedule");
        if(quest!=null)quest.validate();
        if(history==null)history=new java.util.ArrayList<>();if(rejectedSites==null)rejectedSites=new java.util.LinkedHashMap<>();if(lifecycleStage==null)lifecycleStage="";
        if(history.size()>24 || rejectedSites.size()>384 || history.stream().anyMatch(v->v==null || v.length()>400) || rejectedSites.entrySet().stream().anyMatch(e->e.getKey()==null || e.getKey().length()>160 || e.getValue()==null || e.getValue()<0))throw new IllegalArgumentException("Invalid progress history");
        if(roads==null)roads=new java.util.ArrayList<>();if(siteReports==null)siteReports=new java.util.ArrayList<>();
        if(roads.size()>50 || siteReports.size()>16 || failedSites<0 || nextSurveyTick<0)throw new IllegalArgumentException("Invalid terrain state");
        for(var road:roads)road.validate();
        if(founder==null)founder="";if(supplyMessage==null)supplyMessage="Not started";
        if(pioneerName==null)pioneerName="";
        if(pioneerCitizenId<0 || pioneerName.length()>64)throw new IllegalArgumentException("Invalid pioneer identity");
        if(recruitId==null)recruitId="";if(journeyMessage==null)journeyMessage="No escorted recruit";
        if(!recruitId.isEmpty())java.util.UUID.fromString(recruitId);
        if(starterSites==null)starterSites=new java.util.ArrayList<>();
        if(starterSites.size()>2 || deliveredItems<0)throw new IllegalArgumentException("Invalid expedition state");
        if(camp!=null)camp.validate();for(var site:starterSites)site.validate();
        if(economyMessage==null)economyMessage="Waiting for governor";
        if(economyPopulation<0 || economyPopulation>10000 || economyCycles<0 || economyCycles>=1000000 || recruitmentCooldown<0 || recruitmentCooldown>20)throw new IllegalArgumentException("Invalid economy state");
        if(expansionPack==null)expansionPack="";if(styleReason==null)styleReason="";if(governorMessage==null)governorMessage="Not started";
        if(expansions==null)expansions=new java.util.ArrayList<>();
        if(expansions.size()>48)throw new IllegalArgumentException("Too many expansion records");
        for(var e:expansions)if(e==null || e.pack==null || e.path==null || e.kind==null)throw new IllegalArgumentException("Invalid expansion record");
        DistantProgress.validate(this);
        if(colonyId<0 || questMasterCitizenId<0 || (colonyReady && colonyId==0)) throw new IllegalArgumentException("Invalid linked colony");
        if(colonyId>0) {if(colonyOwner==null) throw new IllegalArgumentException("Missing colony identity");java.util.UUID.fromString(colonyOwner);}
        if(plots==null) plots=new java.util.ArrayList<>();
        if(!plots.isEmpty()) surveyed=true; // A save during survey retains only the finished reservations.
        if(plots.size()>8) throw new IllegalArgumentException("Too many house plots");
        for(var p:plots) p.validate();
        if (name == null || !name.matches("[A-Za-z0-9_-]{1,24}") || dimension == null ||
            homes < 1 || homes > 8 || population < 1 || population > 32 ||
            wood < 0 || wood > 512 || stone < 0 || stone > 512 || food < 0 || food > 512 ||
            progress < 0 || progress >= 40 || treasury < 0 || reputation == null || alliances == null)
            throw new IllegalArgumentException("Invalid settlement save");
    }
}

package dev.livingworld;
public final class CampSafety {
    public static int[] candidate(int attempt){
        int i=Math.floorMod(attempt,48),distance=32+16*((i%24)/8);
        int[][] dirs={{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
        if(i<24)return new int[]{dirs[i%8][0]*distance,dirs[i%8][1]*distance};
        int[][] extra={{2,1},{1,2},{-1,2},{-2,1},{-2,-1},{-1,-2},{1,-2},{2,-1}};
        return new int[]{extra[i%8][0]*distance/2,extra[i%8][1]*distance/2};
    }
    public static boolean nearFootprint(double x,double z,SitePlan p,int margin){
        return x>=p.minX-margin && x<p.minX+p.width+margin && z>=p.minZ-margin && z<p.minZ+p.depth+margin;
    }
}

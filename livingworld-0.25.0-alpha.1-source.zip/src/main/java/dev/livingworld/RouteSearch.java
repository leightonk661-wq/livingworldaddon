package dev.livingworld;
import java.util.*;

/** Incremental A*: cardinal steps, no cliff jumps, fixed exploration and route limits. */
public final class RouteSearch {
    public record Point(int x,int y,int z) {}
    public interface Ground { Integer height(int x,int z); }
    private record Entry(Point p,int cost,int score) {}
    private final PriorityQueue<Entry> open=new PriorityQueue<>(Comparator.comparingInt(Entry::score));
    private final Map<Point,Integer> costs=new HashMap<>();
    private final Map<Point,Point> parents=new HashMap<>();
    private final Ground ground;private final Point target,start;
    public boolean done;public List<Point> route=List.of();private int examined;
    public RouteSearch(Point start,Point target,Ground ground){this.start=start;this.target=target;this.ground=ground;costs.put(start,0);open.add(new Entry(start,0,estimate(start)));}
    private int estimate(Point p){return 10*(Math.abs(p.x-target.x)+Math.abs(p.z-target.z));}
    public void step(int budget){
        while(!done && budget-->0){
            if(open.isEmpty() || examined++>=4096){done=true;return;}
            var e=open.poll();if(e.cost!=costs.getOrDefault(e.p,Integer.MAX_VALUE))continue;
            if(e.p.equals(target)){
                var path=new ArrayList<Point>();Point p=target;
                while(p!=null){path.add(p);if(path.size()>256){done=true;return;}p=parents.get(p);}
                Collections.reverse(path);route=path;done=true;return;
            }
            for(var d:new int[][]{{1,0},{0,1},{-1,0},{0,-1}}){
                int x=e.p.x+d[0],z=e.p.z+d[1];if(Math.abs(x-start.x)>144 || Math.abs(z-start.z)>144)continue;
                Integer y=ground.height(x,z);if(y==null || Math.abs(y-e.p.y)>1)continue;
                var n=new Point(x,y,z);int cost=e.cost+10+4*Math.abs(y-e.p.y);
                if(cost<costs.getOrDefault(n,Integer.MAX_VALUE)){costs.put(n,cost);parents.put(n,e.p);open.add(new Entry(n,cost,cost+estimate(n)));}
            }
        }
    }
}

package dev.livingworld;

/** Nearby players wake NPC towns, but discovery alone never grants MineColonies authority. */
public final class TownAutonomyRules {
    private TownAutonomyRules() {}

    public static boolean mayWitnessFounding(Settlement town,String playerId) {
        return town.automatic || playerId.equals(town.founder);
    }

    public static boolean mayPlanNearby(Settlement town,boolean colonyMember) {
        return town.automatic || colonyMember;
    }

    public static boolean grantOfficer(Settlement town,String playerId) {
        return !town.automatic && playerId.equals(town.founder);
    }
}

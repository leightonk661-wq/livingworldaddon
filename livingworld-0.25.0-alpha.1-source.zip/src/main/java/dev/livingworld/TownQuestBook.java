package dev.livingworld;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.Filterable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.WrittenBookContent;
import java.util.List;

/** A signed, quest-specific request that players can carry back to the Quest Master. */
public final class TownQuestBook {
    private TownQuestBook(){}
    public static ItemStack create(Settlement town){
        var q=town.quest;if(q==null)throw new IllegalArgumentException("No open quest");
        var book=new ItemStack(Items.WRITTEN_BOOK);
        String title=q.title.substring(0,Math.min(32,q.title.length()));
        var hall=QuestMaster.hall(town);int x=hall==null?town.x:hall.x,z=hall==null?town.z:hall.z;
        var pages=BookPages.fit(List.of(q.title+"\n\n"+q.reason,
            "Request\n\n"+q.amount+" "+TownQuests.itemName(q.resource)+"\nReceived: "+q.progress+" / "+q.amount+"\n\nCarry this book. Drop supplies at the Quest Master's feet. Partial stacks count.",
            "Return to "+town.name+"\n\nTown hall: "+x+", "+z+"\n\nReputation is shared by contribution. The largest contributor may collect one funded emerald from the Quest Master.",
            "Keep in touch\n\nRight-click the Quest Master to update this book's progress. Completed requests cannot be delivered twice."));
        book.set(DataComponents.WRITTEN_BOOK_CONTENT,new WrittenBookContent(Filterable.passThrough(title),"Quest Master",0,
            pages.stream().map(page->Filterable.<Component>passThrough(Component.literal(page))).toList(),true));
        var tag=new CompoundTag();tag.putString("livingworld_quest",q.id);
        book.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));
        return book;
    }
    public static boolean matches(ItemStack stack,TownQuest quest){
        if(quest==null || !stack.is(Items.WRITTEN_BOOK))return false;
        var data=stack.get(DataComponents.CUSTOM_DATA);
        return data!=null && quest.id.equals(data.copyTag().getStringOr("livingworld_quest",""));
    }
    public static boolean carries(ServerPlayer player,TownQuest quest){
        for(int i=0;i<player.getInventory().getContainerSize();i++)if(matches(player.getInventory().getItem(i),quest))return true;
        return matches(player.getOffhandItem(),quest);
    }
    public static void give(ServerPlayer player,Settlement town){
        String id=player.getUUID().toString();int pending=town.questRewards.getOrDefault(id,0);
        if(pending>0){
            var reward=new ItemStack(Items.EMERALD,Math.min(64,pending));int offered=reward.getCount();player.getInventory().add(reward);int received=offered-reward.getCount();
            if(received>0){int left=pending-received;if(left==0)town.questRewards.remove(id);else town.questRewards.put(id,left);player.sendSystemMessage(Component.literal("The Quest Master hands you "+received+" emerald(s). Thank you for helping "+town.name+"."));}
            else player.sendSystemMessage(Component.literal("Make room in your inventory to collect your reward."));
        }
        if(town.quest==null){player.sendSystemMessage(Component.literal("The Quest Master has no request right now."));return;}
        if(carries(player,town.quest)){
            var content=create(town).get(DataComponents.WRITTEN_BOOK_CONTENT);
            for(int i=0;i<player.getInventory().getContainerSize();i++){var book=player.getInventory().getItem(i);if(matches(book,town.quest))book.set(DataComponents.WRITTEN_BOOK_CONTENT,content);}
            if(matches(player.getOffhandItem(),town.quest))player.getOffhandItem().set(DataComponents.WRITTEN_BOOK_CONTENT,content);
            player.getInventory().setChanged();player.containerMenu.broadcastChanges();
            player.sendSystemMessage(Component.literal("Your request book is updated: "+town.quest.progress+" / "+town.quest.amount+" received."));return;
        }
        player.getInventory().placeItemBackInInventory(create(town));
        player.sendSystemMessage(Component.literal("The Quest Master gave you a written request. Read it, then drop the items beside them."));
    }
}

package dev.livingworld;
/** A charter is transferred into one settlement, including in operator testing. */
public final class PioneerHandoff {
    public static void link(Settlement town,VillageCharter charter){
        if(charter==null || charter.villagerId==null || charter.villagerId.isEmpty())throw new IllegalArgumentException("A recruited pioneer is required");
        if(!town.expedition || town.automatic || !town.recruitId.isEmpty())throw new IllegalArgumentException("This settlement cannot accept a pioneer");
        town.recruitId=charter.villagerId;town.recruitX=charter.lastX;town.recruitZ=charter.lastZ;
        town.journeyComplete=false;town.journeyMessage="Pioneer is waiting for the camp to be ready";
    }
    public static boolean ready(Settlement town,boolean recruitAtCamp,boolean citizenLoaded){
        return !town.recruitId.isEmpty() && !town.journeyComplete && town.camp!=null && town.camp.complete && town.founderSpawned && recruitAtCamp && citizenLoaded;
    }
}

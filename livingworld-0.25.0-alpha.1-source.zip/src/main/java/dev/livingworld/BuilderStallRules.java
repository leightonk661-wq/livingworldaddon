package dev.livingworld;
/** Timed intervention requires an unchanged native cursor and no open request. */
public final class BuilderStallRules {
    public static boolean warn(long unchangedTicks,boolean requestOpen){return !requestOpen && unchangedTicks>=1200;}
    public static boolean rescue(long unchangedTicks,boolean requestOpen){return !requestOpen && unchangedTicks>=3600;}
}

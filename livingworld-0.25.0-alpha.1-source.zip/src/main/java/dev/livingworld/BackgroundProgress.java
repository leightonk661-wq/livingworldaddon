package dev.livingworld;
/** Physical background work begins after the pioneer has actually joined camp. */
public final class BackgroundProgress {
    public static boolean eligible(Settlement s){
        return s.expedition && s.governorEnabled && s.distantEnabled && !s.pendingDeparture
            && s.dimension.equals("minecraft:overworld") && s.colonyId>0 && s.economyPopulation>0 && s.founderSpawned
            && s.camp!=null && s.camp.complete && (s.recruitId.isEmpty() || s.journeyComplete)
            && (s.colonyReady || s.autoDevelop);
    }
    public static boolean startersPending(Settlement s){return s.starterSites.size()<2 || s.starterSites.stream().anyMatch(p->!p.complete);}
    public static String nextStarter(Settlement s){return s.starterSites.isEmpty()?"builder":"townhall";}
}

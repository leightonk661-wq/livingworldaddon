package dev.livingworld;

import com.minecolonies.api.entity.citizen.AbstractEntityCitizen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.Filterable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.WrittenBookContent;
import java.util.*;

/** Small, player-local observations and physical journals; never loads terrain. */
public final class JourneyService {
    private int clock=19;
    private final Map<ServerPlayer,String> sent=new WeakHashMap<>();
    public void reset(){clock=19;sent.clear();}
    public static boolean matches(ItemStack book,String owner){
        var tag=book.get(DataComponents.CUSTOM_DATA);
        return book.is(Items.WRITTEN_BOOK) && tag!=null && owner.equals(tag.copyTag().getStringOr("livingworld_journal",""));
    }
    public static List<String> overview(PlayerJourney journey){
        var next=journey.objective();
        return List.of("#Your journey",next.title(),next.detail(),"Milestones recorded: "+journey.milestones.size()+". Places visited: "+journey.visited.size()+". Use /livingworld journal to replace a lost journal.");
    }
    public static List<String> pages(PlayerJourney journey,List<Settlement> towns){
        var next=journey.objective();var pages=new ArrayList<String>();
        pages.add("Traveller's Journal\n\n"+next.title()+"\n\n"+next.detail());
        pages.add("The first journey\n\nFind a village. Earn 4 emeralds through normal trade. Crouch-right-click an adult villager with an empty hand to recruit a pioneer.");
        pages.add("Pack for the road\n\n32 oak logs\n32 cobblestone\n16 bread\nVillage Charter\n\nEscort your pioneer at least 256 blocks from the village. Use J > Council > Found here.");
        pages.add("Making a home\n\nStay until your pioneer joins the completed camp. Then you can leave: background work continues in saved, player-visited chunks. Check J > Works for blockers.");
        pages.add("Quiet guidance\n\nBrief HUD hints follow your progress. Use /livingworld hints off to hide them, or /livingworld hints on to restore them.");
        pages.add("Helping neighbours\n\nAsk a Quest Master for a written request. Carry it and drop supplies at their feet. Partial deliveries count. Return to collect any funded reward.");
        pages.add("Recorded milestones\n\n"+(journey.milestones.isEmpty()?"Your story is just beginning.":String.join("\n",journey.milestones.stream().map(DashboardData::friendly).toList())));
        for(var s:towns)if(journey.visited.contains(s.name)){
            pages.add(s.name+"\n\n"+TownProgress.stage(s)+"\n"+s.x+", "+s.y+", "+s.z+"\n\n"+(s.automatic?"An independent settlement.":"A traveller-founded settlement.")+"\n\n"+TownProgress.next(s));
        }
        return BookPages.fit(pages);
    }
    private static WrittenBookContent content(PlayerJourney journey,List<Settlement> towns){
        return new WrittenBookContent(Filterable.passThrough("Traveller's Journal"),"Living World",0,
            pages(journey,towns).stream().map(s->Filterable.<Component>passThrough(Component.literal(s))).toList(),true);
    }
    public static boolean refresh(ServerPlayer player,PlayerJourney journey,List<Settlement> towns){
        String owner=player.getUUID().toString();var content=content(journey,towns);boolean found=false,changed=false;
        for(int i=0;i<player.getInventory().getContainerSize();i++){
            var stack=player.getInventory().getItem(i);if(!matches(stack,owner))continue;found=true;
            if(!content.equals(stack.get(DataComponents.WRITTEN_BOOK_CONTENT))){stack.set(DataComponents.WRITTEN_BOOK_CONTENT,content);changed=true;}
        }
        var offhand=player.getOffhandItem();
        if(matches(offhand,owner)){found=true;if(!content.equals(offhand.get(DataComponents.WRITTEN_BOOK_CONTENT))){offhand.set(DataComponents.WRITTEN_BOOK_CONTENT,content);changed=true;}}
        if(changed){player.getInventory().setChanged();player.containerMenu.broadcastChanges();}
        return found;
    }
    public static boolean give(ServerPlayer player,PlayerJourney journey,List<Settlement> towns){
        if(refresh(player,journey,towns))return true;
        var book=new ItemStack(Items.WRITTEN_BOOK);book.set(DataComponents.WRITTEN_BOOK_CONTENT,content(journey,towns));
        var tag=new CompoundTag();tag.putString("livingworld_journal",player.getUUID().toString());book.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));
        return player.getInventory().add(book);
    }
    public void sync(ServerPlayer player,PlayerJourney state,VillageCharter charter,List<Settlement> towns,boolean open){
        if(!net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player,DashboardNetwork.Journal.TYPE))return;
        if(!state.trackedQuest.isEmpty() && towns.stream().noneMatch(t->t.quest!=null && t.quest.id.equals(state.trackedQuest)))state.trackedQuest="";
        String json=new com.google.gson.Gson().toJson(JournalData.project(state,towns,charter,player.getUUID().toString()));
        if(open || !json.equals(sent.get(player))){
            net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,new DashboardNetwork.Journal(json,open));sent.put(player,json);
        }
    }
    public void tick(MinecraftServer server,Map<String,PlayerJourney> records,Map<String,VillageCharter> charters,List<Settlement> towns,Runnable save){
        if(++clock<20)return;clock=0;boolean dirty=false;
        for(var player:server.getPlayerList().getPlayers()){
            String id=player.getUUID().toString();var journey=records.get(id);boolean fresh=journey==null;
            if(fresh){if(records.size()>=4096)continue;journey=new PlayerJourney();records.put(id,journey);dirty=true;}
            String dimension=player.level().dimension().identifier().toString();
            var nearby=towns.stream().filter(s->s.dimension.equals(dimension) && player.distanceToSqr(s.x,s.y,s.z)<96*96).toList();
            boolean changed=journey.observe(id,dimension.equals("minecraft:overworld") && player.level().isVillage(player.blockPosition()),charters.containsKey(id),towns,nearby);
            dirty|=changed;
            if(!journey.journalGiven && give(player,journey,towns)){
                journey.journalGiven=true;dirty=true;
                player.sendSystemMessage(Component.literal("You received a Traveller's Journal. Your next step: "+journey.objective().title()+"."));
            }else if(changed){
                refresh(player,journey,towns);

            }
            if(!journey.waypointTown.isEmpty()){
                String marked=journey.waypointTown;
                var destination=towns.stream().filter(t->t.name.equals(marked)).findFirst().orElse(null);
                if(destination==null || !WaypointRules.known(destination,journey,id)){journey.waypointTown="";dirty=true;}
                else if(WaypointRules.arrived(dimension,player.getX(),player.getZ(),destination)){
                    journey.waypointTown="";dirty=true;player.sendSystemMessage(Component.literal("You have reached "+destination.name+"."));
                }
            }
            sync(player,journey,charters.get(id),towns,false);
            var objective=journey.objective();
            long now=server.overworld().getGameTime();
            if(HintRules.ready(journey,objective.title(),now) && net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player,DashboardNetwork.Hint.TYPE)){
                net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,new DashboardNetwork.Hint(objective.title(),objective.detail()));
                journey.lastHint=objective.title();journey.hintAt=now;dirty=true;
            }
            if(journey.hintsEnabled && now-journey.hintAt>=1200 && net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player,DashboardNetwork.Hint.TYPE)){
                String key="",title="",detail="";
                var charter=charters.get(id);
                if(charter!=null && !charter.villagerId.isEmpty() && charter.dimension.equals(dimension) && !journey.contextHints.contains("escort")){
                    var pioneer=player.level().getEntity(UUID.fromString(charter.villagerId));
                    if(pioneer!=null && pioneer.isAlive() && player.distanceToSqr(pioneer)>24*24){
                        key="escort";title="Wait for your pioneer";detail="Your travelling settler is falling behind. Slow down and keep a walkable route between you.";
                    }
                }
                if(key.isEmpty() && !journey.contextHints.contains("departure") && LivingWorldSettings.current.workChunkLoading && towns.stream().anyMatch(t->id.equals(t.founder) && BackgroundProgress.eligible(t))){
                    key="departure";title="Your camp can carry on";detail="You can leave now. Starter huts continue through the background rotation. Work areas must be saved and player-visited; check Build for blockers.";
                }
                if(key.isEmpty() && !journey.contextHints.contains("reward") && nearby.stream().anyMatch(t->t.questRewards.getOrDefault(id,0)>0)){
                    key="reward";title="A thank-you is waiting";detail="A nearby town owes you a quest reward. Speak to its Quest Master with space in your inventory.";
                }
                if(!key.isEmpty()){
                    net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,new DashboardNetwork.Hint(title,detail));
                    journey.contextHints.add(key);journey.hintAt=now;dirty=true;
                }
            }
            long day=player.level().getGameTime()/24000;
            for(var town:nearby){
                if(!town.colonyReady || journey.greeted.getOrDefault(town.name,-1L)==day)continue;
                var speakers=player.level().getEntitiesOfClass(AbstractEntityCitizen.class,player.getBoundingBox().inflate(10),c->c.isAlive() && c.getCitizenColonyHandler().getColonyId()==town.colonyId);
                if(speakers.isEmpty())continue;
                String greeting=town.food<Economy.reserve(town)?"Food is running short. The Quest Master may need a hand.":
                    town.questRewards.getOrDefault(id,0)>0?"The Quest Master has a reward waiting for you.":
                    town.alliances.getOrDefault(id,false)?"Welcome back, friend. You are welcome here.":
                    town.relation(id)>=5?"Good to see you again. We remember your help.":
                    town.expansions.stream().anyMatch(e->!e.complete)?"Mind the building site. We are making room for more settlers.":
                    "Welcome to "+town.name+". The town hall is a good place to start.";
                player.sendSystemMessage(Component.literal("["+town.name+"] "+speakers.getFirst().getName().getString()+": "+greeting));
                if(journey.greeted.size()>=32 && !journey.greeted.containsKey(town.name))journey.greeted.remove(journey.greeted.keySet().iterator().next());
                journey.greeted.put(town.name,day);dirty=true;break;
            }
        }
        if(dirty)save.run();
    }
}

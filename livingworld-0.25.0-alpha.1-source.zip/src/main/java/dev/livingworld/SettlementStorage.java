package dev.livingworld;
import com.minecolonies.api.colony.ICitizenData;
import com.minecolonies.api.colony.buildings.IBuilding;
import com.minecolonies.api.inventory.api.IItemHandler;
import com.minecolonies.api.util.IItemHandlerCapProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Loaded builder-linked containers and the reserved camp footprint only; never scans arbitrary player chests. */
public final class SettlementStorage {
    public static List<IItemHandler> sources(Settlement s,IBuilding builder,ServerLevel level){
        var positions=new LinkedHashSet<BlockPos>();positions.add(builder.getPosition());
        for(var pos:builder.getContainers()){if(positions.size()>=64)break;positions.add(pos);}
        var camp=s.camp;
        if(camp!=null && camp.complete){
            for(int x=camp.minX>>4;x<=(camp.minX+camp.width-1)>>4;x++)for(int z=camp.minZ>>4;z<=(camp.minZ+camp.depth-1)>>4;z++){
                var chunk=level.getChunkSource().getChunkNow(x,z);if(chunk==null)continue;
                for(var pos:chunk.getBlockEntities().keySet())if(positions.size()<64 && pos.getX()>=camp.minX && pos.getX()<camp.minX+camp.width
                    && pos.getZ()>=camp.minZ && pos.getZ()<camp.minZ+camp.depth && pos.getY()>=camp.minY && pos.getY()<camp.minY+camp.height)positions.add(pos);
            }
        }
        var handlers=new ArrayList<IItemHandler>();
        for(var pos:positions){
            var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);if(chunk==null)continue;
            var claim=com.minecolonies.api.colony.IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),pos);
            if(claim==null || claim.getID()!=s.colonyId)continue;
            var tile=chunk.getBlockEntity(pos);if(tile==null)continue;
            var provider=IItemHandlerCapProvider.wrap(tile);if(provider==null)continue;
            var handler=provider.getItemHandlerCap();if(handler!=null && !handlers.contains(handler))handlers.add(handler);
        }
        return handlers;
    }
    private static ItemStack insert(IItemHandler inv,ItemStack stack,boolean simulate){
        for(int slot=0;slot<inv.getSlots() && !stack.isEmpty();slot++)stack=inv.insertItem(slot,stack,simulate);return stack;
    }
    /** Preserve incidental floor drops in the builder's linked/camp storage, never a player chest. */
    public static int offload(ICitizenData worker,ItemStack wanted,List<IItemHandler> stores,ServerLevel level){
        var inv=worker.getInventory();
        for(int slot=0;slot<inv.getSlots();slot++){
            var stack=inv.getStackInSlot(slot);
            if(stack.isEmpty() || !ItemStack.isSameItemSameComponents(stack,wanted))continue;
            for(var store:stores){
                if(store==inv)continue;
                var sample=inv.extractItem(slot,stack.getCount(),true);
                int fitting=sample.getCount()-insert(store,sample.copy(),true).getCount();
                if(fitting<=0)continue;
                var taken=inv.extractItem(slot,fitting,false);
                if(taken.isEmpty())continue;
                var remainder=insert(store,taken,false);
                int moved=taken.getCount()-remainder.getCount();
                if(!remainder.isEmpty()){
                    remainder=insert(inv,remainder,false);
                    if(!remainder.isEmpty()){var spill=remainder;worker.getEntity().ifPresent(entity->entity.spawnAtLocation(level,spill));}
                }
                if(moved>0){inv.markDirty();return moved;}
            }
        }
        return 0;
    }
    public static boolean supply(Settlement s,ICitizenData worker,ItemStack wanted,int limit,List<IItemHandler> sources,ServerLevel level){
        var target=worker.getInventory();int inspected=0;
        for(var source:sources){
            if(source==target)continue;
            for(int slot=0;slot<source.getSlots() && inspected++<512;slot++){
                var stored=source.getStackInSlot(slot);
                if(stored.isEmpty() || !ItemStack.isSameItemSameComponents(stored,wanted))continue;
                var sample=source.extractItem(slot,limit,true);if(sample.isEmpty())continue;
                int fitting=sample.getCount()-insert(target,sample.copy(),true).getCount();if(fitting<=0)return false;
                var taken=source.extractItem(slot,fitting,false);if(taken.isEmpty())continue;
                int extracted=taken.getCount();var remainder=insert(target,taken,false);int moved=extracted-remainder.getCount();
                if(!remainder.isEmpty()){
                    remainder=source.insertItem(slot,remainder,false);
                    if(!remainder.isEmpty())remainder=insert(source,remainder,false);
                    if(!remainder.isEmpty())worker.getEntity().orElseThrow().spawnAtLocation(level,remainder);
                }
                if(moved>0){target.markDirty();s.deliveredItems+=moved;s.supplyMessage="Collected "+moved+" "+wanted.getHoverName().getString()+" from camp / linked builder storage";return true;}
            }
            if(inspected>=512)break;
        }
        return false;
    }
}

package dev.livingworld;
import java.util.*;
/** A player-local view. Inventory is counted locally; delivery totals and milestones are server facts. */
public final class JournalData {
    public String title="Traveller's Journal",objective="",detail="",mode="journey",status="";
    public String charterToken="",dispatchId="",dispatchPhase="";
    public String waypointTown="",waypointDimension="";
    public int waypointX,waypointZ;
    public boolean checklistEnabled=true,hintsEnabled=true;
    public List<Requirement> requirements=new ArrayList<>();
    public List<Step> milestones=new ArrayList<>();
    public List<String> places=new ArrayList<>();
    public List<Place> knownPlaces=new ArrayList<>();
    public record Place(String name,String stage,String dimension,int x,int y,int z){}
    public record Requirement(String item,String label,int amount,int delivered,boolean exactCharter){}
    public record Step(String label,boolean complete){}
    public static int remaining(Requirement r){return Math.max(0,r.amount()-r.delivered());}
    public static boolean ready(Requirement r,int inventory){return r.delivered()+Math.max(0,inventory)>=r.amount();}
    public static JournalData project(PlayerJourney state,List<Settlement> towns,VillageCharter charter){return project(state,towns,charter,"");}
    public static JournalData project(PlayerJourney state,List<Settlement> towns,VillageCharter charter,String owner){
        var data=new JournalData();if(charter!=null)data.charterToken=charter.token;var next=state.objective();data.objective=next.title();data.detail=next.detail();
        data.checklistEnabled=state.checklistEnabled;data.hintsEnabled=state.hintsEnabled;
        String[][] steps={{"village","Find a village"},{"charter","Recruit a pioneer"},{"founded","Found your settlement"},{"camp","Establish camp"},{"outpost","Complete the starter huts"},{"home","Build the first residence"},{"farm","Establish a farm"},{"neighbour","Meet a neighbouring town"},{"helped","Help a settlement"},{"town","Reach a working town"},{"allied","Form an alliance"},{"capital","Reach a regional capital"}};
        for(var step:steps)data.milestones.add(new Step(step[1],state.milestones.contains(step[0])));
        if(!state.milestones.contains("founded")){
            if(charter==null)data.requirements.add(new Requirement("minecraft:emerald","Recruitment emeralds",4,0,false));
            else{
                data.requirements.add(new Requirement("minecraft:written_book","Your Village Charter",1,0,true));
                data.requirements.add(new Requirement("minecraft:oak_log","Oak logs",32,0,false));
                data.requirements.add(new Requirement("minecraft:cobblestone","Cobblestone",32,0,false));
                data.requirements.add(new Requirement("minecraft:bread","Bread",16,0,false));
                data.status="Pioneer last seen: "+charter.lastX+", "+charter.lastZ+". Issuing village: "+charter.x+", "+charter.z+".";
            }
        }
        for(var town:towns)if(BackgroundProgress.eligible(town) && state.milestones.contains("founded") && state.visited.contains(town.name) && !town.automatic && owner.equals(town.founder)){
            data.status="Your camp can carry on. You can travel while the starter huts take shape. The town ledger shows current plans and anything that needs your help.";break;
        }
        for(var town:towns)if(state.visited.contains(town.name))data.places.add(town.name+" | "+TownProgress.stage(town)+" | "+town.dimension+" | "+town.x+", "+town.y+", "+town.z);
        for(var town:towns)if(town.name.equals(state.waypointTown) && WaypointRules.known(town,state,owner)){
            data.waypointTown=town.name;data.waypointDimension=town.dimension;data.waypointX=town.x;data.waypointZ=town.z;break;
        }
        for(var town:towns)if(WaypointRules.known(town,state,owner))data.knownPlaces.add(new Place(town.name,TownProgress.stage(town),town.dimension,town.x,town.y,town.z));
        if(!state.trackedQuest.isEmpty())for(var town:towns)if(town.quest!=null && town.quest.id.equals(state.trackedQuest)){
            var q=town.quest;data.mode="quest";data.title="Written Request";data.objective=q.title;data.detail=q.reason;
            data.requirements.clear();data.requirements.add(new Requirement(switch(q.resource){case "wood"->"minecraft:oak_log";case "stone"->"minecraft:cobblestone";default->"minecraft:bread";},TownQuests.itemName(q.resource),q.amount,q.progress,false));
            data.status="Delivered "+q.progress+" / "+q.amount+". Drop supplies at the Quest Master's feet while carrying the request book. Town: "+town.name+" ("+town.x+", "+town.z+").";
            break;
        }
        if(state.trackedCourier && state.courier!=null && !state.courier.phase.equals("complete")){
            var q=state.courier;data.mode="courier";data.title="Town correspondence";data.objective=q.phase.equals("return")?"Bring the reply home":"Deliver the sealed letter";
            data.detail=q.sender+" of "+q.source+" asked you to carry news to "+q.recipient+" of "+q.destination+". Topic: "+q.topic+".";
            data.dispatchId=q.id;data.dispatchPhase=q.phase;data.requirements.clear();data.requirements.add(new Requirement("minecraft:written_book",q.phase.equals("return")?"Signed reply":"Sealed letter",1,0,false));
            data.status="Drop the book beside the steward in "+q.target()+". "+q.escrow+" emerald(s) reserved at "+q.source+" when the reply is returned.";
            for(var town:towns)if(town.name.equals(q.target())){data.waypointTown=town.name;data.waypointDimension=town.dimension;data.waypointX=town.x;data.waypointZ=town.z;break;}
        }
        return data;
    }
}

package dev.livingworld;

import java.util.*;

/** Persistent observations of actual player and settlement progress. No timers unlock buildings. */
public final class PlayerJourney {
    public boolean journalGiven;
    public boolean hintsEnabled=true;
    public boolean checklistEnabled=true;
    public String trackedQuest="";
    public String waypointTown="";
    public CourierQuest courier;
    public boolean trackedCourier;
    public long nextCourierAt;
    public String lastHint="";
    public Set<String> contextHints=new HashSet<>();
    public long hintAt=-1200;
    public Set<String> milestones=new LinkedHashSet<>();
    public Set<String> visited=new LinkedHashSet<>();
    public Map<String,Long> greeted=new HashMap<>();
    private static final Set<String> KNOWN=Set.of("village","charter","founded","camp","outpost","home","farm","grown","town","city","capital","neighbour","helped","allied");
    public void validate(){
        if(courier!=null)courier.validate();if(nextCourierAt<0)throw new IllegalArgumentException("Invalid correspondence schedule");
        if(contextHints==null)contextHints=new HashSet<>();
        if(contextHints.size()>8 || contextHints.stream().anyMatch(s->s==null || s.length()>40))throw new IllegalArgumentException("Invalid context hint state");
        if(waypointTown==null)waypointTown="";
        if(!waypointTown.isEmpty() && !waypointTown.matches("[A-Za-z0-9_-]{1,24}"))throw new IllegalArgumentException("Invalid town trail");
        if(trackedQuest==null)trackedQuest="";
        if(trackedQuest.length()>64)throw new IllegalArgumentException("Invalid tracked request");
        if(lastHint==null)lastHint="";
        if(lastHint.length()>160)throw new IllegalArgumentException("Invalid hint state");
        if(milestones==null)milestones=new LinkedHashSet<>();if(visited==null)visited=new LinkedHashSet<>();if(greeted==null)greeted=new HashMap<>();
        if(!KNOWN.containsAll(milestones) || visited.size()>32 || greeted.size()>32 || visited.stream().anyMatch(s->s==null || !s.matches("[A-Za-z0-9_-]{1,24}"))
            || greeted.entrySet().stream().anyMatch(e->e.getKey()==null || !e.getKey().matches("[A-Za-z0-9_-]{1,24}") || e.getValue()==null || e.getValue()<0))throw new IllegalArgumentException("Invalid player journal");
    }
    public boolean observe(String player,boolean inVillage,boolean charter,List<Settlement> towns,List<Settlement> nearby){
        int before=milestones.size()+visited.size();
        if(inVillage || charter)milestones.add("village");if(charter)milestones.add("charter");
        for(var s:nearby){if(visited.size()<32)visited.add(s.name);if(s.automatic && s.camp!=null && s.camp.complete)milestones.add("neighbour");}
        for(var s:towns){
            if(s.relation(player)>0)milestones.add("helped");if(s.alliances.getOrDefault(player,false))milestones.add("allied");
            if(!s.expedition || s.automatic || !player.equals(s.founder))continue;
            milestones.add("founded");
            if(s.camp!=null && s.camp.complete)milestones.add("camp");
            if(s.colonyReady && s.starterSites.size()==2 && s.starterSites.stream().allMatch(p->p.complete))milestones.add("outpost");
            if(Economy.count(s,"residence")>0)milestones.add("home");if(Economy.count(s,"farmer")>0)milestones.add("farm");
            switch(TownProgress.stage(s)){
                case "Capital":milestones.add("capital");
                case "City":milestones.add("city");
                case "Town":milestones.add("town");
                case "Village":milestones.add("grown");
                default:break;
            }
        }
        return before!=milestones.size()+visited.size();
    }
    public record Objective(String title,String detail){}
    public Objective objective(){
        if(!milestones.contains("founded")){
            if(!milestones.contains("village"))return new Objective("Find a village","Explore for a Minecraft village. Trade to earn four emeralds, then ask an adult villager about founding a town.");
            if(!milestones.contains("charter"))return new Objective("Recruit a pioneer","Carry four emeralds. Crouch-right-click an adult village villager with an empty hand to receive a charter.");
            return new Objective("Choose your new home","Escort your pioneer 256 blocks from their village. Bring the charter, 32 oak logs, 32 cobblestone and 16 bread. Use J > Council > Found here.");
        }
        if(!milestones.contains("camp"))return new Objective("Establish camp","Stay within 192 blocks of the founding point. Give the worksite space and lead your pioneer to the completed camp.");
        if(!milestones.contains("outpost"))return new Objective("Raise the outpost","Once your pioneer joins camp, you can leave. Starter huts continue in the background using saved, player-visited work areas. Build shows any blockers.");
        if(!milestones.contains("home"))return new Objective("A roof for new settlers","Let the builder finish the first residence. Check their requests and food supply if work pauses.");
        if(!milestones.contains("farm"))return new Objective("Put down roots","Help the town reach its first completed farm. Speak to the Quest Master for local requests.");
        if(!milestones.contains("neighbour"))return new Objective("Meet your neighbours","Explore beyond your town. Visit an NPC settlement and record it here. Village gazettes can describe nearby towns.");
        if(!milestones.contains("helped"))return new Objective("Become a trusted visitor","Complete a Quest Master's request or donate useful supplies to earn local reputation.");
        if(!milestones.contains("town"))return new Objective("Build a working town","Grow housing, farms, storage and delivery jobs. The town milestone needs 12 residents and completed services.");
        if(!milestones.contains("allied"))return new Objective("Make an alliance","Earn 40 reputation with a settlement, then record an alliance in Controls. Military assistance is not available yet.");
        if(!milestones.contains("capital"))return new Objective("A regional capital","Support housing, food, health, education and defence. Watch the town's next milestone as it grows.");
        return new Objective("Keep the region thriving","Maintain supplies, help neighbouring towns and check that homes and workplaces stay accessible.");
    }
}

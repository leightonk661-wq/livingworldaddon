package dev.livingworld;
import com.minecolonies.api.entity.citizen.AbstractEntityCitizen;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import java.util.*;
/** One town per second; only healthy, idle adults receive additional local social navigation. */
public final class CitizenLifeService {
    private static final Map<AbstractEntityCitizen,Long> SOCIAL=new WeakHashMap<>();
    private final Map<UUID,Long> conversations=new HashMap<>();private final Map<String,Integer> meetingCursor=new HashMap<>();private int clock,turn;
    public void reset(){SOCIAL.clear();conversations.clear();meetingCursor.clear();clock=turn=0;}
    public static boolean ownsRoutine(AbstractEntityCitizen citizen){
        var data=citizen.getCitizenData();return data!=null && data.getJob()==null && !data.isAsleep() && !data.isChild() && data.getSaturation()>=6
            && citizen.getTarget()==null && SOCIAL.getOrDefault(citizen,-1L)>citizen.level().getGameTime();
    }
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save){
        if(++clock<20 || towns.isEmpty())return;clock=0;var town=towns.get(Math.floorMod(turn++,towns.size()));
        if(!town.colonyReady || town.colonyId<=0)return;
        for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(town.dimension)){
            try{
                var colony=ColonyBridge.colony(town,level);var citizens=colony.getCitizenManager().getCitizens();boolean dirty=false;
                var present=new HashSet<Integer>();
                for(var data:citizens){
                    present.add(data.getId());var life=town.residents.get(data.getId());
                    if(life!=null && !life.uuid.equals(data.getUUID().toString())){town.residents.remove(data.getId());for(var old:town.residents.values()){old.acquaintances.remove(data.getId());old.metDays.remove(data.getId());}life=null;dirty=true;}
                    if(life==null){if(town.residents.size()>=128)continue;life=new CitizenLife();life.id=data.getId();life.uuid=data.getUUID().toString();life.name=data.getName();life.trait=new String[]{"Sociable","Practical","Quiet","Curious"}[Math.floorMod(Objects.hash(town.name,life.id),4)];town.residents.put(life.id,life);dirty=true;}
                    String role=data.getId()==town.questMasterCitizenId?"Steward":data.getJob()==null?"Settler":DashboardData.friendly(data.getJob().getClass().getSimpleName().replaceFirst("^Job",""));
                    String activity=CitizenLife.activity(level.getOverworldClockTime(),data.getJob()!=null,data.isAsleep());if(role.equals("Steward"))activity="Keeping the town's correspondence";
                    if(!life.name.equals(data.getName()) || !life.role.equals(role) || !life.activity.equals(activity) || !life.present){life.name=data.getName();life.role=role;life.activity=activity;life.present=true;dirty=true;}
                    var entity=data.getEntity().orElse(null);
                    long time=Math.floorMod(level.getOverworldClockTime(),24000);
                    if(entity==null || data.getId()==town.questMasterCitizenId || !town.governorEnabled || data.getJob()!=null || data.isAsleep() || data.isChild() || data.getSaturation()<6 || entity.getTarget()!=null || time>=12000
                        || level.players().stream().noneMatch(p->p.distanceToSqr(entity)<96*96)){if(entity!=null)SOCIAL.remove(entity);continue;}
                    var target=QuestMaster.post(town,level);
                    if(time>=2000 && time<9000){
                        var market=town.expansions.stream().filter(e->e.complete && e.kind.equals("warehouse")).findFirst().orElse(null);
                        int x=market==null?(town.camp==null?town.x:town.camp.minX-3):market.x-6,z=market==null?(town.camp==null?town.z:town.camp.minZ+town.camp.depth/2):market.z;
                        if(life.trait.equals("Quiet") && data.getHomeBuilding()!=null){var corners=data.getHomeBuilding().getCorners();x=Math.min(corners.getA().getX(),corners.getB().getX())-3;z=corners.getA().getZ();}
                        var chunk=level.getChunkSource().getChunkNow(x>>4,z>>4);
                        if(chunk!=null){int y=chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);var point=new BlockPos(x,y,z);
                            if(chunk.getBlockState(point).isAir() && chunk.getBlockState(point.above()).isAir() && chunk.getBlockState(point.below()).isCollisionShapeFullBlock(level,point.below()))target=point;}
                    }
                    if(target==null || entity.distanceToSqr(target.getX(),target.getY(),target.getZ())>48*48)continue;
                    // Require the complete pathfinding rectangle to be loaded before asking native navigation.
                    boolean loaded=true;for(int x=(Math.min(entity.blockPosition().getX(),target.getX())-16)>>4;x<=(Math.max(entity.blockPosition().getX(),target.getX())+16)>>4;x++)for(int z=(Math.min(entity.blockPosition().getZ(),target.getZ())-16)>>4;z<=(Math.max(entity.blockPosition().getZ(),target.getZ())+16)>>4;z++)if(level.getChunkSource().getChunkNow(x,z)==null)loaded=false;
                    if(!loaded)continue;
                    SOCIAL.put(entity,level.getGameTime()+Math.max(100,20L*towns.size()+20));
                    if(entity.distanceToSqr(target.getX()+.5,target.getY(),target.getZ()+.5)>5*5 && entity.getNavigation().isDone())entity.getNavigation().moveTo(target.getX()+.5,target.getY(),target.getZ()+.5,0.75);
                }
                for(var life:town.residents.values())if(life.present && !present.contains(life.id)){life.present=false;dirty=true;}
                var loaded=citizens.stream().filter(c->c.getEntity().isPresent() && !c.isAsleep()).toList();
                if(loaded.size()>1){int cursor=meetingCursor.getOrDefault(town.name,0);meetingCursor.put(town.name,cursor+1);var a=loaded.get(Math.floorMod(cursor,loaded.size()));var entity=a.getEntity().orElseThrow();var b=loaded.stream().filter(c->c.getId()!=a.getId() && entity.distanceToSqr(c.getEntity().orElseThrow())<=6*6).findFirst().orElse(null);
                    if(b!=null){var first=town.residents.get(a.getId());var second=town.residents.get(b.getId());if(first!=null && second!=null){long day=level.getGameTime()/24000;dirty|=first.meet(second,day);dirty|=second.meet(first,day);}}
                }
                if(dirty)save.run();
            }catch(RuntimeException e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Town life inspection failed for {}",town.name,e);}break;
        }
    }
    public void speak(ServerPlayer player,Settlement town,int citizenId,Runnable save){
        long now=player.level().getGameTime();if(now-conversations.getOrDefault(player.getUUID(),-100L)<40)return;conversations.put(player.getUUID(),now);
        var life=town.residents.get(citizenId);if(life==null)return;boolean known=life.visitors.containsKey(player.getUUID().toString());
        if(life.remember(player.getUUID().toString(),now/24000))save.run();
        String greeting=known?"Good to see you again.":"I'm "+life.name+". Welcome to "+town.name+".";
        player.sendSystemMessage(net.minecraft.network.chat.Component.literal(life.name+": "+greeting+" "+life.activity+". "+(life.acquaintances.isEmpty()?"I'm still finding my feet here.":"You may know "+life.familiar(town)+".")));
    }
}

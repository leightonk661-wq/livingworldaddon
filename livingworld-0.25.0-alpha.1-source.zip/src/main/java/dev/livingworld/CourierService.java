package dev.livingworld;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.component.*;
import net.minecraft.server.network.Filterable;
import net.minecraft.network.chat.Component;
import java.util.*;
public final class CourierService {
    private int clock;
    public void reset(){clock=0;}
    public static boolean matches(ItemStack stack,CourierQuest q){return q!=null && !q.phase.equals("complete") && q.id.equals(JournalBooks.marker(stack,"livingworld_dispatch")) && q.phase.equals(JournalBooks.marker(stack,"livingworld_dispatch_stage"));}
    public static ItemStack book(CourierQuest q){
        var stack=new ItemStack(Items.WRITTEN_BOOK);var tag=new CompoundTag();tag.putString("livingworld_dispatch",q.id);tag.putString("livingworld_dispatch_stage",q.phase);stack.set(DataComponents.CUSTOM_DATA,CustomData.of(tag));
        var pages=BookPages.fit(List.of((q.phase.equals("return")?"A signed reply":"A sealed letter")+"\n\nFrom "+(q.phase.equals("return")?q.recipient:q.sender)+" of "+(q.phase.equals("return")?q.destination:q.source)+" to "+(q.phase.equals("return")?q.sender:q.recipient)+" of "+q.target()+".\n\n"+q.topic,
            "Take this to the steward of "+q.target()+". Drop it at their feet. A letter outward and a reply home build trust between the towns. Your reward is reserved at "+q.source+"."));
        stack.set(DataComponents.WRITTEN_BOOK_CONTENT,new WrittenBookContent(Filterable.passThrough(q.phase.equals("return")?"Signed reply":"Sealed dispatch"),q.phase.equals("return")?q.recipient:q.sender,0,pages.stream().map(p->Filterable.<Component>passThrough(Component.literal(p))).toList(),true));return stack;
    }
    public void request(ServerPlayer player,Settlement from,PlayerJourney journey,List<Settlement> towns,long now){
        var active=journey.courier;
        if(active!=null && !active.phase.equals("complete")){
            if(!from.name.equals(active.source) && !from.name.equals(active.destination)){player.sendSystemMessage(Component.literal("Your current letter belongs with "+active.target()+"."));return;}
        }else{
            if(now<journey.nextCourierAt){player.sendSystemMessage(Component.literal("There is no new correspondence for you today."));return;}
            var target=towns.stream().filter(t->t!=from && t.colonyReady && t.questMasterCitizenId>0 && t.dimension.equals(from.dimension) && WaypointRules.known(t,journey,player.getUUID().toString()) && t.residents.containsKey(t.questMasterCitizenId))
                .sorted(Comparator.<Settlement,Boolean>comparing(t->RegionRules.key(t.x,t.z).equals(RegionRules.key(from.x,from.z)))
                .thenComparingDouble(t->Math.hypot(t.x-from.x,t.z-from.z))).findFirst().orElse(null);
            if(target==null){player.sendSystemMessage(Component.literal("Visit another settled town and meet its steward. Then we can exchange letters."));return;}
            try{journey.courier=CourierQuest.issue(player.getUUID().toString(),from,target,now);}catch(IllegalArgumentException e){player.sendSystemMessage(Component.literal(e.getMessage()));return;}
        }
        var q=journey.courier;boolean carried=false;
        for(int i=0;i<player.getInventory().getContainerSize();i++)if(matches(player.getInventory().getItem(i),q))carried=true;
        if(!carried && !matches(player.getOffhandItem(),q))player.getInventory().placeItemBackInInventory(book(q));
        journey.trackedCourier=true;journey.trackedQuest="";
        player.sendSystemMessage(Component.literal("Carry the "+(q.phase.equals("return")?"reply":"sealed letter")+" to "+q.target()+". Read it to follow the trail."));
    }
    public void tick(MinecraftServer server,Map<String,PlayerJourney> journeys,List<Settlement> towns,Runnable save){
        if(++clock<10)return;clock=0;
        for(var player:server.getPlayerList().getPlayers()){
            var journey=journeys.get(player.getUUID().toString());var q=journey==null?null:journey.courier;if(q==null || q.phase.equals("complete"))continue;
            var source=towns.stream().filter(t->t.name.equals(q.source)).findFirst().orElse(null);var target=towns.stream().filter(t->t.name.equals(q.destination)).findFirst().orElse(null);
            var at=q.phase.equals("return")?source:target;
            if(source==null || target==null || at.questMasterCitizenId<=0 || !at.dimension.equals(player.level().dimension().identifier().toString()) || player.distanceToSqr(at.x,at.y,at.z)>160*160)continue;
            try{
                var steward=ColonyBridge.colony(at,player.level()).getCitizenManager().getCivilian(at.questMasterCitizenId);var entity=steward==null?null:steward.getEntity().orElse(null);
                if(entity==null || player.distanceToSqr(entity)>8*8)continue;
                for(var drop:player.level().getEntitiesOfClass(ItemEntity.class,entity.getBoundingBox().inflate(2.5),e->e.isAlive() && e.getAge()<400 && matches(e.getItem(),q))){
                    if(!(drop.getOwner() instanceof ServerPlayer owner) || !owner.getUUID().equals(player.getUUID()))continue;
                    String phase=JournalBooks.marker(drop.getItem(),"livingworld_dispatch_stage");
                    if(!q.accept(player.getUUID().toString(),at,source,target,phase))continue;
                    var remaining=drop.getItem().copy();remaining.shrink(1);if(remaining.isEmpty())drop.discard();else drop.setItem(remaining);
                    if(q.phase.equals("complete")){journey.nextCourierAt=player.level().getGameTime()+24000;journey.trackedCourier=false;}
                    save.run();
                    if(q.phase.equals("return")){player.getInventory().placeItemBackInInventory(book(q));player.sendSystemMessage(Component.literal(q.recipient+" signs a reply. Bring it back to "+q.source+"."));}
                    else{journey.nextCourierAt=player.level().getGameTime()+24000;journey.trackedCourier=false;player.sendSystemMessage(Component.literal("The exchange is complete. Speak to the steward to collect your reserved reward."));}
                    break;
                }
            }catch(RuntimeException e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Courier hand-in failed for {}",player.getName().getString(),e);}
        }
    }
}

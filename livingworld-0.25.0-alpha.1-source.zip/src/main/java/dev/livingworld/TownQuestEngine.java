package dev.livingworld;

import com.minecolonies.api.entity.citizen.AbstractEntityCitizen;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.*;

/** Periodically offers one saved request per town and lets nearby citizens speak it aloud. */
public final class TownQuestEngine {
    private final Map<UUID,Map<String,String>> heard=new HashMap<>();
    private int clock;
    public void reset(){heard.clear();clock=0;}
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save){
        if(clock%5==0)deliverDrops(server,towns,save);
        if(++clock<100)return;clock=0;
        var online=new HashSet<UUID>();for(var player:server.getPlayerList().getPlayers())online.add(player.getUUID());
        heard.keySet().retainAll(online);
        for(var town:towns){
            ServerLevel level=null;
            for(var candidate:server.getAllLevels())if(candidate.dimension().identifier().toString().equals(town.dimension)){level=candidate;break;}
            if(level==null)continue;
            try{
                var offered=TownQuests.offer(town,level.getGameTime());
                if(offered!=null){TownProgress.record(town,"Settlers requested "+offered.amount+" "+TownQuests.itemName(offered.resource));save.run();}
                var quest=town.quest;
                if(quest==null || town.colonyId<=0)continue;
                for(var player:level.players()){
                    if(player.distanceToSqr(town.x,town.y,town.z)>128*128)continue;
                    var seen=heard.computeIfAbsent(player.getUUID(),unused->new HashMap<>());
                    if(quest.id.equals(seen.get(town.name)))continue;
                    var citizens=level.getEntitiesOfClass(AbstractEntityCitizen.class,player.getBoundingBox().inflate(10),
                        citizen->citizen.isAlive() && QuestMaster.matches(town,citizen));
                    if(citizens.isEmpty())continue;
                    var speaker=citizens.stream().min(Comparator.comparingDouble(player::distanceToSqr)).orElseThrow();
                    player.sendSystemMessage(Component.literal("["+town.name+"] "+speaker.getName().getString()+": "+quest.reason+
                        " Bring "+quest.amount+" "+TownQuests.itemName(quest.resource)+". Right-click me for details."));
                    seen.put(town.name,quest.id);
                }
            }catch(Exception e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Could not update quest at {}",town.name,e);}
        }
    }
    private void deliverDrops(MinecraftServer server,List<Settlement> towns,Runnable save){
        for(var town:towns){
            var q=town.quest;
            if(q==null || town.questMasterCitizenId<=0 || !town.colonyReady)continue;
            for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(town.dimension)){
                try{
                    var hall=QuestMaster.hall(town);
                    if(hall==null || level.players().stream().noneMatch(p->p.distanceToSqr(hall.x,hall.y,hall.z)<24*24))break;
                    var data=ColonyBridge.colony(town,level).getCitizenManager().getCivilian(town.questMasterCitizenId);
                    var master=data==null?null:data.getEntity().orElse(null);
                    if(master==null || !master.isAlive())break;
                    for(var item:level.getEntitiesOfClass(ItemEntity.class,master.getBoundingBox().inflate(2.5),e->e.isAlive() && e.getAge()<400 && e.getItem().is(TownQuests.item(q.resource)))){
                        if(town.quest!=q)break;
                        ServerPlayer player=item.getOwner() instanceof ServerPlayer owner && owner.level()==level?owner:null;
                        if(player==null || player.distanceToSqr(master)>8*8 || !TownQuestBook.carries(player,q))continue;
                        int accepted=TownQuests.acceptableDrop(town,item.getItem().getCount());
                        if(accepted<=0)continue;
                        var remaining=item.getItem().copy();remaining.shrink(accepted);
                        if(remaining.isEmpty())item.discard();else item.setItem(remaining);
                        boolean completed=q.progress+accepted==q.amount;
                        int coins=TownQuests.acceptDrop(town,player.getUUID().toString(),accepted,level.getGameTime());
                        if(completed){
                            player.sendSystemMessage(Component.literal("Quest complete for "+town.name+". Reputation is shared by contribution."));
                            if(coins>0){
                                ServerPlayer recipient=null;
                                try{recipient=server.getPlayerList().getPlayer(UUID.fromString(TownQuests.rewardRecipient(q,player.getUUID().toString())));}catch(IllegalArgumentException ignored){}
                                if(recipient!=null)recipient.sendSystemMessage(Component.literal("An emerald reward is waiting at "+town.name+". Speak to the Quest Master to collect it."));
                            }
                        }else player.sendSystemMessage(Component.literal("Quest delivery: "+q.progress+" / "+q.amount+" "+TownQuests.itemName(q.resource)+" received."));
                        save.run();
                    }
                }catch(Exception e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Could not accept quest delivery at {}",town.name,e);}
                break;
            }
        }
    }
}

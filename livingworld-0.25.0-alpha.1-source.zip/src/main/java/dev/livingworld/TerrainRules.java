package dev.livingworld;

/** Native MineColonies builders excavate and build foundations inside the surveyed blueprint. */
public final class TerrainRules {
    public static final int MAX_RELIEF=6;
    private static final java.util.List<int[]> SITES=new java.util.ArrayList<>();
    static {for(int radius=24;radius<=64;radius+=8)for(int x=-radius;x<=radius;x+=8)for(int z=-radius;z<=radius;z+=8)if(Math.max(Math.abs(x),Math.abs(z))==radius)SITES.add(new int[]{x,z});}
    public static final int SEARCH_SITES=SITES.size();
    public static boolean buildable(int low,int high,int anchorGround,int foundationDepth){
        // Keep the hut on real ground, with bounded foundation depth below lower edges.
        return low<=anchorGround && anchorGround<=high && high-low<=MAX_RELIEF
            && anchorGround-low<=Math.min(3,Math.max(0,foundationDepth));
    }
    public static int[] candidate(int attempt){
        return SITES.get(Math.floorMod(attempt,SEARCH_SITES)).clone();
    }
}

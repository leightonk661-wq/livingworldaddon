package dev.livingworld;
import java.util.*;
public final class RoadPlan {
    public String id=UUID.randomUUID().toString(),destination="",status="Reserved approach",activePath="";
    public int cursor;public boolean issued,complete;
    public long retryAt;
    public List<RouteSearch.Point> points=new ArrayList<>();
    public List<String> ground=new ArrayList<>();
    public void validate(){
        if(id==null || !id.matches("[0-9a-f-]{36}") || destination==null || status==null || activePath==null
            || points==null || ground==null || points.size()>256 || points.isEmpty() || points.size()!=ground.size()
            || cursor<0 || cursor>points.size() || retryAt<0 || (complete && cursor!=points.size()))throw new IllegalArgumentException("Invalid approach plan");
        for(int i=0;i<points.size();i++){
            var p=points.get(i);if(p==null || ground.get(i)==null)throw new IllegalArgumentException("Invalid approach cell");
            if(i>0){var a=points.get(i-1);if(Math.abs((long)p.x()-a.x())+Math.abs((long)p.z()-a.z())!=1 || Math.abs(p.y()-a.y())>1)throw new IllegalArgumentException("Disconnected approach");}
        }
        if(!activePath.isEmpty() && !activePath.matches("road_[0-9a-f-]{36}_[0-9]{1,3}\\.blueprint"))throw new IllegalArgumentException("Invalid road blueprint path");
    }
    public boolean intersects(int minX,int maxX,int minZ,int maxZ){return points.stream().anyMatch(p->p.x()>=minX-1 && p.x()<=maxX+1 && p.z()>=minZ-1 && p.z()<=maxZ+1);}
}

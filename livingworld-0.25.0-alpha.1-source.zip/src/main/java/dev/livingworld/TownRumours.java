package dev.livingworld;

import java.util.*;

/** Pure selection/text logic: never explores terrain or creates a settlement. */
public final class TownRumours {
    public static final int INTERACTION_RADIUS=128;
    public static boolean withinRange(String dimension, double x,double y,double z,Settlement s){
        double dx=x-(s.x+.5),dy=y-s.y,dz=z-(s.z+.5);
        return dimension.equals(s.dimension) && dx*dx+dy*dy+dz*dz<=INTERACTION_RADIUS*INTERACTION_RADIUS;
    }
    public static boolean villageLoot(String id){return id.startsWith("minecraft:chests/village/");}
    private static long distance(Settlement s,int x,int z){long dx=(long)s.x-x,dz=(long)s.z-z;return dx*dx+dz*dz;}
    public static List<String> pages(List<Settlement> towns,String dimension,int x,int z){
        var nearby=towns.stream().filter(s->s.dimension.equals(dimension)
            && (s.colonyReady || s.camp!=null && s.camp.complete)
            && distance(s,x,z)<=8192L*8192).sorted(Comparator.comparingLong(s->distance(s,x,z))).limit(3).toList();
        var pages=new ArrayList<String>();
        pages.add("Travellers' Gazette\n\nCollected in the village near X "+x+", Z "+z+".\n\n"+
            (nearby.isEmpty()?"No confirmed settlements within eight thousand blocks have reached our ears yet. Seek fresh reports in other villages.":"Travellers report "+nearby.size()+" nearby settlements. Directions are measured from this village. These reports may age as towns grow."));
        for(var s:nearby){
            String direction=direction(s.x-x,s.z-z);
            pages.add(s.name.replace('_',' ')+"\n\n"+(s.colonyReady?"A growing settlement":"An expedition's supply camp")+
                " lies "+direction+", about "+Math.round(Math.sqrt(distance(s,x,z)))+" blocks away.\n\nX: "+s.x+"\nY: "+s.y+"\nZ: "+s.z+
                "\n\n"+s.distantProjects.size()+" distant projects reported; "+s.pendingMigrants+" migrants awaiting homes.\nTravellers bearing timber, stone or bread may find a welcome.");
        }
        return pages;
    }
    static String direction(int dx,int dz){
        if(dx==0 && dz==0)return "here";
        double angle=Math.atan2(dx,-dz);
        return new String[]{"north","north-east","east","south-east","south","south-west","west","north-west"}[Math.floorMod((int)Math.round(angle/(Math.PI/4)),8)];
    }
}

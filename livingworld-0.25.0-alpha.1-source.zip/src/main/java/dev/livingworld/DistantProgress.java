package dev.livingworld;
import java.util.*;
/** Pure, bounded simulation. No chunks, native citizens, inventories, clocks or terrain APIs. */
public final class DistantProgress {
    public static boolean supported(String kind){return Set.of("residence","farmer","warehouse","deliveryman","lumberjack","miner","hospital","guardtower","school","university","barracks").contains(kind==null?"":kind);}
    public static boolean established(Settlement s){return s.expedition && s.colonyReady && s.economyPopulation>0 && s.starterSites.size()==2 && s.starterSites.stream().allMatch(p->p.complete);}
    public static int completed(Settlement s,String kind){
        return Economy.count(s,kind)+(int)s.distantProjects.stream().filter(p->p.ready() && p.kind.equals(kind)).count()
            +(int)s.expansions.stream().filter(e->!e.complete && e.assembly!=null && kind.equals(e.kind)).count();
    }
    public static DistantProject ready(Settlement s){return s.distantProjects.stream().filter(DistantProject::ready).findFirst().orElse(null);}
    public static boolean assembling(Settlement s){return s.expansions.stream().anyMatch(e->!e.complete && e.assembly!=null);}
    public static Expansion reserve(Settlement s,DistantProject project,SitePlan site){
        project.validate();site.validate();
        if(!project.ready() || !s.distantProjects.contains(project) || s.expansions.size()>=48
            || !project.kind.equals(site.kind) || !project.pack.equals(site.pack) || !site.autoAssembly
            || site.before.size()!=site.width*site.depth*site.height
            || s.expansions.stream().anyMatch(e->project.id.equals(e.projectId)))throw new IllegalArgumentException("Invalid or already consumed distant reservation");
        var e=new Expansion();e.projectId=project.id;e.pack=site.pack;e.path=site.path;e.kind=site.kind;e.x=site.x;e.y=site.y;e.z=site.z;e.assembly=site;e.registrationPending=true;
        s.expansions.add(e);s.distantProjects.remove(project);return e;
    }
    private static int planned(Settlement s,String kind){return (int)s.expansions.stream().filter(e->kind.equals(e.kind)).count()+(int)s.distantProjects.stream().filter(p->p.ready() && kind.equals(p.kind)).count();}
    public static String next(Settlement s){return TownPlanner.next(s,kind->planned(s,kind));}
    public static void step(Settlement s){step(s,true);}
    public static void step(Settlement s,boolean away){
        var cfg=LivingWorldSettings.current;
        if(!s.governorEnabled || s.pendingDeparture)return;
        if(!cfg.distantProgression || !s.distantEnabled){s.distantMessage="Distant projects disabled; existing queue preserved";return;}
        if(!established(s)){s.distantMessage=BackgroundProgress.eligible(s)?"Background rotation completing the starter huts before later projects":"First settler must join camp before background construction";return;}
        if(away)s.distantCycles=Math.min(Long.MAX_VALUE-1,s.distantCycles+1);
        if(away){
            int labor=Math.max(0,Math.min(32,s.economyPopulation)-1);
            for(String kind:List.of("farmer","lumberjack","miner"))labor-=Math.min(labor,Economy.count(s,kind));
            int virtualFarmers=Math.min(labor,Math.min(3,completed(s,"farmer")-Economy.count(s,"farmer")));labor-=virtualFarmers;
            int virtualLumberjacks=Math.min(labor,Math.min(2,completed(s,"lumberjack")-Economy.count(s,"lumberjack")));labor-=virtualLumberjacks;
            int virtualMiners=Math.min(labor,Math.min(2,completed(s,"miner")-Economy.count(s,"miner")));
            s.food=Math.min(512,s.food+6*virtualFarmers);
            s.wood=Math.min(512,s.wood+4*virtualLumberjacks);
            s.stone=Math.min(512,s.stone+3*virtualMiners);
        }
        // Economy.step supplies the baseline. Pay abstract upkeep only while distant; no NPC inventories are edited.
        int upkeep=away?Math.max(1,(s.economyPopulation+s.pendingMigrants+3)/4):0;
        if(s.food<upkeep){s.distantMessage="Distant work paused: food shortage";return;}
        s.food-=upkeep;
        if(away && s.distantCycles%20==0 && s.pendingMigrants<16 && s.economyPopulation+s.pendingMigrants<Math.min(32,completed(s,"residence")*4) && s.food>=Economy.reserve(s)+16 && s.treasury>=4){
            s.food-=16;s.treasury-=4;s.pendingMigrants++;TownProgress.record(s,"A migrant reserved a place; arrival pending real housing capacity");
        }
        var active=s.distantProjects.stream().filter(p->!p.ready()).findFirst().orElse(null);
        if(active!=null){
            active.progress++;
            if(active.ready()){TownProgress.record(s,"Distant project finished: "+active.kind+"; terrain placement pending");s.distantMessage="Completed "+active.kind+" off-screen; awaiting a loaded site";}
            else s.distantMessage="Distant "+active.kind+": "+active.progress+" / "+active.required+" work cycles";
            return;
        }
        if(!away){s.distantMessage=ready(s)!=null?"Completed distant projects awaiting terrain placement":"Local simulation; no new distant projects started";return;}
        if(s.expansions.size()+s.distantProjects.size()>=cfg.maxExpansions){s.distantMessage="Settlement development limit reached ("+cfg.maxExpansions+")";return;}
        if(s.distantProjects.size()>=cfg.distantQueueLimit){s.distantMessage="Return queue full; visit to place completed projects";return;}
        // A partly built native job remains exclusively native. Do not simulate or pay for it twice.
        String kind=next(s);if(kind==null){s.distantMessage="Capital plan complete; maintaining food, trade and housing";return;}var cost=Economy.cost(kind);
        if(s.wood<cost.wood() || s.stone<cost.stone() || s.food<cost.food()+Economy.reserve(s) || s.treasury<cost.coins()){
            s.distantMessage="Saving for distant "+kind+": "+cost;return;
        }
        var p=new DistantProject();p.id=UUID.randomUUID().toString();p.kind=kind;p.pack=s.expansionPack;p.required=cfg.distantProjectCycles;
        p.wood=cost.wood();p.stone=cost.stone();p.food=cost.food();p.coins=cost.coins();
        s.wood-=p.wood;s.stone-=p.stone;s.food-=p.food;s.treasury-=p.coins;s.distantProjects.add(p);
        TownProgress.record(s,"Funded distant "+kind+": "+cost);s.distantMessage="Started distant "+kind+"; resources reserved once";
    }
    public static void validate(Settlement s){
        if(s.distantProjects==null)s.distantProjects=new ArrayList<>();if(s.distantMessage==null)s.distantMessage="Not yet simulated";
        if(s.expansions.size()+s.distantProjects.size()>48 || s.distantProjects.size()>16 || s.distantCycles<0 || s.pendingMigrants<0 || s.pendingMigrants>16)throw new IllegalArgumentException("Invalid distant simulation state");
        Set<String> ids=new HashSet<>();for(var p:s.distantProjects){if(p==null)throw new IllegalArgumentException("Missing distant project");p.validate();if(!ids.add(p.id))throw new IllegalArgumentException("Duplicate distant project");}
        if(s.distantProjects.stream().filter(p->!p.ready()).count()>1)throw new IllegalArgumentException("Multiple active distant projects");
        for(var e:s.expansions){
            if(e.registrationPending && e.assembly==null)throw new IllegalArgumentException("Registration pending without a terrain reservation");
            if(e.projectId!=null && !e.projectId.isEmpty() && !ids.add(e.projectId))throw new IllegalArgumentException("Project exists twice");
            if(e.assembly!=null){e.assembly.validate();if((e.registrationPending && (e.projectId==null || e.projectId.isEmpty())) || !e.kind.equals(e.assembly.kind) || !e.pack.equals(e.assembly.pack) || !e.path.equals(e.assembly.path) || e.x!=e.assembly.x || e.y!=e.assembly.y || e.z!=e.assembly.z)throw new IllegalArgumentException("Invalid assembly reservation");}
        }
    }
}

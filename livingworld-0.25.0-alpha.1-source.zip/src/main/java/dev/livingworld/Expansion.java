package dev.livingworld;
public final class Expansion {
    public String pack,path,kind;
    public int x,y,z;
    public boolean complete;
    public String projectId="";
    public SitePlan assembly;
    public boolean registrationPending;
}

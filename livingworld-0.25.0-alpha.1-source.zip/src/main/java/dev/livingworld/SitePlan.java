package dev.livingworld;
/** Persistent reservation for the expedition camp and its two first worker-built huts. */
public final class SitePlan {
    public String pack,path,kind;
    public int x,y,z,minX,minY,minZ,width,height,depth,cursor;
    public boolean complete,autoAssembly;
    public java.util.List<String> before=new java.util.ArrayList<>();
    public java.util.List<CampTerrain.Change> groundwork=new java.util.ArrayList<>();
    public int groundworkCursor;
    public void validate(){
        if(before==null)before=new java.util.ArrayList<>();
        if(groundwork==null)groundwork=new java.util.ArrayList<>();
        if(groundwork.size()>18432 || groundworkCursor<0 || groundworkCursor>groundwork.size())throw new IllegalArgumentException("Invalid camp groundwork journal");
        for(var c:groundwork)if(c==null || c.before==null || c.x<minX || c.x>=minX+width || c.z<minZ || c.z>=minZ+depth || c.y<y-4 || c.y>y+4)throw new IllegalArgumentException("Groundwork outside camp bounds");
        if(before.size()>147456)throw new IllegalArgumentException("Oversized site journal");
        if(pack==null || path==null || kind==null || width<1 || width>48 || depth<1 || depth>48 || height<1 || height>64
            || cursor<0 || cursor>width*height*depth*2 || x<minX || x>=minX+width || z<minZ || z>=minZ+depth || y<minY || y>=minY+height)
            throw new IllegalArgumentException("Invalid expedition reservation");
        if(kind.equals("camp") && !complete && before.size()!=width*height*depth)throw new IllegalArgumentException("Incomplete camp terrain journal");
        if(autoAssembly && !complete && before.size()!=width*height*depth)throw new IllegalArgumentException("Incomplete automatic starter journal");
    }
}

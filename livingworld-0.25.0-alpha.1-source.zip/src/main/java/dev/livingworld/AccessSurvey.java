package dev.livingworld;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.minecolonies.api.colony.IColonyManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.*;

/** Checks a predicted blueprint entrance, then a loaded-terrain route from the camp perimeter. */
public final class AccessSurvey {
    private final ServerLevel level;private final Settlement town;private final SitePlan site;private final Blueprint bp;
    private int scan,visits,attempt;private boolean seeded;
    private final List<BlockPos> doors=new ArrayList<>(),exits=new ArrayList<>();
    private final Queue<BlockPos> queue=new ArrayDeque<>();private final Set<BlockPos> seen=new HashSet<>();
    private final Map<Long,Integer> heights=new HashMap<>();private final Set<Long> invalid=new HashSet<>();
    private final Map<Long,Integer> knownRoads=new HashMap<>();private final List<int[]> buildings=new ArrayList<>();
    private RouteSearch route;public boolean done;public RoadPlan result;public String reason="Checking doors and foundations";
    public AccessSurvey(ServerLevel level,Settlement town,SitePlan site,Blueprint bp){this.level=level;this.town=town;this.site=site;this.bp=bp;
        for(var road:town.roads)for(var p:road.points)knownRoads.put(((long)p.x()<<32)^(p.z()&0xffffffffL),p.y());
        if(town.colonyId>0)for(var b:ColonyBridge.colony(town,level).getServerBuildingManager().getBuildings().values()){
            var box=b.getCorners();buildings.add(new int[]{Math.min(box.getA().getX(),box.getB().getX()),Math.max(box.getA().getX(),box.getB().getX()),Math.min(box.getA().getZ(),box.getB().getZ()),Math.max(box.getA().getZ(),box.getB().getZ())});
        }
    }
    private boolean inside(int x,int z){return x>=site.minX && x<site.minX+site.width && z>=site.minZ && z<site.minZ+site.depth;}
    private BlockState predicted(BlockPos local){
        if(local.getY()<0 || local.getY()>=site.height)return Blocks.AIR.defaultBlockState();
        var state=bp.getBlockState(local);String id=BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
        if(id.equals("structurize:blocksubstitution"))return level.getBlockState(new BlockPos(site.minX,site.minY,site.minZ).offset(local));
        if(id.equals("structurize:blocksolidsubstitution"))return Blocks.COBBLESTONE.defaultBlockState();
        return state;
    }
    private boolean passable(BlockState b){return FoundingEngine.soft(b) || b.getBlock() instanceof DoorBlock;}
    private boolean walkable(BlockPos p){
        if(p.getX()<0 || p.getX()>=site.width || p.getZ()<0 || p.getZ()>=site.depth || p.getY()<1 || p.getY()+1>=site.height)return false;
        var floor=predicted(p.below());
        return floor.getFluidState().isEmpty() && (floor.isSolidRender() || floor.getBlock() instanceof StairBlock || floor.getBlock() instanceof SlabBlock)
            && passable(predicted(p)) && passable(predicted(p.above()));
    }
    private static boolean in(SitePlan p,int x,int z){return p!=null && x>=p.minX && x<p.minX+p.width && z>=p.minZ && z<p.minZ+p.depth;}
    private Integer height(int x,int z){
        long key=((long)x<<32)^(z&0xffffffffL);if(heights.containsKey(key))return heights.get(key);if(invalid.contains(key))return null;
        if(inside(x,z) || in(town.camp,x,z) || town.starterSites.stream().anyMatch(p->in(p,x,z))){invalid.add(key);return null;}
        var chunk=level.getChunkSource().getChunkNow(x>>4,z>>4);if(chunk==null){invalid.add(key);return null;}
        int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,x,z);
        for(int n=0;n<4 && FoundingEngine.soft(chunk.getBlockState(new BlockPos(x,y,z)));n++)y--;
        var p=new BlockPos(x,y,z);var ground=chunk.getBlockState(p);
        boolean knownRoad=Objects.equals(knownRoads.get(key),y);
        var claim=IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),p);
        if(claim==null || claim.getID()!=town.colonyId || (!FoundingEngine.natural(ground) && !(knownRoad && ground.is(Blocks.COBBLESTONE)))
            || FoundingEngine.soft(ground) || !ground.getFluidState().isEmpty() || chunk.getBlockEntity(p)!=null
            || !FoundingEngine.soft(chunk.getBlockState(p.above())) || !FoundingEngine.soft(chunk.getBlockState(p.above(2)))){invalid.add(key);return null;}
        // Building footprints must never become roads, including older colonies without starter plans.
        for(var box:buildings)if(x>=box[0] && x<=box[1] && z>=box[2] && z<=box[3]){invalid.add(key);return null;}
        heights.put(key,y);return y;
    }
    public void tick(){
        if(done)return;
        int volume=site.width*site.height*site.depth;
        if(scan<volume){
            for(int n=0;n<128 && scan<volume;n++,scan++){
                var p=new BlockPos(scan%site.width,scan/(site.width*site.depth),(scan/site.width)%site.depth);
                var state=bp.getBlockState(p);
                if(state.getBlock() instanceof DoorBlock && state.getValue(DoorBlock.HALF)==DoubleBlockHalf.LOWER && Math.abs(p.getY()-bp.getPrimaryBlockOffset().getY())<=3 && walkable(p))doors.add(p);
            }
            return;
        }
        if(!seeded){
            if(doors.isEmpty()){
                var anchor=bp.getPrimaryBlockOffset();for(var d:new int[][]{{1,0},{0,1},{-1,0},{0,-1}}){var p=anchor.offset(d[0],0,d[1]);if(walkable(p))doors.add(p);}
            }
            for(var p:doors)if(seen.add(p))queue.add(p);seeded=true;
        }
        if(!queue.isEmpty() && visits<4096){
            for(int n=0;n<32 && !queue.isEmpty() && visits++<4096;n++){
                var p=queue.remove();
                for(var d:new int[][]{{1,0},{0,1},{-1,0},{0,-1}}){
                    int x=site.minX+p.getX()+d[0],z=site.minZ+p.getZ()+d[1];
                    if(!inside(x,z)){
                        Integer y=height(x,z);if(y!=null && Math.abs(y-(site.minY+p.getY()-1))<=1 && exits.size()<32){var exit=new BlockPos(x,y,z);if(!exits.contains(exit))exits.add(exit);}continue;
                    }
                    for(int dy:new int[]{0,1,-1}){var next=p.offset(d[0],dy,d[1]);if(walkable(next) && seen.add(next))queue.add(next);}
                }
            }
            return;
        }
        if(exits.isEmpty()){done=true;reason="No supported walkable entrance in this blueprint at this height";return;}
        if(route==null){
            if(attempt==0)exits.sort(Comparator.comparingLong(p->(long)(p.getX()-town.x)*(p.getX()-town.x)+(long)(p.getZ()-town.z)*(p.getZ()-town.z)));
            if(attempt>=Math.min(4,exits.size())){done=true;reason="No safe loaded-terrain route from camp to entrance";return;}
            var target=exits.get(attempt++);BlockPos start=null;double best=Double.MAX_VALUE;
            var camp=town.camp;
            if(camp==null){done=true;reason="Approach survey needs a camp";return;}
            for(int x=camp.minX-1;x<=camp.minX+camp.width;x++)for(int z=camp.minZ-1;z<=camp.minZ+camp.depth;z++){
                if(in(camp,x,z))continue;Integer y=height(x,z);if(y==null || Math.abs(y-(camp.y-1))>1)continue;
                double dist=target.distSqr(new BlockPos(x,y,z));if(dist<best){best=dist;start=new BlockPos(x,y,z);}
            }
            if(start==null){done=true;reason="Camp has no clear walking exit";return;}
            route=new RouteSearch(new RouteSearch.Point(start.getX(),start.getY(),start.getZ()),new RouteSearch.Point(target.getX(),target.getY(),target.getZ()),this::height);
        }
        reason="Checking walkable route to "+site.kind;route.step(24);
        if(!route.done)return;
        if(route.route.isEmpty()){route=null;return;}
        result=new RoadPlan();result.destination=site.kind+" at "+site.x+", "+site.z;result.points.addAll(route.route);
        for(var p:result.points){
            var chunk=level.getChunkSource().getChunkNow(p.x()>>4,p.z()>>4);var pos=new BlockPos(p.x(),p.y(),p.z());
            if(chunk==null){result=null;done=true;reason="Route chunks unloaded before reservation";return;}
            var state=chunk.getBlockState(pos);
            if((!FoundingEngine.natural(state) && !state.is(Blocks.COBBLESTONE)) || FoundingEngine.soft(state) || chunk.getBlockEntity(pos)!=null
                || !FoundingEngine.soft(chunk.getBlockState(pos.above())) || !FoundingEngine.soft(chunk.getBlockState(pos.above(2)))){result=null;done=true;reason="Route terrain changed during survey";return;}
            result.ground.add(state.toString());
        }
        result.validate();done=true;reason="Entrance and "+result.points.size()+"-block approach checked";
    }
}

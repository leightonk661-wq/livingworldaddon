package dev.livingworld;
import java.util.*;
public final class TownNames {
    private TownNames(){}
    public static String next(String style,Collection<Settlement> towns,int seed){
        String s=style==null?"":style.toLowerCase(Locale.ROOT);
        String[] roots=s.contains("spruce")||s.contains("nordic")?new String[]{"Pine","Fir","Frost","North"}:
            s.contains("birch")?new String[]{"Birch","Silver","White","Dawn"}:
            s.contains("desert")||s.contains("sand")?new String[]{"Sun","Dune","Amber","Sand"}:
            s.contains("jungle")?new String[]{"Fern","Moss","Green","Rain"}:new String[]{"Oak","Willow","Alder","Hazel"};
        String[] ends={"haven","mere","ford","brook","field","watch","stead","vale","ridge","grove","wick","hollow"};
        for(int n=0;n<roots.length*ends.length;n++){
            int i=Math.floorMod((long)seed+n,roots.length*ends.length);String name=roots[i/ends.length]+ends[i%ends.length];
            if(towns.stream().noneMatch(t->t.name.equalsIgnoreCase(name)))return name;
        }
        for(int n=1;n<=1000;n++){String name="NewHaven_"+n;if(towns.stream().noneMatch(t->t.name.equalsIgnoreCase(name)))return name;}
        throw new IllegalStateException("No unused town name");
    }
}

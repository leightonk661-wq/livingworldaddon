package dev.livingworld.client;
import dev.livingworld.DashboardNetwork;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
/** One quiet card; no sound, queue or permanent objective overlay. */
public final class JourneyHud {
    private static DashboardNetwork.Hint hint;
    private static int age;
    private static Object level;
    public static void register(){
        ClientPlayNetworking.registerGlobalReceiver(DashboardNetwork.Hint.TYPE,(packet,context)->context.client().execute(()->{
            hint=packet.title().isEmpty()?null:packet;age=0;level=context.client().level;
        }));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{
            if(mc.level!=level || mc.player==null){hint=null;level=mc.level;}
            if(hint!=null && ++age>=200)hint=null;
        });
        HudElementRegistry.attachElementBefore(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CHAT,Identifier.parse("livingworld:journey"),(g,delta)->{
            var mc=Minecraft.getInstance();
            if(hint==null || mc.player==null || mc.gui.screen()!=null || mc.getDebugOverlay().showDebugScreen())return;
            float fade=Math.min(1f,Math.min(age/10f,(200-age)/30f));
            int alpha=(int)(255*fade);if(alpha<8)return;
            int width=Math.min(250,g.guiWidth()-20);if(width<100)return;
            var lines=mc.font.split(Component.literal(hint.detail()),width-20);
            int count=Math.min(5,lines.size()),height=42+count*10,x=10,y=10+(JournalClient.hudHeight()==0?0:JournalClient.hudHeight()+8);
            if(y+height>g.guiHeight()-35)return;
            g.fill(x,y,x+width,y+height,((int)(195*fade)<<24)|0x121619);
            g.fill(x,y,x+2,y+height,(alpha<<24)|0xb7a275);
            g.text(mc.font,mc.font.plainSubstrByWidth(hint.title(),width-20),x+10,y+8,(alpha<<24)|0xe0cb97,false);
            for(int n=0;n<count;n++)g.text(mc.font,lines.get(n),x+10,y+22+n*10,(alpha<<24)|0xd0d4d6,false);
            g.text(mc.font,"More in your journal",x+10,y+27+count*10,(alpha<<24)|0x899195,false);
        });
    }
}

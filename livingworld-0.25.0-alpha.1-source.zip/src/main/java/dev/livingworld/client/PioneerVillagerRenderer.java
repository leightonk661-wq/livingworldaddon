package dev.livingworld.client;

import dev.livingworld.PioneerEscort;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.VillagerRenderer;
import net.minecraft.client.renderer.entity.state.VillagerRenderState;
import net.minecraft.world.entity.npc.villager.Villager;

/** Adds Living World's visual travel pack to the recruited village pioneer. */
public final class PioneerVillagerRenderer extends VillagerRenderer {
    public PioneerVillagerRenderer(EntityRendererProvider.Context context){
        super(context);addLayer(new PioneerBackpackLayer(this));
    }
    @Override public void extractRenderState(Villager villager,VillagerRenderState state,float partial){
        super.extractRenderState(villager,state,partial);
        state.setData(PioneerBackpackLayer.PIONEER,villager.getCustomName()!=null && PioneerEscort.MARKER.equals(villager.getCustomName().getString()));
    }
}

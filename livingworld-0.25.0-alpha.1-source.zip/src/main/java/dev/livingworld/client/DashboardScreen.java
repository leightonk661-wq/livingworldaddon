package dev.livingworld.client;

import dev.livingworld.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Non-pausing, server-backed settlement dashboard. All coordinates are GUI-scaled pixels. */
public final class DashboardScreen extends Screen {
    private static final int BG=0xFF292B2E,PANEL=0xFF33363A,LINE=0xFF555A60,TEXT=0xFFE7E7E7,MUTED=0xFFB8BDC4,ACCENT=0xFFE4CB83;
    private DashboardData data;
    private final boolean questMasterView;
    private String selected="",draft="",chosenStyle="",pendingTown="";
    private int tab,resource,scroll,clock,cooldown,left,top,w,h,body,bottom,maxScroll;
    private EditBox nameBox;
    private boolean details;
    public DashboardScreen(DashboardData data){super(Component.literal(data.questMasterView?"Quest Master":"Town Ledger"));this.data=data;this.selected=data.selectedTown;this.questMasterView=data.questMasterView;this.tab=questMasterView?4:0;}
    private DashboardData.Town town(){return data.towns.stream().filter(t->t.name.equals(selected)).findFirst().orElse(null);}
    public void accept(DashboardData next){data=next;if(!pendingTown.isEmpty() && data.towns.stream().anyMatch(t->t.name.equalsIgnoreCase(pendingTown))){selected=data.towns.stream().filter(t->t.name.equalsIgnoreCase(pendingTown)).findFirst().orElseThrow().name;pendingTown="";tab=0;scroll=0;chosenStyle="";}rebuildWidgets();}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void tick(){
        if(minecraft.player==null || minecraft.getConnection()==null){onClose();return;}
        if(cooldown>0 && --cooldown==0)rebuildWidgets();
        if(++clock>=40){clock=0;DashboardClient.request("refresh",selected,"");}
    }
    private void action(String action,String name,String value){
        if(cooldown>0)return;
        if(action.equals("found"))pendingTown=name;
        cooldown=8;data.message="Waiting for server...";DashboardClient.request(action,name,value);rebuildWidgets();
    }
    private void action(String action,String value){var t=town();if(t!=null)action(action,t.name,value);}
    private void moveTown(int delta){
        if(data.towns.isEmpty())return;int index=0;for(int i=0;i<data.towns.size();i++)if(data.towns.get(i).name.equals(selected))index=i;
        selected=data.towns.get(Math.floorMod(index+delta,data.towns.size())).name;scroll=0;chosenStyle="";DashboardClient.request("refresh",selected,"");rebuildWidgets();
    }
    private void changeStyle(int delta){
        if(data.styles.isEmpty())return;int index=data.styles.indexOf(chosenStyle);chosenStyle=data.styles.get(Math.floorMod(index+delta,data.styles.size()));rebuildWidgets();
    }
    @Override protected void init(){
        boolean typing=nameBox!=null && nameBox.isFocused();if(nameBox!=null)draft=nameBox.getValue();nameBox=null;
        w=Math.min(560,width-12);h=Math.min(questMasterView?290:380,height-12);left=(width-w)/2;top=(height-h)/2;
        body=top+(questMasterView?56:84);bottom=top+h-30;
        if(town()==null && !data.towns.isEmpty())selected=data.towns.getFirst().name;
        var t=town();
        button("Close",left+w-58,top+8,48,18,true,this::onClose,"Close dashboard (Esc)");
        if(!questMasterView){
            button("<",left+10,top+31,22,20,!data.towns.isEmpty(),()->moveTown(-1),"Previous settlement");
            button(">",left+w-32,top+31,22,20,!data.towns.isEmpty(),()->moveTown(1),"Next settlement");
            String[] tabs={"Town","Market","Works","Council","Quests","People","Guide"};int cell=(w-20)/tabs.length;
            for(int i=0;i<tabs.length;i++){final int id=i;var b=button(tabs[i],left+10+i*cell,top+58,cell-3,20,true,()->{tab=id;scroll=0;rebuildWidgets();},tabs[i]);if(tab==i)b.setMessage(Component.literal(tabs[i]).withStyle(ChatFormatting.YELLOW,ChatFormatting.UNDERLINE));}
        }
        int x=left+12,cw=w-24;
        if(tab==0 && t!=null)button(t.name.equals(data.waypointTown)?"Clear trail":"Follow trail",x,bottom-24,108,20,t.canMark && cooldown==0,()->action("waypoint",""),"Mark the way to a town you have visited or founded.");
        if(tab==1 && t!=null){
            String[] kinds={"wood","stone","food"};int third=(cw-8)/3;
            for(int i=0;i<3;i++){final int n=i;var b=button(new String[]{"Timber","Stone","Food"}[i],x+i*(third+4),body,third,20,true,()->{resource=n;rebuildWidgets();},"View "+kinds[i]+" market");if(i==resource)b.setMessage(Component.literal(new String[]{"Timber","Stone","Food"}[i]).withStyle(ChatFormatting.YELLOW,ChatFormatting.UNDERLINE));}
            String kind=kinds[resource];int price=t.prices[resource];
            boolean available=t.near && cooldown==0 && data.ready;
            button("Buy 8 ("+price+")",x,body+69,third,22,available,()->action("buy",kind),"Spend "+price+" emeralds for 8 "+kind+". Visit within 128 blocks.");
            button("Sell 8 (1)",x+third+4,body+69,third,22,available,()->action("sell",kind),"Sell 8 "+kind+" for 1 emerald. Town must have funds and space.");
            button("Donate 32",x+2*(third+4),body+69,third,22,available,()->action("supply",kind),"Donate 32 items for reputation. Uses your inventory, including in Creative.");
        }
        if(tab==2 && t!=null){
            if(chosenStyle.isEmpty())chosenStyle=t.style;
            button(details?"Town plans":"Details",left+w-178,top+8,72,18,true,()->{details=!details;scroll=0;rebuildWidgets();},"Show construction details when you need them.");
            int y=bottom-24;
            button("<",x,y,22,20,!data.styles.isEmpty(),()->changeStyle(-1),"Previous building style");
            button(">",x+26,y,22,20,!data.styles.isEmpty(),()->changeStyle(1),"Next building style");
            button("Apply style",left+w-100,y,88,20,(data.operator || t.founder) && t.near && cooldown==0 && !chosenStyle.isEmpty(),()->action("style",chosenStyle),"Founders and operators can apply a style while nearby. An unfinished expansion prevents changes.");
        }
        if(tab==3){
            nameBox=addRenderableWidget(new EditBox(font,x,body,cw-92,20,Component.literal("New settlement name")));
            nameBox.setMaxLength(24);nameBox.setHint(Component.literal("New settlement name"));nameBox.setValue(draft);
            button("Found here",x+cw-88,body,88,20,data.ready && cooldown==0,()->action("found",nameBox.getValue(),""),"In Survival, charter and escort a village villager 256 blocks on foot. Keep them within 16 blocks here; bring the charter, 32 oak logs, 32 cobblestone and 16 bread.");
            int col=(cw-6)/2;int row=body+28;boolean op=data.operator && data.ready && cooldown==0;boolean manager=(data.operator || t!=null && t.founder) && data.ready && cooldown==0;
            boolean nearby=t!=null && t.near;
            button(t!=null && t.enabled?"Pause town plans":"Resume town plans",x,row,col,22,manager && nearby && t!=null && (t.activated || t.expedition),()->action("governor",town().enabled?"off":"on"),"Founders and operators can manage growth within 128 blocks. Existing MineColonies work may continue when paused.");
            button(data.autoFound?"New neighbours: on":"New neighbours: off",x+col+6,row,col,22,op,()->action("autofound",t==null?"World":t.name,data.autoFound?"off":"on"),"NPC expeditions require one manually founded town first. Existing settlements remain when switched off.");
            row+=28;
            button(t!=null && t.allied?"Allied":"Form alliance",x,row,col,22,nearby && cooldown==0 && t.reputation>=40 && !t.allied,()->action("ally",""),"Visit with 40 reputation, earned by donating supplies. Military help is not implemented.");
            button("Try another approach",x+col+6,row,col,22,manager && nearby,()->action("recover",""),"Resume growth, clear failed-site cooldowns and recheck interrupted approaches. Changed terrain remains protected.");
            row+=28;
            button(t!=null && t.distantEnabled?"While away: on":"While away: off",x,row,col,22,manager && t!=null,()->action("distant",town().distantEnabled?"off":"on"),"Allow this town to develop while you travel.");
            if(typing)setInitialFocus(nameBox);
        }
    }
    private Button button(String text,int x,int y,int width,int height,boolean enabled,Runnable run,String tip){
        var b=Button.builder(Component.literal(text),pressed->run.run()).bounds(x,y,width,height).build();b.active=enabled;b.setTooltip(Tooltip.create(Component.literal(tip)));return addRenderableWidget(b);
    }
    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){
        if((tab==0||tab==2||tab==4||tab==5||tab==6) && y>=body && y<bottom){scroll=Math.max(0,Math.min(maxScroll,scroll-(int)(vertical*24)));return true;}
        return super.mouseScrolled(x,y,horizontal,vertical);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){
        g.fill(0,0,width,height,0x99000000);
        panel(g,left,top,w,h,false);
        panel(g,left+8,body-3,w-16,bottom-body+5,true);
        g.item(new ItemStack(Items.WRITABLE_BOOK),left+12,top+8);
        text(g,questMasterView?"Quest Master":"Town Ledger",left+34,top+12,TEXT);
        var t=town();String heading=t==null?"A new journey awaits":t.name+"  /  "+t.tier;
        g.centeredText(font,fit(heading,w-88),left+w/2,top+37,TEXT);
        int x=left+12,cw=w-24;
        g.enableScissor(x,body,left+w-12,bottom);
        if(!data.ready){text(g,"Waiting for the server...",x,body+10,MUTED);}
        else if(t==null && tab!=3 && tab!=6){
            renderLines(g,data.journey,x,body,cw,bottom-body);
        }else if(tab==0){
            g.disableScissor();g.enableScissor(x,body,x+cw,bottom-29);
            int end=TownCards.overview(g,font,t,x,body-scroll,cw-10);finishCards(g,x,body,cw,bottom-body-29,end);
        }else if(tab==1){
            int stock=resource==0?t.wood:resource==1?t.stone:t.food;
            g.item(new ItemStack(resource==0?Items.OAK_LOG:resource==1?Items.COBBLESTONE:Items.BREAD),x,body+25);
            text(g,"Stock: "+stock+" / 512",x+22,body+28,TEXT);
            g.fill(x,body+43,x+cw,body+47,LINE);g.fill(x,body+43,x+(int)(cw*Math.min(1,stock/512.0)),body+47,ACCENT);
            text(g,fit("Town funds: "+t.coins+" emeralds / "+(t.near?"In range":"Visit within 128 blocks"),cw),x,body+54,MUTED);
            if(bottom-body>117)wrap(g,"Uses oak logs, cobblestone or bread from your inventory. Food reserves and available funds can prevent a trade.",x,body+100,cw,MUTED);
        }else if(tab==2){
            g.disableScissor();g.enableScissor(x,body,x+cw,bottom-42);
            if(!details){int end=TownCards.works(g,font,t,x,body-scroll,cw-10);finishCards(g,x,body,cw,bottom-42-body,end);}
            else{var lines=new ArrayList<String>();
            if(!t.detailed)lines.add("Loading selected settlement details...");
            lines.add("#Background work chunks");lines.add(data.rotationStatus);lines.add(t.chunkStatus);
            lines.add("#Current work");lines.add(t.worker);lines.add(t.workStage);lines.add(t.governor);
            if(t.expedition && !t.journey.isEmpty())lines.add("Pioneer journey: "+t.journey);
            lines.add("#Requested materials");
            if(t.requests.isEmpty())lines.add("No open builder requests reported. Automatic deliveries appear in Town.");else lines.addAll(t.requests);
            lines.add("#Supply report");lines.add(t.supply);lines.add("Items supplied: "+t.delivered);
            lines.add("#Settlement stages");
            String[] stages={"Find a suitable camp site","Establish the supply camp","Bring in the first settler","Survey the builder site","Automatic builder hut assembly","Automatic town hall assembly","Expand and recruit"};
            for(int i=0;i<stages.length;i++)lines.add((i<t.milestone?"Done: ":i==t.milestone?"Now: ":"Next: ")+stages[i]);
            lines.add("#Building locations");lines.addAll(t.buildings);
            lines.add("#Approach paths and survey history");if(t.terrain.isEmpty())lines.add("No approaches or rejected sites recorded yet.");else lines.addAll(t.terrain);
            renderLines(g,lines,x,body,cw,bottom-42-body);
            }g.disableScissor();g.enableScissor(x,bottom-42,x+cw,bottom);
            text(g,fit("Future style: "+chosenStyle,cw),x,bottom-38,MUTED);
        }else if(tab==3){
            if(bottom-body>=104)wrap(g,(data.discoveryUnlocked?"Other pioneers may now settle nearby. ":"Found your first town to begin a living region. ")+(data.hasCharter?"Charter ready. Village "+data.charterOrigin+"; pioneer last seen "+data.escortPosition+". Keep them close and travel 256 blocks.":"Crouch-right-click a village villager with an empty hand and 4 emeralds for a charter."),x,body+92,cw,MUTED);
        }else if(tab==4){
            int end=TownCards.request(g,font,t,x,body-scroll,cw-10);finishCards(g,x,body,cw,bottom-body,end);
        }else if(tab==5){
            int end=TownCards.people(g,font,t,x,body-scroll,cw-10);finishCards(g,x,body,cw,bottom-body,end);
        }else if(tab==6){
            renderLines(g,List.of(
                "#Your first settlement",
                "Find a village and earn four emeralds. Crouch-right-click an adult villager with an empty hand to recruit them. Carry the charter, 32 oak logs, 32 cobblestone and 16 bread. Escort the pioneer 256 blocks from their village, then use Council > Found here with them within 16 blocks.",
                "#A camp becomes a home",
                "Stay while the camp is built and your pioneer becomes its first MineColonies settler. The builder's hut and town hall follow. Leave each work area clear so construction can continue safely.",
                "#While you travel",
                "Once the pioneer joins camp, you can leave. Towns take turns progressing in the background. Physical work uses saved chunks players have entered. Works > Details explains any terrain or supply blocker.",
                "#Keeping the builder supplied",
                "Stock the builder's linked chests or camp containers. Builders can collect those materials at the worksite. They still need food, tools, rest and a walkable route.",
                "#Help the community",
                "Ask the Quest Master for a request book. Read it to track the supplies, then drop them at the Quest Master's feet. Open Market to trade or donate useful supplies.",
                "#Earn their trust",
                "Requests and donations build your reputation. At 40 reputation you can form an alliance in Council. The Town page shows how the settlement knows you.",
                "#Follow familiar trails",
                "Choose Follow trail on a town you have founded or visited. A small compass line shows its direction and distance. Your marker clears when you arrive. In your journal, Places > Nearest town marks a known destination away from your current location.",
                "#People and correspondence",
                "People remember residents they meet and travellers who speak to them. Idle adults meet around town; workers keep their normal jobs and rest. Crouch-right-click the steward with an empty hand to carry a sealed letter to another known town, then bring its signed reply home. Drop each book at the receiving steward's feet. Regional ties grow through successful exchanges.",
                "#Read the town's story",
                "Town shows current priorities and a chronicle of recent events. Works shows building plans and progress. Details contains the full construction report when you need it. The world continues running while a menu is open."
            ),x,body,cw,bottom-body);
        }
        g.disableScissor();
        g.fill(left+10,bottom+3,left+w-10,bottom+4,LINE);
        text(g,fit(data.message,w-24),left+12,bottom+11,MUTED);
        if(mx>left+10 && mx<left+w-10 && my>bottom+4 && my<top+h)g.setTooltipForNextFrame(font,Component.literal(data.message),mx,my);
        super.extractRenderState(g,mx,my,delta);
    }
    private void finishCards(GuiGraphicsExtractor g,int x,int y,int width,int available,int end){
        maxScroll=Math.max(0,end+scroll-y-available);scroll=Math.min(scroll,maxScroll);
        if(maxScroll>0){int thumb=Math.max(14,available*available/(available+maxScroll));int sy=y+(available-thumb)*scroll/maxScroll;g.fill(x+width-5,sy,x+width-2,sy+thumb,0xff89969f);}
    }
    private void renderLines(GuiGraphicsExtractor g,List<String> lines,int x,int y,int width,int available){
        int cursor=y-scroll;
        for(String line:lines){
            boolean heading=line.startsWith("#");if(heading){line=line.substring(1);cursor+=6;g.fill(x,cursor-3,x+width-8,cursor+13,PANEL);}
            for(var part:font.split(Component.literal(line),width-18)){g.text(font,part,x+5,cursor,heading?ACCENT:TEXT,false);cursor+=14;}
            cursor+=heading?6:8;
        }
        maxScroll=Math.max(0,cursor+scroll-y-available);scroll=Math.min(scroll,maxScroll);
        if(maxScroll>0){int track=Math.max(12,available);g.fill(x+width-7,y,x+width-1,y+track,0xFF111214);int thumb=Math.max(12,track*available/(available+maxScroll));int ty=y+(track-thumb)*scroll/maxScroll;g.fill(x+width-7,ty,x+width-1,ty+thumb,0xFF999EA5);g.fill(x+width-6,ty+1,x+width-2,ty+2,0xFFCDD0D5);}
    }
    private void wrap(GuiGraphicsExtractor g,String value,int x,int y,int width,int color){for(var line:font.split(Component.literal(value),width)){g.text(font,line,x,y,color,false);y+=12;}}
    private void text(GuiGraphicsExtractor g,String value,int x,int y,int color){g.text(font,value,x,y,color,false);}
    private String fit(String value,int width){return font.width(value)<=width?value:font.plainSubstrByWidth(value,Math.max(0,width-12))+"...";}
    private void panel(GuiGraphicsExtractor g,int x,int y,int width,int height,boolean inset){
        g.fill(x,y,x+width,y+height,inset?0xFF1B1D20:BG);
        int light=inset?0xFF101113:0xFF565B62,dark=inset?0xFF454A50:0xFF121315;
        g.fill(x,y,x+width-1,y+2,light);g.fill(x,y,x+2,y+height-1,light);
        g.fill(x+2,y+height-2,x+width,y+height,dark);g.fill(x+width-2,y+2,x+width,y+height,dark);
        if(!inset)g.outline(x-1,y-1,width+2,height+2,0xFF000000);
    }
}

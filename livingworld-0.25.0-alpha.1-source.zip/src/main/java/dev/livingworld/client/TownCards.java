package dev.livingworld.client;
import dev.livingworld.*;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
/** Compact, scrollable player-facing cards. Diagnostics are rendered separately. */
final class TownCards {
    private final GuiGraphicsExtractor g;private final Font font;private final int x,w;private int y;
    private TownCards(GuiGraphicsExtractor g,Font font,int x,int y,int w){this.g=g;this.font=font;this.x=x;this.y=y;this.w=w;}
    private String fit(String text,int width){return font.plainSubstrByWidth(text,Math.max(1,width));}
    private void heading(String title){g.text(font,title,x+3,y+2,0xffe0cb97,false);y+=18;}
    private void paragraph(String text,int color){for(var line:font.split(Component.literal(text),w-16)){g.text(font,line,x+8,y,color,false);y+=12;}y+=8;}
    private void card(String title,String text){
        var lines=font.split(Component.literal(text),w-18);int height=27+lines.size()*12;
        g.fill(x,y,x+w,y+height,0xff292f34);g.fill(x,y,x+2,y+height,0xffb7a275);
        g.text(font,title,x+8,y+8,0xffe0cb97,false);int row=y+23;
        for(var line:lines){g.text(font,line,x+8,row,0xffc5cdd2,false);row+=12;}y+=height+8;
    }
    private void metric(Item item,String label,String value,int px,int py,int width){
        g.fill(px,py,px+width,py+40,0xff292f34);g.item(new ItemStack(item),px+7,py+11);
        g.text(font,fit(label,width-34),px+29,py+8,0xff9da9b1,false);
        g.text(font,fit(value,width-34),px+29,py+23,0xffe3e7e9,false);
    }
    static int overview(GuiGraphicsExtractor g,Font font,DashboardData.Town t,int x,int y,int width){
        var p=new TownCards(g,font,x,y,width);p.card(t.headline,t.summary);
        int col=(width-12)/3;p.metric(Items.PLAYER_HEAD,"Residents",Integer.toString(t.people),x,p.y,col);p.metric(Items.BREAD,"Food",Integer.toString(t.food),x+col+6,p.y,col);p.metric(Items.EMERALD,"Treasury",Integer.toString(t.coins),x+2*(col+6),p.y,col);p.y+=48;
        int half=(width-6)/2;p.metric(Items.OAK_LOG,"Timber",Integer.toString(t.wood),x,p.y,half);p.metric(Items.COBBLESTONE,"Stone",Integer.toString(t.stone),x+half+6,p.y,half);p.y+=48;
        p.card(t.relationship,"Reputation "+t.reputation+" / 100. "+(t.allied?"The town welcomes you as an ally.":t.reputation>=40?"You can form an alliance in Council.":"Help with requests and supplies to earn the town's trust."));
        p.heading("The next chapter");p.paragraph(t.nextMilestone,0xffd7dde1);
        p.heading("Town chronicle");if(t.news.isEmpty())p.paragraph("Your settlement's story is just beginning.",0xffa5b0b7);else for(String line:t.news)p.paragraph(line,0xffc5cdd2);
        p.paragraph(t.location.replace("minecraft:overworld","Overworld").replace("minecraft:the_nether","Nether"),0xff89969f);return p.y;
    }
    static int works(GuiGraphicsExtractor g,Font font,DashboardData.Town t,int x,int y,int width){
        var p=new TownCards(g,font,x,y,width);p.card("At the worksite",t.workStage.equals("Not started")?t.summary:t.workStage);
        if(!t.requests.isEmpty()){p.heading("Supplies the builder needs");for(String request:t.requests)p.paragraph(request,0xffe0cb97);}
        p.heading("Town plans");
        if(t.projects.isEmpty())p.paragraph("The pioneer is choosing a place for camp.",0xffa5b0b7);
        var projects=new java.util.ArrayList<>(t.projects);projects.sort(java.util.Comparator.comparing(DashboardData.Project::complete));
        for(var project:projects){
            g.fill(x,p.y,x+width,p.y+43,0xff292f34);JournalClient.checkbox(g,x+8,p.y+9,project.complete());
            g.text(font,p.fit(project.name(),width-35),x+24,p.y+9,project.complete()?0xffa9cf9b:0xffe0cb97,false);
            g.text(font,p.fit(project.state(),width-20),x+8,p.y+23,0xffacb8c0,false);
            if(project.percent()>=0){g.fill(x+8,p.y+37,x+width-8,p.y+39,0xff424d55);g.fill(x+8,p.y+37,x+8+(width-16)*project.percent()/100,p.y+39,0xffb7a275);}
            p.y+=49;
        }
        return p.y;
    }
    static int people(GuiGraphicsExtractor g,Font font,DashboardData.Town t,int x,int y,int width){
        var p=new TownCards(g,font,x,y,width);p.card("The people of "+t.name,"Part of "+t.region+". Crouch-right-click a resident with an empty hand to talk. Ask the steward the same way for courier work.");
        if(t.residents.isEmpty())p.paragraph("Meet the first settlers as the town takes shape.",0xffaab4bb);
        for(var person:t.residents){p.card(person.name()+" / "+person.role(),person.trait()+". "+person.activity()+". Knows: "+person.familiar()+".");}
        if(!t.townRelations.isEmpty()){p.heading("News from other towns");for(String relation:t.townRelations)p.paragraph(relation,0xffc5cdd2);}
        return p.y;
    }
    static int request(GuiGraphicsExtractor g,Font font,DashboardData.Town t,int x,int y,int width){
        var p=new TownCards(g,font,x,y,width);
        p.card("Letters between towns","Crouch-right-click the steward with an empty hand for courier work. Visit a second settled town first so you know where its steward lives.");
        if(t.questAmount<=0){p.card("All quiet for now","The Quest Master will have another request when the town needs help.");return p.y;}
        p.card(t.questTitle,t.questReason);p.heading("Bring to the Quest Master");
        Item icon=t.questItem.equals("bread")?Items.BREAD:t.questItem.equals("oak logs")?Items.OAK_LOG:Items.COBBLESTONE;
        g.item(new ItemStack(icon),x+8,p.y);g.text(font,t.questProgress+" / "+t.questAmount+" "+t.questItem+" delivered",x+31,p.y+5,0xffdce3e7,false);p.y+=25;
        g.fill(x+8,p.y,x+width-8,p.y+5,0xff424d55);g.fill(x+8,p.y,x+8+(width-16)*t.questProgress/Math.max(1,t.questAmount),p.y+5,0xffa9cf9b);p.y+=17;
        p.paragraph("Ask the Quest Master for the request book, then drop supplies at their feet while carrying it. You can deliver a little at a time.",0xffc5cdd2);
        p.card("A town remembers its helpers","Earn shared reputation for your contribution. If the town has funds, the largest contributor can collect an emerald from the Quest Master.");return p.y;
    }
}

package dev.livingworld.client;
import dev.livingworld.*;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.resources.Identifier;
/** Physical books open the screen; nothing in this UI transfers items or completes a quest. */
public final class JournalClient {
    private static JournalData data;
    private static Object connection;
    public static void register(){
        UseItemCallback.EVENT.register((player,world,hand)->{
            if(!world.isClientSide() || !JournalBooks.supported(player.getItemInHand(hand)) || !ClientPlayNetworking.canSend(DashboardNetwork.Request.TYPE))return InteractionResult.PASS;
            DashboardClient.request("book","",hand.name());return InteractionResult.FAIL;
        });
        ClientPlayNetworking.registerGlobalReceiver(DashboardNetwork.Journal.TYPE,(packet,context)->context.client().execute(()->{
            try{
                var next=new Gson().fromJson(packet.json(),JournalData.class);if(next==null)return;
                data=next;connection=context.client().getConnection();
                if(packet.open())context.client().gui.setScreen(new JournalScreen(next));
                else if(context.client().gui.screen() instanceof JournalScreen screen)screen.accept(next);
            }catch(RuntimeException e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Unreadable journal response",e);}
        }));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{if(mc.getConnection()!=connection){data=null;connection=mc.getConnection();}});
        HudElementRegistry.attachElementBefore(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CHAT,Identifier.parse("livingworld:checklist"),(g,delta)->{
            var mc=Minecraft.getInstance();int height=hudHeight();
            if(height==0 || mc.gui.screen()!=null || mc.getDebugOverlay().showDebugScreen())return;
            int x=10,y=10,width=Math.min(208,g.guiWidth()-20);
            if(g.guiHeight()<height+50 || width<160)return;
            g.fill(x,y,x+width,y+height,0xc3121619);g.fill(x,y,x+2,y+height,0xffb7a275);
            int row=y;
            if(!data.requirements.isEmpty()){
                g.text(mc.font,mc.font.plainSubstrByWidth(data.mode.equals("courier")?"Town correspondence":data.mode.equals("quest")?"Quest supplies":"Pack for your journey",width-18),x+9,y+6,0xffe0cb97,false);
                row=y+21;
                for(var requirement:data.requirements){drawRequirement(g,data,requirement,x+8,row,width-16);row+=20;}
                row+=4;
            }
            if(!data.waypointTown.isEmpty()){
                g.item(new ItemStack(Items.COMPASS),x+7,row+8);
                g.text(mc.font,mc.font.plainSubstrByWidth(data.waypointTown,width-36),x+29,row+5,0xffe0cb97,false);
                String dimension=mc.level.dimension().identifier().toString();
                String trail=dimension.equals(data.waypointDimension)?WaypointRules.bearing(data.waypointX-mc.player.getX(),data.waypointZ-mc.player.getZ())+" / "+(int)Math.ceil(Math.hypot(data.waypointX-mc.player.getX(),data.waypointZ-mc.player.getZ()))+" blocks":DashboardData.friendly(data.waypointDimension);
                g.text(mc.font,mc.font.plainSubstrByWidth(trail,width-36),x+29,row+18,0xffb4bec5,false);
            }
        });
    }
    public static int hudHeight(){
        if(data==null || !data.checklistEnabled || Minecraft.getInstance().player==null)return 0;
        return (data.requirements.isEmpty()?0:25+20*data.requirements.size())+(data.waypointTown.isEmpty()?0:34);
    }
    public static Item item(String id){return switch(id){case "minecraft:emerald"->Items.EMERALD;case "minecraft:oak_log"->Items.OAK_LOG;case "minecraft:cobblestone"->Items.COBBLESTONE;case "minecraft:bread"->Items.BREAD;default->Items.WRITTEN_BOOK;};}
    public static int count(JournalData view,JournalData.Requirement requirement){
        var player=Minecraft.getInstance().player;if(player==null)return 0;int count=0;
        // Founding consumes main inventory only. Quest drops may also be held in the offhand.
        for(int i=0;i<36;i++)count+=countStack(view,requirement,player.getInventory().getItem(i));
        if(view.mode.equals("quest") || view.mode.equals("courier"))count+=countStack(view,requirement,player.getOffhandItem());
        return count;
    }
    private static int countStack(JournalData data,JournalData.Requirement r,ItemStack stack){
        if(data.mode.equals("courier") && r.item().equals("minecraft:written_book"))return data.dispatchId.equals(JournalBooks.marker(stack,"livingworld_dispatch")) && data.dispatchPhase.equals(JournalBooks.marker(stack,"livingworld_dispatch_stage"))?stack.getCount():0;
        if(r.exactCharter())return !data.charterToken.isEmpty() && data.charterToken.equals(JournalBooks.marker(stack,"livingworld_charter"))?1:0;
        return stack.is(item(r.item()))?stack.getCount():0;
    }
    public static void checkbox(GuiGraphicsExtractor g,int x,int y,boolean checked){
        int c=checked?0xffa9cf9b:0xff7c858a;g.outline(x,y,9,9,c);
        if(checked){g.fill(x+2,y+4,x+4,y+6,c);g.fill(x+4,y+3,x+6,y+5,c);g.fill(x+6,y+2,x+7,y+4,c);}
    }
    public static void drawRequirement(GuiGraphicsExtractor g,JournalData data,JournalData.Requirement r,int x,int y,int width){
        var mc=Minecraft.getInstance();int have=count(data,r),need=JournalData.remaining(r);boolean ready=JournalData.ready(r,have);
        checkbox(g,x,y+4,ready);g.item(new ItemStack(item(r.item())),x+14,y);
        String amount=Math.min(have,need)+" / "+need;
        int right=x+width-mc.font.width(amount);
        g.text(mc.font,mc.font.plainSubstrByWidth(r.label(),Math.max(25,right-x-39)),x+35,y+5,0xffd0d4d6,false);
        g.text(mc.font,amount,right,y+5,ready?0xffa9cf9b:0xffd0d4d6,false);
    }
}

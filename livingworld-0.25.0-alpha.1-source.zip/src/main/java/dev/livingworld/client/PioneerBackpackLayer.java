package dev.livingworld.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.VillagerRenderState;
import net.minecraft.client.model.npc.VillagerModel;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

/** A small visual rucksack; its inventory is deliberately not a storage container. */
public final class PioneerBackpackLayer extends RenderLayer<VillagerRenderState,VillagerModel> {
    public static final RenderStateDataKey<Boolean> PIONEER=RenderStateDataKey.create();
    private static final Identifier TEXTURE=Identifier.parse("livingworld:textures/entity/pioneer_pack.png");
    private final PackModel pack=new PackModel();
    public PioneerBackpackLayer(RenderLayerParent<VillagerRenderState,VillagerModel> parent){super(parent);}
    @Override public void submit(PoseStack pose,SubmitNodeCollector collector,int light,VillagerRenderState state,float limbSwing,float limbSwingAmount){
        if(!state.getDataOrDefault(PIONEER,false) || state.isInvisible || state.isBaby)return;
        collector.submitModel(pack,state,pose,TEXTURE,light,OverlayTexture.NO_OVERLAY,-1,null);
    }
    private static final class PackModel extends EntityModel<VillagerRenderState> {
        PackModel(){super(model().bakeRoot());}
        private static LayerDefinition model(){
            var mesh=new MeshDefinition();var root=mesh.getRoot();
            root.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-5,5,3,10,12,5),PartPose.ZERO);
            root.addOrReplaceChild("flap",CubeListBuilder.create().texOffs(0,17).addBox(-5.5f,4.5f,7.7f,11,4,1),PartPose.ZERO);
            root.addOrReplaceChild("left_strap",CubeListBuilder.create().texOffs(24,0).addBox(-4.5f,5,-4.2f,2,11,1),PartPose.ZERO);
            root.addOrReplaceChild("right_strap",CubeListBuilder.create().texOffs(30,0).addBox(2.5f,5,-4.2f,2,11,1),PartPose.ZERO);
            root.addOrReplaceChild("roll",CubeListBuilder.create().texOffs(36,0).addBox(-4,3,4,8,3,4),PartPose.ZERO);
            return LayerDefinition.create(mesh,64,32);
        }
    }
}

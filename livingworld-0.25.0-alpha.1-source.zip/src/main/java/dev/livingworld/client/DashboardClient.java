package dev.livingworld.client;
import dev.livingworld.*;
import com.google.gson.Gson;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
public final class DashboardClient implements ClientModInitializer {
    public void onInitializeClient(){
        JourneyHud.register();
        JournalClient.register();
        if(!net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded(HumanoidVillagers.MOD))EntityRendererRegistry.register(net.minecraft.world.entity.EntityTypes.VILLAGER,PioneerVillagerRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(DashboardNetwork.Snapshot.TYPE,(packet,context)->context.client().execute(()->{
            var mc=context.client();
            try{
                var data=new Gson().fromJson(packet.json(),DashboardData.class);
                if(data==null)return;
                if(packet.open())mc.gui.setScreen(new DashboardScreen(data));
                else if(mc.gui.screen() instanceof DashboardScreen screen)screen.accept(data);
            }catch(RuntimeException e){org.slf4j.LoggerFactory.getLogger("livingworld").error("Dashboard response could not be read",e);}
        }));
        var key=KeyMappingHelper.registerKeyMapping(new KeyMapping("key.livingworld.dashboard",org.lwjgl.glfw.GLFW.GLFW_KEY_J,KeyMapping.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(mc->{while(key.consumeClick())if(mc.player!=null && mc.gui.screen()==null){
            if(ClientPlayNetworking.canSend(DashboardNetwork.Request.TYPE)){
                var loading=new DashboardData();loading.message="Opening the town ledger...";mc.gui.setScreen(new DashboardScreen(loading));request("refresh","","");
            }else mc.player.sendOverlayMessage(Component.literal("This server does not support the Living World dashboard."));
        }});
    }
    public static void request(String action,String town,String value){
        if(Minecraft.getInstance().getConnection()!=null && ClientPlayNetworking.canSend(DashboardNetwork.Request.TYPE))
            ClientPlayNetworking.send(new DashboardNetwork.Request(action,town,value));
    }
}


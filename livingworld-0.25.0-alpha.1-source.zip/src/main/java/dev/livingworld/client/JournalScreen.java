package dev.livingworld.client;
import dev.livingworld.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
/** Spacious, scrollable companion to the physical journal and request books. */
public final class JournalScreen extends Screen {
    private JournalData data;
    private int tab,scroll,maxScroll,left,top,w,h,body,bottom,clock,cooldown;
    public JournalScreen(JournalData data){super(Component.literal(data.title));this.data=data;}
    public void accept(JournalData next){data=next;rebuildWidgets();}
    @Override public boolean isPauseScreen(){return false;}
    @Override protected void init(){
        w=Math.min(520,width-12);h=Math.min(350,height-12);left=(width-w)/2;top=(height-h)/2;body=top+66;bottom=top+h-35;
        button("Close",left+w-53,top+8,43,this::onClose);
        String[] tabs={"Current","Milestones","Places"};int cell=(w-24)/3;
        for(int i=0;i<3;i++){final int n=i;button((tab==i?"> ":"")+tabs[i],left+12+i*cell,top+37,cell-4,()->{tab=n;scroll=0;rebuildWidgets();});}
        int bw=(w-28)/3;
        button(data.checklistEnabled?"HUD: on":"HUD: off",left+10,top+h-27,bw,()->request("checklist"));
        button(tab==2?(data.waypointTown.isEmpty()?"Nearest town":"Clear trail"):"Track journey",left+14+bw,top+h-27,bw,()->{if(tab==2)DashboardClient.request("waypoint","",data.waypointTown.isEmpty()?"":"clear");else request("trackjourney");});
        button("Town ledger",left+18+2*bw,top+h-27,bw,()->{DashboardClient.request("refresh","","");minecraft.gui.setScreen(new DashboardScreen(new DashboardData()));});
    }
    private void button(String label,int x,int y,int width,Runnable action){addRenderableWidget(Button.builder(Component.literal(label),b->action.run()).bounds(x,y,width,20).build());}
    private void request(String action){if(cooldown>0)return;cooldown=6;DashboardClient.request(action,"","");}
    @Override public void tick(){
        if(minecraft.player==null || minecraft.getConnection()==null){onClose();return;}
        if(cooldown>0)cooldown--;
        if(++clock>=40){clock=0;DashboardClient.request("journalrefresh","","");}
    }
    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){
        if(y>=body && y<bottom){scroll=Math.max(0,Math.min(maxScroll,scroll-(int)(vertical*22)));return true;}
        return super.mouseScrolled(x,y,horizontal,vertical);
    }
    private int paragraph(GuiGraphicsExtractor g,String text,int x,int y,int width,int color){
        for(var line:font.split(Component.literal(text),width)){g.text(font,line,x,y,color,false);y+=11;}return y+8;
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){
        g.fill(0,0,width,height,0x99000000);g.fill(left,top,left+w,top+h,0xff202529);g.outline(left,top,w,h,0xff59636a);
        g.item(new ItemStack(Items.WRITTEN_BOOK),left+12,top+9);g.text(font,data.title,left+35,top+13,0xffe0cb97,false);
        int x=left+15,cw=w-32,y=body+4-scroll;g.enableScissor(left+10,body,left+w-10,bottom);
        if(tab==0){
            y=paragraph(g,data.objective,x,y,cw,0xffe0cb97);y=paragraph(g,data.detail,x,y,cw,0xffe0e4e6);
            if(!data.requirements.isEmpty()){
                y=paragraph(g,(data.mode.equals("quest") || data.mode.equals("courier"))?"Ready to deliver (carried items)":"Supplies in your main inventory",x,y,cw,0xff9faab2);
                for(var r:data.requirements){g.fill(x,y-2,x+cw,y+20,0xff2c3338);JournalClient.drawRequirement(g,data,r,x+6,y,cw-12);y+=25;}
                boolean ready=data.requirements.stream().allMatch(r->JournalData.ready(r,JournalClient.count(data,r)));
                y=paragraph(g,ready?((data.mode.equals("quest") || data.mode.equals("courier"))?"Supplies ready. Return to the Quest Master to deliver them.":"Supplies ready. Follow the objective above."):"Unchecked items are still needed.",x,y+3,cw,ready?0xffa9cf9b:0xffaab4bb);
                if(data.mode.equals("quest")){
                    var r=data.requirements.getFirst();int bar=Math.max(1,cw-4);
                    y=paragraph(g,"Delivered to town: "+r.delivered()+" / "+r.amount(),x,y,cw,0xffe0cb97);
                    g.fill(x,y,x+bar,y+5,0xff414b52);g.fill(x,y,x+bar*r.delivered()/Math.max(1,r.amount()),y+5,0xffa9cf9b);y+=15;
                }
            }
            if(!data.status.isEmpty())y=paragraph(g,data.status,x,y+4,cw,0xffaab4bb);
            y=paragraph(g,"Open your journal to track your journey, or open a current request book to track that quest. The HUD can be hidden with the button below.",x,y+6,cw,0xff89969f);
        }else if(tab==1){
            int done=(int)data.milestones.stream().filter(JournalData.Step::complete).count();y=paragraph(g,"Your story: "+done+" / "+data.milestones.size()+" milestones",x,y,cw,0xffe0cb97);
            g.fill(x,y,x+cw,y+5,0xff414b52);g.fill(x,y,x+cw*done/Math.max(1,data.milestones.size()),y+5,0xffb7a275);y+=16;
            for(var step:data.milestones){JournalClient.checkbox(g,x,y+1,step.complete());y=paragraph(g,step.label(),x+17,y,cw-17,step.complete()?0xffa9cf9b:0xffc9d0d4);}
        }else{
            y=paragraph(g,"Familiar places",x,y,cw,0xffe0cb97);
            y=paragraph(g,data.waypointTown.isEmpty()?"Choose Nearest town below to find a familiar destination, or mark a specific town from its ledger.":"Following the trail to "+data.waypointTown+".",x,y,cw,0xffaab4bb);
            if(data.knownPlaces.isEmpty())y=paragraph(g,"Found or visit a settlement to learn its location.",x,y,cw,0xffaab4bb);
            for(var place:data.knownPlaces){
                g.fill(x,y,x+cw,y+54,0xff2c3338);g.item(new ItemStack(Items.COMPASS),x+7,y+9);
                g.text(font,font.plainSubstrByWidth(place.name()+" / "+place.stage(),cw-37),x+30,y+10,0xffe0cb97,false);
                g.text(font,font.plainSubstrByWidth(DashboardData.friendly(place.dimension()),cw-37),x+30,y+24,0xffc5cdd2,false);
                g.text(font,place.x()+", "+place.y()+", "+place.z(),x+30,y+38,0xff89969f,false);y+=61;
            }

        }
        maxScroll=Math.max(0,y+scroll-bottom+8);scroll=Math.min(scroll,maxScroll);g.disableScissor();
        if(maxScroll>0){int track=bottom-body;int thumb=Math.max(14,track*track/(track+maxScroll));int sy=body+(track-thumb)*scroll/maxScroll;g.fill(left+w-7,sy,left+w-4,sy+thumb,0xff89969f);}
        super.extractRenderState(g,mx,my,delta);
    }
}

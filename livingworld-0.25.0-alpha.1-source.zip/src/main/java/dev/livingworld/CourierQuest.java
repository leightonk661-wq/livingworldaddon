package dev.livingworld;
import java.util.*;
/** One owner-bound, two-stage physical dispatch. Escrow and state make copied books harmless. */
public final class CourierQuest {
    public String id="",owner="",source="",destination="",sender="",recipient="",topic="",phase="outbound";
    public int escrow;public long issued;
    public String target(){return phase.equals("return")?source:destination;}
    public void validate(){
        UUID.fromString(id);UUID.fromString(owner);
        if(source==null || destination==null || !source.matches("[A-Za-z0-9_-]{1,24}") || !destination.matches("[A-Za-z0-9_-]{1,24}") || source.equals(destination)
            || sender==null || sender.length()>80 || recipient==null || recipient.length()>80 || topic==null || topic.length()>160 || !Set.of("outbound","return","complete").contains(phase) || escrow<0 || escrow>2 || issued<0)throw new IllegalArgumentException("Invalid courier dispatch");
    }
    public static CourierQuest issue(String player,Settlement from,Settlement to,long now){
        UUID.fromString(player);
        if(now<0)throw new IllegalArgumentException("Invalid issue time");
        if(from==to || !from.colonyReady || !to.colonyReady || from.questMasterCitizenId<=0 || to.questMasterCitizenId<=0 || !from.dimension.equals(to.dimension))throw new IllegalArgumentException("Both towns need a steward");
        var q=new CourierQuest();q.id=UUID.randomUUID().toString();q.owner=player;q.source=from.name;q.destination=to.name;q.issued=now;
        var a=from.residents.get(from.questMasterCitizenId);var b=to.residents.get(to.questMasterCitizenId);
        if(a==null || b==null)throw new IllegalArgumentException("Introduce yourself to both towns' stewards first");
        q.sender=a.name;q.recipient=b.name;q.topic=from.food<Economy.reserve(from)?"Harvest news and future mutual aid":from.wood<64?"Timber contacts and local trade":"An introduction between our communities";
        q.escrow=Math.min(2,from.treasury);from.treasury-=q.escrow;return q;
    }
    public boolean accept(String player,Settlement at,Settlement from,Settlement to,String bookPhase){
        if(!owner.equals(player) || !phase.equals(bookPhase) || phase.equals("complete") || !at.name.equals(target()) || !from.name.equals(source) || !to.name.equals(destination))return false;
        if(phase.equals("outbound")){
            phase="return";from.reputation.put(player,Math.min(100,from.relation(player)+2));to.reputation.put(player,Math.min(100,to.relation(player)+3));
            if(from.regionalTrust.size()<32 || from.regionalTrust.containsKey(to.name))from.regionalTrust.merge(to.name,3,(a,b)->Math.min(100,a+b));
            if(to.regionalTrust.size()<32 || to.regionalTrust.containsKey(from.name))to.regionalTrust.merge(from.name,3,(a,b)->Math.min(100,a+b));
            TownProgress.record(from,"A letter reached "+to.name+".");TownProgress.record(to,"A letter arrived from "+from.name+".");
        }else{
            int pending=from.questRewards.getOrDefault(player,0);
            if(pending+escrow>4096 || !from.questRewards.containsKey(player) && from.questRewards.size()>=4096)return false;
            from.questRewards.merge(player,escrow,Integer::sum);if(escrow==0 && pending==0)from.questRewards.remove(player);
            phase="complete";from.reputation.put(player,Math.min(100,from.relation(player)+2));TownProgress.record(from,"A courier returned with news from "+to.name+".");
        }return true;
    }
}

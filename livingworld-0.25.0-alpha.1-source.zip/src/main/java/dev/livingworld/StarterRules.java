package dev.livingworld;
public final class StarterRules {
    public static boolean automatic(SitePlan p){return p!=null && !p.complete && ("builder".equals(p.kind)||"townhall".equals(p.kind));}
    public static int trainingIncrease(int current){return Math.max(0,4-current);}
}

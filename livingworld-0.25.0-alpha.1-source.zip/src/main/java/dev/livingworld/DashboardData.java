package dev.livingworld;
import java.util.*;
/** Read-only transport projection. Never sends block journals or other players' relationships. */
public final class DashboardData {
    public boolean operator,autoFound,discoveryUnlocked,ready,hasCharter,questMasterView;
    public String charterOrigin="",escortPosition="",waypointTown="";
    public int maxExpansions;
    public String message="",selectedTown="",rotationStatus="";
    public List<String> styles=new ArrayList<>();
    public List<String> journey=new ArrayList<>();
    public List<Town> towns=new ArrayList<>();
    public static final class Town {
        public String tier="",headline="",summary="",relationship="",nextMilestone="";
        public boolean canMark;
        public String region="";
        public List<Resident> residents=new ArrayList<>();
        public List<String> townRelations=new ArrayList<>();
        public List<String> news=new ArrayList<>();
        public List<Project> projects=new ArrayList<>();
        public String phase="",worker="Waiting for a builder",workStage="Not started",guidance="";
        public int milestone;
        public List<String> requests=new ArrayList<>(),terrain=new ArrayList<>();
        public String name,location,style,governor,economy,next,supply,journey,chunkStatus;
        public String questTitle="",questReason="",questItem="";
        public int questAmount,questProgress;
        public long delivered;
        public boolean detailed=true,distantEnabled,away;
        public boolean near,activated,linked,enabled,allied,expedition,materials,founder,automatic;
        public int people,wood,stone,food,coins,reputation,plots,finishedPlots,expansions;
        public int[] prices;
        public List<String> buildings=new ArrayList<>();
    }
    public record Resident(String name,String role,String activity,String trait,String familiar){}
    public record Project(String name,String state,int percent,boolean complete){}
    public static Town project(Settlement s,String player,boolean near){
        var t=new Town();t.name=s.name;t.location=s.dimension+" / "+s.x+", "+s.y+", "+s.z;
        t.style=s.expansionPack;t.governor=clip(s.governorMessage);t.economy=clip(s.economyMessage);t.journey=clip(s.journeyMessage);t.chunkStatus=clip(s.chunkMessage==null?"Work chunks idle":s.chunkMessage);
        t.distantEnabled=s.distantEnabled;t.away=s.away;
        t.expedition=s.expedition;t.materials=s.materialMode;t.supply=clip(s.supplyMessage);t.delivered=s.deliveredItems;
        String next=Economy.next(s);t.next=s.expedition && !s.colonyReady?"Camp > one settler > builder hut > town hall":next==null?"Capital plan complete":friendly(next)+" / planning cost: "+Economy.planningCost(s,next);t.near=near;t.activated=s.colonyReady;
        t.linked=s.colonyId>0;t.enabled=s.governorEnabled;t.allied=s.alliances.getOrDefault(player,false);t.founder=player.equals(s.founder);t.automatic=s.automatic;
        t.people=!s.recruitId.isEmpty() && !s.founderSpawned?0:t.linked?s.economyPopulation:s.population;t.wood=s.wood;t.stone=s.stone;t.food=s.food;t.coins=s.treasury;
        t.reputation=s.relation(player);t.plots=s.plots.size();t.expansions=s.expansions.size();
        if(s.quest!=null){t.questTitle=s.quest.title;t.questReason=s.quest.reason;t.questItem=TownQuests.itemName(s.quest.resource);t.questAmount=s.quest.amount;t.questProgress=s.quest.progress;}
        for(var road:s.roads)t.terrain.add(road.destination+": "+road.status+" ("+road.cursor+" / "+road.points.size()+")");
        t.terrain.addAll(s.siteReports);
        t.terrain.add("Distant development: "+s.distantMessage);
        t.terrain.add("Distant work chunks: "+(s.chunkMessage==null?"Idle":s.chunkMessage));
        t.terrain.add("Reserved migrants: "+s.pendingMigrants+"; physical housing still required");
        t.terrain.add("Settlement history:");t.terrain.addAll(s.history);
        t.prices=new int[]{Economy.price(s,"wood",true),Economy.price(s,"stone",true),Economy.price(s,"food",true)};
        t.milestone=s.camp==null?0:!s.camp.complete?1:!s.founderSpawned?2:s.starterSites.isEmpty()?3:s.starterSites.stream().noneMatch(p->p.kind.equals("builder") && p.complete)?4:s.starterSites.stream().noneMatch(p->p.kind.equals("townhall") && p.complete)?5:6;
        t.phase=!s.expedition?"Established colony":new String[]{"Finding a camp site","Establishing the supply camp","Settler arriving","Finding a builder site","Preparing terrain / building the hut","Building the town hall","Growing the settlement"}[t.milestone];
        t.phase=TownProgress.stage(s)+" / "+t.phase;
        t.guidance=!t.enabled?"Growth is paused. Resume it from Controls.":BackgroundProgress.eligible(s)?
            "You can travel. Starter work and later development use the bounded background rotation in saved, player-visited chunks. "+t.chunkStatus:
            !s.colonyReady?(s.automatic?"A nearby player keeps this NPC expedition active until the first settler joins camp.":"Stay within 192 blocks until your pioneer joins the completed camp. You can then leave."):
            "Supply timber, stone or food through Trade if stocks run low.";
        t.guidance+=" "+(s.away?"Distant: ":"Background projects: ")+clip(s.distantMessage)+". Next milestone: "+TownProgress.next(s)+".";
        for(int i=0;i<s.plots.size();i++){var p=s.plots.get(i);if(p.cursor==p.cells.size())t.finishedPlots++;
            t.buildings.add("Cottage "+(i+1)+" / "+p.cursor+" of "+p.cells.size()+" blocks / "+p.x+", "+p.y+", "+p.z+(p.blocked.isEmpty()?"":" / "+clip(p.blocked)));}
        if(s.camp!=null && s.camp.groundworkCursor<s.camp.groundwork.size())t.terrain.add("Camp groundwork: "+s.camp.groundworkCursor+" / "+s.camp.groundwork.size()+" blocks");
        if(s.camp!=null)t.buildings.add("Supply camp / "+(s.camp.complete?"Established":(100L*s.camp.cursor/(s.camp.width*s.camp.height*s.camp.depth*2))+"%")+" / "+s.camp.pack);
        for(var site:s.starterSites)t.buildings.add("Starter "+site.kind+" / "+(site.complete?"Complete":site.autoAssembly?"Automatic assembly "+(100L*site.cursor/Math.max(1,site.width*site.height*site.depth*2))+"%":"Reserved for automatic assembly")+" / "+site.x+", "+site.y+", "+site.z);
        for(var project:s.distantProjects)t.buildings.add("Distant "+project.kind+" / "+(project.ready()?"Ready for terrain placement":project.progress+" / "+project.required+" cycles")+" / paid "+project.wood+" wood, "+project.stone+" stone / "+project.pack);
        for(var e:s.expansions)t.buildings.add(e.kind+" / "+(e.complete?"Complete":e.assembly!=null?"Protected automatic completion":"Under construction")+" / "+e.x+", "+e.y+", "+e.z+" / "+clip(e.pack));
        TownPresentation.apply(t,s);return t;
    }
    public static void compact(Town t){t.detailed=false;t.buildings.clear();t.terrain.clear();t.requests.clear();t.projects.clear();t.news.clear();t.residents.clear();t.townRelations.clear();}
    public static String friendly(String s){
        if(s==null)return "";
        s=s.replace("minecraft:","").replace('_',' ').toLowerCase(Locale.ROOT);
        return s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1);
    }
    public static void live(Town t,Settlement s,net.minecraft.server.level.ServerLevel level){
        if(s.colonyId<=0)return;
        if(level.players().stream().noneMatch(p->p.distanceToSqr(s.x,s.y,s.z)<192*192)){t.worker="Distant work: "+(s.chunkMessage==null?"idle":s.chunkMessage);t.workStage=s.distantMessage;return;}
        if(s.starterSites.stream().anyMatch(StarterRules::automatic) || DistantProgress.assembling(s)){
            t.worker="Automatic assembly active; the builder handles native jobs";
            t.workStage=clip(s.governorMessage);return;
        }
        try{
            var c=ColonyBridge.colony(s,level);
            var builder=c.getServerBuildingManager().getBuildings().get(ColonyBridge.builderHut(s));
            if(builder==null)return;
            if(builder instanceof com.minecolonies.core.colony.buildings.AbstractBuildingStructureBuilder b && b.getProgress()!=null){
                String stage=String.valueOf(b.getProgress().getB());
                t.workStage=switch(stage){case "CLEAR","REMOVE","CLEAR_NON_SOLIDS"->"Clearing and excavating the site";case "BUILD_SOLID","WEAK_SOLID"->"Building foundations, walls and roof";case "CLEAR_WATER","REMOVE_WATER"->"Draining the site";case "DECORATE","SPAWN"->"Fitting out the building";default->"Preparing the work order";};
            }
            for(var citizen:builder.getAllAssignedCitizen()){
                t.worker=citizen.getEntity().isEmpty()?"Builder is outside loaded terrain":citizen.isAsleep()?"Builder is sleeping": "Builder: "+friendly(String.valueOf(citizen.getJobStatus()));
                for(var req:builder.getOpenRequests(citizen.getId())){
                    if(t.requests.size()>=8)break;t.requests.add(clip(req.getShortDisplayString().getString()));
                }
            }
        }catch(IllegalArgumentException ignored){t.workStage="Waiting for a registered builder site";}
    }
    public static String clip(String s){return s==null?"":s.substring(0,Math.min(400,s.length()));}
    public static String command(String action,String town,String value){
        if(!town.matches("[A-Za-z0-9_-]{1,24}"))throw new IllegalArgumentException("Use a settlement name of 1-24 letters, digits, underscores or dashes.");
        return switch(action){
            case "found","survey","activate","retry","retrypaths","recover","ally" -> "livingworld "+action+" "+town;
            case "advance" -> "livingworld advance "+town+" 80";
            case "distant" -> "livingworld distant "+town+" "+toggle(value);
            case "governor" -> "livingworld governor "+town+" "+toggle(value);
            case "autofound" -> "livingworld autofound "+toggle(value);
            case "buy","sell" -> "livingworld trade "+town+" "+action+" "+resource(value);
            case "supply" -> "livingworld supply "+town+" "+resource(value)+" 32";
            case "repair" -> "livingworld repair "+town+" "+(value.equals("2")?"2":"1");
            case "style" -> {
                if(value.length()>80 || !value.matches("[A-Za-z0-9 _-]+"))throw new IllegalArgumentException("Invalid style name");
                yield "livingworld style "+town+" "+value;
            }
            default -> throw new IllegalArgumentException("Unknown dashboard action");
        };
    }
    private static String toggle(String s){if(!s.equals("on")&&!s.equals("off"))throw new IllegalArgumentException("Invalid toggle");return s;}
    private static String resource(String s){if(!List.of("wood","stone","food").contains(s))throw new IllegalArgumentException("Invalid resource");return s;}
}

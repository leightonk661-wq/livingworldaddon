package dev.livingworld;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.minecolonies.api.colony.IColonyManager;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.*;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static net.minecraft.commands.Commands.*;

public final class LivingWorld implements ModInitializer {
    private static LivingWorld instance;
    public static Settlement builderTown(com.minecolonies.api.entity.citizen.AbstractEntityCitizen worker,net.minecraft.core.BlockPos hut){
        var mod=instance;if(mod==null || !mod.ready || !LivingWorldSettings.current.builderWorksiteSupply)return null;
        int colony=worker.getCitizenColonyHandler().getColonyId();
        for(var town:mod.data.settlements)if(town.governorEnabled && town.expedition && town.colonyId==colony
            && town.dimension.equals(worker.level().dimension().identifier().toString())
            && town.starterSites.stream().anyMatch(p->p.kind.equals("builder") && p.x==hut.getX() && p.y==hut.getY() && p.z==hut.getZ()))return town;
        return null;
    }
    public static void addVillageRumour(net.minecraft.world.RandomizableContainer chest,String lootId){
        var mod=instance;
        if(mod==null || !mod.ready || !TownRumours.villageLoot(lootId)
            || !(chest instanceof net.minecraft.world.level.block.entity.ChestBlockEntity)
            || !(chest.getLevel() instanceof net.minecraft.server.level.ServerLevel level)
            || !level.getServer().isSameThread())return;
        try {
            for(int slot=0;slot<chest.getContainerSize();slot++)if(chest.getItem(slot).isEmpty()){
                var pos=chest.getBlockPos();
                var pages=TownRumours.pages(mod.data.settlements,level.dimension().identifier().toString(),pos.getX(),pos.getZ());
                var book=new ItemStack(Items.WRITTEN_BOOK);
                book.set(net.minecraft.core.component.DataComponents.WRITTEN_BOOK_CONTENT,
                    new net.minecraft.world.item.component.WrittenBookContent(net.minecraft.server.network.Filterable.passThrough("Travellers' Gazette"),
                        "Village chronicler",0,pages.stream().map(p->net.minecraft.server.network.Filterable.<Component>passThrough(Component.literal(p))).toList(),true));
                chest.setItem(slot,book);chest.setChanged();return;
            }
        } catch(Exception e){LOG.warn("Could not add village rumour at {}",chest.getBlockPos(),e);}
    }
    private static final Logger LOG = LoggerFactory.getLogger("livingworld");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private Save data = new Save();
    private Path file;
    private int tick;
    private boolean ready;
    private final TerrainBuilder builder = new TerrainBuilder();
    private final PackGovernor governor = new PackGovernor();
    private final FoundingEngine founding=new FoundingEngine();
    private final StarterAssembly starters=new StarterAssembly();
    private final SupplyController supplies=new SupplyController();
    private final WorkChunkLoader workChunks=new WorkChunkLoader();
    private final PioneerEscort escort=new PioneerEscort();
    private final BuilderWatchdog builderWatchdog=new BuilderWatchdog();
    private final TownQuestEngine quests=new TownQuestEngine();
    private final QuestMaster questMasters=new QuestMaster();
    private final RoadBuilder roads=new RoadBuilder();
    private final JourneyService journeys=new JourneyService();
    private final CitizenLifeService life=new CitizenLifeService();
    private final CourierService couriers=new CourierService();
    private int autoTicks, autoAttempt;
    static final class Save { int version = 17; boolean autoFound=true; List<Settlement> settlements = new ArrayList<>(); Map<String,VillageCharter> charters=new HashMap<>(); Map<String,PlayerJourney> journeys=new HashMap<>(); Map<String,String> playerVisitedChunks=new HashMap<>(); WorkChunkLoader.State workRotation=new WorkChunkLoader.State(); }

    private final Map<ServerPlayer,Long> dashboardRequests=new WeakHashMap<>();
    private final Map<ServerPlayer,String> dashboardMessages=new WeakHashMap<>();
    private final Map<ServerPlayer,String> dashboardSelections=new WeakHashMap<>();
    private boolean visitedChunksDirty;
    private WorkChunkLoader.State rotationAtStop;
    @Override public void onInitialize() {
        instance=this;
        DashboardNetwork.register();
        UseEntityCallback.EVENT.register((player,level,hand,entity,hit)->{
            if(!(player instanceof ServerPlayer p) || hand!=InteractionHand.MAIN_HAND
                || !p.isShiftKeyDown() || !p.getMainHandItem().isEmpty())return InteractionResult.PASS;
            var villager=HumanoidVillagers.original(entity,p.level());
            return villager==null?InteractionResult.PASS:requestCharter(p,villager);
        });
        UseEntityCallback.EVENT.register((player,level,hand,entity,hit)->{
            if(!(entity instanceof com.minecolonies.api.entity.citizen.AbstractEntityCitizen citizen) || hand!=InteractionHand.MAIN_HAND)return InteractionResult.PASS;
            if(level.isClientSide())return citizen.getCustomName()!=null && ("Quest Master".equals(citizen.getCustomName().getString()) || citizen.getCustomName().getString().endsWith(" / Steward")) || player.isShiftKeyDown() && player.getMainHandItem().isEmpty()?InteractionResult.SUCCESS:InteractionResult.PASS;
            if(!(player instanceof ServerPlayer p) || !ready)return InteractionResult.PASS;
            for(var town:data.settlements)if(town.dimension.equals(level.dimension().identifier().toString()) && QuestMaster.matches(town,citizen)){
                dashboardSelections.put(p,town.name);
                if(p.isShiftKeyDown() && p.getMainHandItem().isEmpty()){
                    String id=p.getUUID().toString();if(!data.journeys.containsKey(id) && data.journeys.size()>=4096)return InteractionResult.SUCCESS;
                    var journey=data.journeys.computeIfAbsent(id,unused->new PlayerJourney());couriers.request(p,town,journey,data.settlements,level.getGameTime());
                    journeys.sync(p,journey,data.charters.get(id),data.settlements,false);save();return InteractionResult.SUCCESS;
                }
                TownQuestBook.give(p,town);save();dashboardSnapshot(p,true,true);return InteractionResult.SUCCESS;
            }
            if(p.isShiftKeyDown() && p.getMainHandItem().isEmpty())for(var town:data.settlements)if(town.colonyId==citizen.getCitizenColonyHandler().getColonyId() && town.dimension.equals(level.dimension().identifier().toString())){
                if(citizen.getCitizenData()!=null)life.speak(p,town,citizen.getCitizenData().getId(),this::save);return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(DashboardNetwork.Request.TYPE,(request,context)->context.server().execute(()->dashboardAction(context.player(),request)));

        ServerLifecycleEvents.SERVER_STARTED.register(this::load);
        ServerLifecycleEvents.BEFORE_SAVE.register((server, flush, force) -> save());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> { rotationAtStop=workChunks.snapshot();workChunks.reset();save(); });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> { ready = false; data = new Save(); file = null; tick = 0; visitedChunksDirty=false;rotationAtStop=null;VisitedChunks.resetPlayerVisits();builder.reset();builderWatchdog.reset();governor.reset();founding.reset();starters.reset();supplies.reset();roads.reset();escort.reset();quests.reset();journeys.reset();life.reset();couriers.reset();questMasters.reset(); });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!ready) return;
            tick = (tick + 1) % 600;
            for(var player:server.getPlayerList().getPlayers())
                if(player.level().dimension().identifier().toString().equals("minecraft:overworld")
                    && VisitedChunks.recordPlayerEntry(player.chunkPosition()))visitedChunksDirty=true;
            if(visitedChunksDirty && tick%200==0)save();
            escort.tick(server,data.charters,data.settlements,this::save);
            // Stagger all 32 possible settlements. No chunk loads or missed-tick catch-up.
            for (int i = 0; i < data.settlements.size(); i++)
                if (tick == i * 18) economyStep(server,data.settlements.get(i));
            founding.tick(server,data.settlements,this::save,workChunks);
            workChunks.tick(server,data.settlements,governor,founding,this::save);
            supplies.tick(server,data.settlements,workChunks);
            builder.tick(server,data.settlements);
            governor.tick(server,data.settlements,this::save,workChunks);
            builderWatchdog.tick(server,data.settlements,this::save);
            starters.tick(server,data.settlements,this::save,workChunks);
            roads.tick(server,data.settlements,this::save);
            quests.tick(server,data.settlements,this::save);
            questMasters.tick(server,data.settlements,this::save);
            life.tick(server,data.settlements,this::save);
            couriers.tick(server,data.journeys,data.settlements,this::save);
            journeys.tick(server,data.journeys,data.charters,data.settlements,this::save);
            if(tick%20==0)for(var town:data.settlements)TownProgress.update(town);
            if(++autoTicks>=1200) { autoTicks=0; discover(server);save(); }
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> {
            var root = literal("livingworld").executes(c -> help(c.getSource()));
            root.then(literal("ui").executes(c -> run(c, () -> {dashboardSnapshot(c.getSource().getPlayerOrException(),true);return 1;})));
            for(String mode:List.of("on","off"))root.then(literal("hints").then(literal(mode).executes(c -> run(c, () -> {
                var player=c.getSource().getPlayerOrException();String id=player.getUUID().toString();
                if(!data.journeys.containsKey(id) && data.journeys.size()>=4096)throw new IllegalArgumentException("Journal record limit reached");
                var state=data.journeys.computeIfAbsent(id,unused->new PlayerJourney());state.hintsEnabled=mode.equals("on");
                if(state.hintsEnabled){state.lastHint="";state.hintAt=-1200;}
                if(net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player,DashboardNetwork.Hint.TYPE))net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,new DashboardNetwork.Hint("",""));
                save();say(c.getSource(),"Journey hints "+mode+".");return 1;
            }))));
            root.then(literal("journal").executes(c -> run(c, () -> {
                var player=c.getSource().getPlayerOrException();String id=player.getUUID().toString();
                if(!data.journeys.containsKey(id) && data.journeys.size()>=4096)throw new IllegalArgumentException("Journal record limit reached");
                var journal=data.journeys.computeIfAbsent(id,unused->new PlayerJourney());
                if(!JourneyService.give(player,journal,data.settlements))throw new IllegalArgumentException("Make room in your inventory for the journal");
                journal.journalGiven=true;save();say(c.getSource(),"Your Traveller's Journal is up to date.");return 1;
            })));
            root.then(literal("list").executes(c -> run(c, () -> {
                if (data.settlements.isEmpty()) say(c.getSource(), "No settlements yet. Read your Traveller's Journal and ask a village villager for a charter (crouch-right-click with an empty hand).");
                for (var s : data.settlements) say(c.getSource(), s.name + " | " + s.dimension + " " + s.x + " " + s.y + " " + s.z);
                return 1;
            })));
            root.then(literal("discovery").executes(c -> run(c, () -> {
                say(c.getSource(),DiscoveryRules.unlocked(data.settlements)
                    ? "NPC expeditions unlocked by your first manually founded town. Automatic discovery is "+(data.autoFound?"on":"off")+"."
                    : "NPC expeditions locked. Found your first town using a Village Charter, or use Found here as an operator. Automatic discovery cannot start before that.");
                return 1;
            })));
            root.then(literal("found")
                .then(argument("name", StringArgumentType.word()).executes(c -> run(c, () -> {
                    var p = c.getSource().getPlayerOrException(); String name = StringArgumentType.getString(c, "name");
                    if (!name.matches("[A-Za-z0-9_-]{1,24}")) throw new IllegalArgumentException("Use 1–24 letters, numbers, underscores or dashes.");
                    if (data.settlements.size() >= 32) throw new IllegalArgumentException("Prototype limit: 32 settlements.");
                    if (data.settlements.stream().anyMatch(s -> s.name.equalsIgnoreCase(name))) throw new IllegalArgumentException("Name already exists.");
                    var pos = p.blockPosition();
                    String dim=p.level().dimension().identifier().toString();
                    if(!dim.equals("minecraft:overworld")) throw new IllegalArgumentException("Found an expedition in the Overworld.");
                    if(p.level().isVillage(pos))throw new IllegalArgumentException("Travel beyond existing village limits before founding.");
                    if(!separated(dim,pos.getX(),pos.getZ(),112)) throw new IllegalArgumentException("Too close to another Living World settlement.");
                    for(var colony:IColonyManager.getInstance().getColonies(p.level())){
                        var center=colony.getCenter();
                        if((long)(center.getX()-pos.getX())*(center.getX()-pos.getX())+(long)(center.getZ()-pos.getZ())*(center.getZ()-pos.getZ())<256L*256L)
                            throw new IllegalArgumentException("Travel at least 256 blocks from an existing MineColonies town.");
                    }
                    boolean operator=Commands.hasPermission(Commands.LEVEL_GAMEMASTERS).test(c.getSource());
                    VillageCharter charter=data.charters.get(p.getUUID().toString());
                    if(!operator || charter!=null){
                        if(charter==null)throw new IllegalArgumentException("Ask a villager in an existing village for a charter first. Crouch-right-click with an empty hand and 4 emeralds.");
                        if(!hasCharter(p,charter))throw new IllegalArgumentException("Carry your Village Charter book in your main inventory.");
                        if(charter.villagerId.isEmpty() || !PioneerEscort.nearPlayer(charter,p,16))throw new IllegalArgumentException("Escort your charter villager here first; the recruit must be within 16 blocks. Return to a village villager if your recruit was lost.");
                        if(!charter.farEnough(dim,pos.getX(),pos.getZ()))throw new IllegalArgumentException("Travel at least 256 blocks from the issuing village before founding.");
                    }
                    if(!operator)requireFoundingKit(p);
                    var created=new Settlement(name, dim, pos.getX(), pos.getY(), pos.getZ());prepareExpedition(created,p);PackGovernor.select(created,p.level());
                    if(!operator){takeFoundingKit(p);created.wood=64;created.stone=64;created.food=32;created.treasury=8;}
                    if(charter!=null){
                        PioneerHandoff.link(created,charter);
                        var recruit=PioneerEscort.find(p.level(),charter.villagerId);
                        if(recruit!=null)PioneerEscort.capture(created,recruit);
                        takeCharter(p,charter);data.charters.remove(p.getUUID().toString());
                    }
                    data.settlements.add(created);
                    save(); say(c.getSource(), "Recorded " + name + ". Stay nearby while its supply camp and first settler establish the town. NPC expeditions can now appear as you explore."+(operator?"":" Your charter and supplies were consumed; initial stores are in the town ledger.")); return 1;
                }))));
            root.then(literal("status").then(argument("name", StringArgumentType.word()).executes(c -> run(c, () -> {
                var s = settlement(c); var p = c.getSource().getPlayerOrException();
                say(c.getSource(), s.name + " | simulated population " + s.population + " | homes " + s.homes + "/8 | next home " + s.progress + "/40");
                say(c.getSource(), "Wood " + s.wood + ", stone " + s.stone + ", food " + s.food + " | treasury " + s.treasury);
                say(c.getSource(), "Surveyed plots " + s.plots.size() + " | waiting for departure " + s.pendingDeparture);
                say(c.getSource(),"Expansion style: "+s.expansionPack+" | governor "+s.governorEnabled+" | "+s.governorMessage);
                if(s.colonyId>0 && s.dimension.equals(p.level().dimension().identifier().toString())) say(c.getSource(),ColonyBridge.status(s,p.level()));
                say(c.getSource(), "Your reputation " + s.relation(p.getUUID().toString()) + "/100 | alliance " + s.alliances.getOrDefault(p.getUUID().toString(), false)); return 1;
            }))));
            root.then(literal("chunks").then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                var s=settlement(c);
                say(c.getSource(),s.name+" work chunks: "+s.chunkMessage+" | global "+(LivingWorldSettings.current.workChunkLoading?"on":"off")+
                    " | distant "+(s.distantEnabled?"on":"off")+" | budget "+LivingWorldSettings.current.maxWorkChunks+" chunks");
                say(c.getSource(),workChunks.rotationStatus(c.getSource().getServer()));return 1;
            }))));
            root.then(literal("rotate").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)).executes(c -> run(c, () -> {
                workChunks.rotateNow();save();say(c.getSource(),"Background rotation advanced. The next eligible pair starts shortly.");return 1;
            })));
            root.then(literal("supply").then(argument("name", StringArgumentType.word())
                .then(argument("resource", StringArgumentType.word()).suggests((c,b) -> { b.suggest("wood"); b.suggest("stone"); b.suggest("food"); return b.buildFuture(); })
                .then(argument("amount", IntegerArgumentType.integer(8,64)).executes(c -> run(c, () -> {
                    var s = settlement(c); var p = nearby(c,s); var kind = StringArgumentType.getString(c,"resource");
                    int amount = IntegerArgumentType.getInteger(c,"amount"); Item item = resource(kind);
                    if (s.stock(kind) + amount > 512) throw new IllegalArgumentException("Settlement stockpile is full.");
                    requireItems(p,item,amount); s.supply(p.getUUID().toString(),kind,amount); take(p,item,amount); save();
                    say(c.getSource(), "Delivered " + amount + " " + kind + " to " + s.name + ". Reputation: " + s.relation(p.getUUID().toString())); return 1;
                }))))));
            root.then(literal("economy").then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                say(c.getSource(),Economy.status(settlement(c)));return 1;
            }))));
            root.then(literal("quest").then(argument("name",StringArgumentType.word())
                .executes(c -> run(c, () -> {
                    var s=settlement(c);var q=s.quest;
                    say(c.getSource(),q==null?"No open request in "+s.name+" yet.":q.title+": "+q.reason+" Bring "+(q.amount-q.progress)+" more "+TownQuests.itemName(q.resource)+". Right-click the Quest Master for a book, then drop the items beside them.");return 1;
                }))));
            var market=literal("trade").then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                var s=settlement(c);say(c.getSource(),Economy.status(s));
                for(String kind:new String[]{"wood","stone","food"})say(c.getSource(),kind+": buy 8 for "+Economy.price(s,kind,true)+" emeralds; sell 8 for 1 emerald. Use trade "+s.name+" buy|sell "+kind);
                return 1;
            })));
            // Separate roots merge under Brigadier's existing trade/name nodes.
            root.then(market);
            for(boolean buying:new boolean[]{true,false})root.then(literal("trade").then(argument("name",StringArgumentType.word())
                .then(literal(buying?"buy":"sell").then(argument("resource",StringArgumentType.word())
                .suggests((c,b)->{b.suggest("wood");b.suggest("stone");b.suggest("food");return b.buildFuture();})
                .executes(c -> run(c, () -> {
                    var s=settlement(c);var p=nearby(c,s);String kind=StringArgumentType.getString(c,"resource");
                    var item=resource(kind);int price=Economy.price(s,kind,buying);
                    requireItems(p,buying?Items.EMERALD:item,buying?price:8);
                    Economy.trade(s,kind,buying);
                    take(p,buying?Items.EMERALD:item,buying?price:8);
                    p.getInventory().placeItemBackInInventory(new ItemStack(buying?item:Items.EMERALD,buying?8:price));
                    save();say(c.getSource(),(buying?"Bought":"Sold")+" 8 "+kind+" for "+price+" emerald(s).");return 1;
                }))))));
            root.then(literal("ally").then(argument("name", StringArgumentType.word()).executes(c -> run(c, () -> {
                var s = settlement(c); var p = nearby(c,s); s.ally(p.getUUID().toString());
                say(c.getSource(), "Alliance recorded with " + s.name + ". Military assistance is not implemented in this prototype."); return 1;
            }))));
            root.then(literal("recover").then(argument("name",StringArgumentType.word()).executes(c->run(c,()->{
                var s=settlement(c);manager(c,s);nearby(c,s);TownProgress.recover(s);save();say(c.getSource(),"Resuming searches and unfinished work; protection checks retained.");return 1;
            }))));
            root.then(literal("retrypaths").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS)).then(argument("name",StringArgumentType.word()).executes(c->run(c,()->{
                var s=settlement(c);nearby(c,s);for(var road:s.roads)if(!road.complete){road.issued=false;road.retryAt=0;road.status="Retry requested; terrain will be rechecked";}s.nextSurveyTick=0;save();say(c.getSource(),"Approaches will retry. Changed blocks remain protected.");return 1;
            }))));
            root.then(literal("colonies").executes(c -> run(c, () -> {
                var colonies = IColonyManager.getInstance().getColonies(c.getSource().getLevel());
                say(c.getSource(), "MineColonies towns in this dimension: " + colonies.size());
                for (var colony : colonies) say(c.getSource(), "#" + colony.getID() + " " + colony.getName() + " at " + colony.getCenter().toShortString());
                return 1;
            })));
            root.then(literal("survey").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                    var s=settlement(c);var player=nearby(c,s);if(s.expedition){s.autoDevelop=true;s.governorEnabled=true;save();say(c.getSource(),"Expedition survey resumed; stay nearby.");return 1;}requireSimulated(s);
                    builder.survey(s,player.level(),message -> { say(c.getSource(),message);save(); });
                    say(c.getSource(),"Survey queued. Inspecting loaded, clear terrain for up to eight plots."); return 1;
                }))));
            root.then(literal("plots").then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                var s=settlement(c);
                for(int i=0;i<s.plots.size();i++) {var plot=s.plots.get(i);
                    say(c.getSource(),"Plot "+(i+1)+" at "+plot.x+" "+plot.y+" "+plot.z+" | applied "+plot.cursor+"/"+plot.cells.size()+" | "+(plot.blocked.isEmpty()?"ready":plot.blocked));}
                if(s.plots.isEmpty()) say(c.getSource(),"No suitable plots surveyed yet. Try an open, gently sloped area.");
                return 1;
            }))));
            var distantControl=literal("distant");
            var distantTown=argument("name",StringArgumentType.word()).executes(c->run(c,()->{var s=settlement(c);say(c.getSource(),s.distantMessage+" | queue "+s.distantProjects.size()+" | incoming residents "+s.pendingMigrants);return 1;}));
            for(boolean enabled:new boolean[]{false,true})distantTown.then(literal(enabled?"on":"off").executes(c->run(c,()->{
                var s=settlement(c);manager(c,s);s.distantEnabled=enabled;save();say(c.getSource(),"Distant development "+(enabled?"enabled":"paused")+"; funded projects retained.");return 1;
            })));
            distantControl.then(distantTown);root.then(distantControl);
            root.then(literal("simulate").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).then(argument("cycles",IntegerArgumentType.integer(1,120)).executes(c->run(c,()->{
                    var s=settlement(c);
                    if(!DistantProgress.established(s) || !s.governorEnabled || !s.distantEnabled || !LivingWorldSettings.current.distantProgression)throw new IllegalArgumentException("Complete and enable the settlement's starter buildings first.");
                    if(c.getSource().getServer().getPlayerList().getPlayers().stream().anyMatch(p->p.level().dimension().identifier().toString().equals(s.dimension) && p.distanceToSqr(s.x,s.y,s.z)<192*192))throw new IllegalArgumentException("All players must leave this settlement's 192-block area before simulating it.");
                    for(int i=0;i<IntegerArgumentType.getInteger(c,"cycles");i++){s.step();DistantProgress.step(s,true);}s.away=true;save();
                    say(c.getSource(),"Advanced distant test cycles; no terrain or citizens were loaded. "+s.distantMessage);return 1;
                })))));
            root.then(literal("advance").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).then(argument("cycles",IntegerArgumentType.integer(1,400))
                .executes(c -> run(c, () -> {
                    var s=settlement(c);requireSimulated(s);if(s.pendingDeparture) throw new IllegalArgumentException("Leave the automatic site before advancing it.");
                    for(int i=0;i<IntegerArgumentType.getInteger(c,"cycles");i++) s.step();
                    say(c.getSource(),"Simulation advanced. Visible placement still uses the normal per-tick budget.");return 1;
                })))));
            root.then(literal("retry").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                    var s=settlement(c);for(var plot:s.plots) plot.blocked="";
                    say(c.getSource(),"Blocked plots will be checked again. Changed blocks are still protected.");return 1;
                }))));
            var auto=literal("autofound").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS));
            for(boolean enabled:new boolean[]{false,true}) auto.then(literal(enabled?"on":"off").executes(c -> run(c, () -> {
                data.autoFound=enabled;save();say(c.getSource(),"Automatic discovery "+(enabled?(DiscoveryRules.unlocked(data.settlements)?"enabled. Explore open land for NPC expeditions.":"enabled but locked until the first manually founded town."):"disabled. Existing settlements remain."));return 1;
            })));
            root.then(auto);
            root.then(literal("activate").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                    var s=settlement(c);var player=nearby(c,s);
                    say(c.getSource(),ColonyBridge.activate(s,player,this::save));return 1;
                }))));
            root.then(literal("colony").then(argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {
                var s=settlement(c);var player=nearby(c,s);say(c.getSource(),ColonyBridge.status(s,player.level()));return 1;
            }))));
            root.then(literal("repair").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(argument("name",StringArgumentType.word()).then(argument("plot",IntegerArgumentType.integer(1,2)).executes(c -> run(c, () -> {
                    var s=settlement(c);var player=nearby(c,s);
                    say(c.getSource(),ColonyBridge.repair(s,player.level(),IntegerArgumentType.getInteger(c,"plot")));return 1;
                })))));
            root.then(literal("styles").executes(c -> run(c, () -> {say(c.getSource(),"Installed supported packs: "+String.join(", ",PackGovernor.available()));return 1;})));
            root.then(literal("style").then(argument("name",StringArgumentType.word())
                .executes(c -> run(c, () -> {var s=settlement(c);var p=nearby(c,s);PackGovernor.select(s,p.level());save();say(c.getSource(),s.expansionPack+" | "+s.styleReason);return 1;}))
                .then(argument("pack",StringArgumentType.greedyString()).executes(c -> run(c, () -> {
                    var s=settlement(c);manager(c,s);nearby(c,s);PackGovernor.override(s,StringArgumentType.getString(c,"pack"));save();say(c.getSource(),"Future expansions use "+s.expansionPack);return 1;
                })))));
            var govern=literal("governor");
            var townArg=argument("name",StringArgumentType.word()).executes(c -> run(c, () -> {var s=settlement(c);say(c.getSource(),"Style "+s.expansionPack+" | enabled "+s.governorEnabled+" | expansions "+s.expansions.size()+"/"+LivingWorldSettings.current.maxExpansions+" | "+s.governorMessage);return 1;}));
            for(boolean enabled:new boolean[]{false,true})townArg.then(literal(enabled?"on":"off").executes(c -> run(c, () -> {
                var s=settlement(c);manager(c,s);var p=nearby(c,s);if(s.expedition && !s.colonyReady){s.autoDevelop=enabled;s.governorEnabled=enabled;save();say(c.getSource(),enabled?"Expedition resumed":"Expedition paused");return 1;}if(!s.colonyReady)throw new IllegalArgumentException("Activate the colony first.");
                PackGovernor.select(s,p.level());s.governorEnabled=enabled;s.materialMode=true;s.governorMessage=enabled?"Ready to plan next building":"Paused; any existing MineColonies work order continues";save();say(c.getSource(),s.governorMessage+" | style "+s.expansionPack);return 1;
            })));
            govern.then(townArg);root.then(govern);
            dispatcher.register(root);
        });
    }
    private void dashboardAction(ServerPlayer player,DashboardNetwork.Request request){
        long now=System.nanoTime();Long previous=dashboardRequests.get(player);
        if(previous!=null && now-previous<150_000_000L)return;
        dashboardRequests.put(player,now);
        if(request.action().equals("waypoint")){
            if(!ready)return;String id=player.getUUID().toString();
            if(!data.journeys.containsKey(id) && data.journeys.size()>=4096)return;
            var journey=data.journeys.computeIfAbsent(id,unused->new PlayerJourney());
            var target=request.town().isEmpty()?data.settlements.stream().filter(t->WaypointRules.known(t,journey,id)
                && t.dimension.equals(player.level().dimension().identifier().toString()) && !WaypointRules.arrived(t.dimension,player.getX(),player.getZ(),t))
                .min(java.util.Comparator.comparingDouble(t->player.distanceToSqr(t.x,t.y,t.z))).orElse(null):
                data.settlements.stream().filter(t->t.name.equals(request.town()) && WaypointRules.known(t,journey,id)).findFirst().orElse(null);
            if(request.value().equals("clear")){journey.waypointTown="";dashboardMessages.put(player,"Your trail marker has been put away.");}
            else if(target!=null){journey.waypointTown=target.name.equals(journey.waypointTown)?"":target.name;dashboardMessages.put(player,journey.waypointTown.isEmpty()?"Trail marker cleared.":"Following the trail to "+target.name+".");}
            else dashboardMessages.put(player,"Visit a town first to learn the way there.");
            journeys.sync(player,journey,data.charters.get(id),data.settlements,false);save();dashboardSnapshot(player,false);return;
        }
        if(java.util.Set.of("book","journalrefresh","checklist","trackjourney").contains(request.action())){
            if(!ready)return;
            String id=player.getUUID().toString();
            if(!data.journeys.containsKey(id) && data.journeys.size()>=4096)return;
            var state=data.journeys.computeIfAbsent(id,unused->new PlayerJourney());
            if(request.action().equals("book")){
                var hand=request.value().equals("OFF_HAND")?InteractionHand.OFF_HAND:InteractionHand.MAIN_HAND;
                var book=player.getItemInHand(hand);var charter=data.charters.get(id);
                if(JourneyService.matches(book,id) || charter!=null && charter.matches(book)){state.trackedQuest="";state.trackedCourier=false;}
                else if(CourierService.matches(book,state.courier)){state.trackedCourier=true;state.trackedQuest="";}
                else{
                    var quest=data.settlements.stream().filter(t->t.quest!=null && TownQuestBook.matches(book,t.quest)).findFirst();
                    if(quest.isEmpty()){
                        player.sendSystemMessage(Component.literal("This request has ended or this journal belongs to someone else. Use your Traveller's Journal for current progress."));return;
                    }
                    state.trackedQuest=quest.get().quest.id;state.trackedCourier=false;
                }
            }
            if(request.action().equals("trackjourney")){state.trackedQuest="";state.trackedCourier=false;}
            if(request.action().equals("checklist"))state.checklistEnabled=!state.checklistEnabled;
            journeys.sync(player,state,data.charters.get(id),data.settlements,request.action().equals("book"));if(!request.action().equals("journalrefresh"))save();return;
        }
        if(!request.action().equals("refresh")){
            if(!ready){dashboardMessages.put(player,"Settlement save is unavailable. Check server log.");dashboardSnapshot(player,false);return;}
            try{
                String command=DashboardData.command(request.action(),request.town(),request.value());
                var output=new net.minecraft.commands.CommandSource(){
                    public void sendSystemMessage(Component message){dashboardMessages.put(player,DashboardData.clip(message.getString()));}
                    public boolean acceptsSuccess(){return true;}
                    public boolean acceptsFailure(){return true;}
                    public boolean shouldInformAdmins(){return false;}
                };
                var source=player.createCommandSourceStack().withSource(output);
                player.level().getServer().getCommands().getDispatcher().execute(command,source);
                save();
            }catch(Exception e){dashboardMessages.put(player,DashboardData.clip(e.getMessage()));}
        }
        if(data.settlements.stream().anyMatch(s->s.name.equals(request.town())))dashboardSelections.put(player,request.town());
        dashboardSnapshot(player,false);
    }
    private void dashboardSnapshot(ServerPlayer player,boolean open){
        dashboardSnapshot(player,open,false);
    }
    private void dashboardSnapshot(ServerPlayer player,boolean open,boolean questMasterView){
        if(!net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.canSend(player,DashboardNetwork.Snapshot.TYPE)){
            player.sendSystemMessage(Component.literal("Install Living World on the client to use this dashboard."));return;
        }
        var view=new DashboardData();view.ready=ready;view.autoFound=data.autoFound;view.discoveryUnlocked=DiscoveryRules.unlocked(data.settlements);view.maxExpansions=LivingWorldSettings.current.maxExpansions;view.questMasterView=questMasterView;view.rotationStatus=workChunks.rotationStatus(player.level().getServer());
        var charter=data.charters.get(player.getUUID().toString());
        view.waypointTown=data.journeys.getOrDefault(player.getUUID().toString(),new PlayerJourney()).waypointTown;
        view.journey=JourneyService.overview(data.journeys.getOrDefault(player.getUUID().toString(),new PlayerJourney()));
        if(charter!=null){view.hasCharter=hasCharter(player,charter);view.charterOrigin=charter.x+", "+charter.z;view.escortPosition=charter.lastX+", "+charter.lastZ;}
        view.operator=Commands.hasPermission(Commands.LEVEL_GAMEMASTERS).test(player.createCommandSourceStack());
        view.message=dashboardMessages.getOrDefault(player,ready?"Your settlement ledger is up to date.":"Settlement save unavailable. Check server log.");
        if(ready){
            view.styles.addAll(PackGovernor.available());
            view.selectedTown=dashboardSelections.getOrDefault(player,data.settlements.isEmpty()?"":data.settlements.getFirst().name);
            for(var s:data.settlements){boolean near=TownRumours.withinRange(player.level().dimension().identifier().toString(),player.getX(),player.getY(),player.getZ(),s);
                var projected=DashboardData.project(s,player.getUUID().toString(),near);
                if(s.name.equals(view.selectedTown)){if(s.dimension.equals(player.level().dimension().identifier().toString()))DashboardData.live(projected,s,player.level());}
                projected.canMark=WaypointRules.known(s,data.journeys.getOrDefault(player.getUUID().toString(),new PlayerJourney()),player.getUUID().toString());
                TownPresentation.apply(projected,s);if(!s.name.equals(view.selectedTown))DashboardData.compact(projected);
                view.towns.add(projected);}
        }
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(player,new DashboardNetwork.Snapshot(GSON.toJson(view),open));
    }
    private void economyStep(MinecraftServer server,Settlement s){
        s.away=server.getPlayerList().getPlayers().stream().noneMatch(p->p.level().dimension().identifier().toString().equals(s.dimension) && p.distanceToSqr(s.x,s.y,s.z)<192*192);
        if(s.away){s.step();DistantProgress.step(s,true);return;}
        if(s.colonyReady && s.governorEnabled){
            for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(s.dimension)){
                try{
                    var c=ColonyBridge.colony(s,level);s.economyPopulation=c.getCitizenManager().getCurrentCitizenCount();
                    for(var e:s.expansions){var b=c.getServerBuildingManager().getBuildings().get(new net.minecraft.core.BlockPos(e.x,e.y,e.z));
                        if(b==null && e.registrationPending)continue;
                        if(b==null){s.governorEnabled=false;s.economyMessage="Expansion hut missing; governor paused";return;}
                        e.complete=b.getBuildingLevel()>=1 && b.isBuilt() && !b.isPendingConstruction();
                        if(e.complete && e.assembly!=null){e.assembly.complete=true;e.assembly.before.clear();e.registrationPending=false;}
                    }
                }catch(IllegalArgumentException e){s.governorEnabled=false;s.economyMessage=e.getMessage();return;}
                s.step();DistantProgress.step(s,false);return;
            }
            return;
        }
        s.step();
    }
    private int help(CommandSourceStack source) {
        say(source,"Living World 0.25: /livingworld ui | /livingworld list | journal | hints on/off | discovery | status <name> | chunks <name> | quest <name> | plots <name> | colonies");
        say(source,"At a settlement (within 128 blocks): supply <name> wood|stone|food <8–64> | trade <name> | ally <name>");
        say(source,"Survival founding: crouch-right-click a village villager with an empty hand and 4 emeralds. Escort them 256 blocks with your charter; found <name> also needs 32 oak logs, 32 cobblestone and 16 bread. Operators can found freely.");
        say(source,"Supplies: oak logs, cobblestone, bread. Trade: trade <name> buy|sell wood|stone|food; economy <name>.");
        say(source,"Distant: distant <name> on|off | simulate <name> <1-120 cycles> (operator test, while away)");
        say(source,"Operator: survey <name> | advance <name> <1–400 cycles> | retry <name> | autofound on|off");
        say(source,"Colony test: activate <name> | colony <name> | repair <name> <1|2>");
        say(source,"Founders: recover <name> | distant <name> on|off | style <name> [pack] | governor <name> on|off. Styles and growth controls are available to founders.");
        return 1;
    }
    @FunctionalInterface private interface Action { int apply() throws Exception; }
    private int run(CommandContext<CommandSourceStack> c, Action action) {
        if (!ready) { c.getSource().sendFailure(Component.literal("Living World save unavailable. Check the server log.")); return 0; }
        try { return action.apply(); }
        catch (IllegalArgumentException | com.mojang.brigadier.exceptions.CommandSyntaxException e) { c.getSource().sendFailure(Component.literal(e.getMessage())); return 0; }
        catch (Exception e) { LOG.error("Living World command failed",e); c.getSource().sendFailure(Component.literal("Command failed; check the server log.")); return 0; }
    }
    private Settlement settlement(CommandContext<CommandSourceStack> c) {
        String name = StringArgumentType.getString(c,"name");
        return data.settlements.stream().filter(s -> s.name.equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new IllegalArgumentException("Unknown settlement."));
    }
    private ServerPlayer nearby(CommandContext<CommandSourceStack> c, Settlement s) throws Exception {
        var p = c.getSource().getPlayerOrException();
        if (!TownRumours.withinRange(p.level().dimension().identifier().toString(),p.getX(),p.getY(),p.getZ(),s))
            throw new IllegalArgumentException("Visit the settlement coordinates first (within 128 blocks).");
        return p;
    }
    private ServerPlayer manager(CommandContext<CommandSourceStack> c,Settlement s) throws Exception {
        var p=c.getSource().getPlayerOrException();
        if(!Commands.hasPermission(Commands.LEVEL_GAMEMASTERS).test(c.getSource()) && !p.getUUID().toString().equals(s.founder))
            throw new IllegalArgumentException("Only this settlement's founder or an operator can change its controls.");
        return p;
    }
    private InteractionResult requestCharter(ServerPlayer p,Villager villager){
        if(!ready){p.sendSystemMessage(Component.literal("Living World save is unavailable; no charter was issued."));return InteractionResult.SUCCESS;}
        if(!p.level().dimension().identifier().toString().equals("minecraft:overworld") || !p.level().isVillage(villager.blockPosition())){
            p.sendSystemMessage(Component.literal("This villager must be in an existing Overworld village to issue a charter."));return InteractionResult.SUCCESS;
        }
        if(villager.isBaby()){p.sendSystemMessage(Component.literal("Ask an adult villager for a charter."));return InteractionResult.SUCCESS;}
        var key=p.getUUID().toString();var existing=data.charters.get(key);
        String villagerId=villager.getUUID().toString();
        if(data.charters.entrySet().stream().anyMatch(e->!e.getKey().equals(key) && villagerId.equals(e.getValue().villagerId))
            || data.settlements.stream().anyMatch(s->!s.journeyComplete && villagerId.equals(s.recruitId))){
            p.sendSystemMessage(Component.literal("This villager is already escorting another expedition."));return InteractionResult.SUCCESS;
        }
        if(existing!=null){
            if(!villagerId.equals(existing.villagerId)){
                if(hasCharter(p,existing))takeCharter(p,existing);
                var old=PioneerEscort.find(p.level(),existing.villagerId);
                if(old!=null)PioneerEscort.release(old);
                existing.token=UUID.randomUUID().toString();existing.x=villager.blockPosition().getX();existing.z=villager.blockPosition().getZ();
                existing.villagerId=villagerId;existing.lastX=existing.x;existing.lastZ=existing.z;
                PioneerEscort.mark(villager);p.getInventory().placeItemBackInInventory(existing.book());save();
                p.sendSystemMessage(Component.literal("New pioneer enlisted. Your old charter is cancelled; escort this villager 256 blocks from this village."));
            }else if(hasCharter(p,existing))p.sendSystemMessage(Component.literal("Your pioneer is ready to follow. Walk 256 blocks from the issuing village."));
            else{p.getInventory().placeItemBackInInventory(existing.book());p.sendSystemMessage(Component.literal("Your charter was reissued. Keep it in your main inventory when founding."));}
            return InteractionResult.SUCCESS;
        }
        if(data.charters.size()>=256){p.sendSystemMessage(Component.literal("Too many outstanding village charters in this world."));return InteractionResult.SUCCESS;}
        try{requireItems(p,Items.EMERALD,4);}catch(IllegalArgumentException e){
            p.sendSystemMessage(Component.literal("The villager asks for 4 emeralds to sign a settlement charter."));return InteractionResult.SUCCESS;
        }
        var charter=new VillageCharter(UUID.randomUUID().toString(),"minecraft:overworld",villager.blockPosition().getX(),villager.blockPosition().getZ());
        charter.villagerId=villagerId;PioneerEscort.mark(villager);
        take(p,Items.EMERALD,4);data.charters.put(key,charter);p.getInventory().placeItemBackInInventory(charter.book());save();
        p.sendSystemMessage(Component.literal("Village Charter issued. Your pioneer follows you on foot. Escort them 256 blocks with 32 oak logs, 32 cobblestone and 16 bread, then found a town from J > Council."));
        return InteractionResult.SUCCESS;
    }
    private static boolean hasCharter(ServerPlayer p,VillageCharter charter){
        for(int i=0;i<36;i++)if(charter.matches(p.getInventory().getItem(i)))return true;
        return false;
    }
    private static void takeCharter(ServerPlayer p,VillageCharter charter){
        for(int i=0;i<36;i++){
            var stack=p.getInventory().getItem(i);
            if(charter.matches(stack)){stack.shrink(1);p.getInventory().setChanged();p.containerMenu.broadcastChanges();return;}
        }
        throw new IllegalArgumentException("Carry your Village Charter book in your main inventory.");
    }
    private static void requireFoundingKit(ServerPlayer p){
        try{
            requireItems(p,Items.OAK_LOG,32);requireItems(p,Items.COBBLESTONE,32);
            requireItems(p,Items.BREAD,16);
        }catch(IllegalArgumentException e){throw new IllegalArgumentException("Founding needs 32 oak logs, 32 cobblestone and 16 bread in your main inventory.");}
    }
    private static void takeFoundingKit(ServerPlayer p){
        take(p,Items.OAK_LOG,32);take(p,Items.COBBLESTONE,32);take(p,Items.BREAD,16);
    }
    private static Item resource(String kind) {
        return switch(kind) {case "wood" -> Items.OAK_LOG; case "stone" -> Items.COBBLESTONE; case "food" -> Items.BREAD; default -> throw new IllegalArgumentException("Use wood, stone or food.");};
    }
    private static void requireSimulated(Settlement s) {
        if(s.expedition)throw new IllegalArgumentException("This expedition develops automatically; watch its progress in the dashboard.");
        if(s.colonyId>0) throw new IllegalArgumentException("This settlement is now managed by MineColonies. Cottage simulation is paused; use governor for expansion and economy for the town ledger.");
    }
    private static void requireItems(ServerPlayer p, Item item, int count) {
        int found=0; for (int i=0;i<36;i++) { var stack=p.getInventory().getItem(i); if(stack.is(item)) found+=stack.getCount(); }
        if(found<count) throw new IllegalArgumentException("Not enough items in your main inventory.");
    }
    private static void take(ServerPlayer p, Item item, int count) {
        for(int i=0;i<36 && count>0;i++) { var stack=p.getInventory().getItem(i); if(stack.is(item)) { int n=Math.min(count,stack.getCount()); stack.shrink(n); count-=n; } }
        p.getInventory().setChanged(); p.containerMenu.broadcastChanges();
    }
    private static void say(CommandSourceStack source,String text) { source.sendSuccess(() -> Component.literal(text),false); }
    private boolean separated(String dim,int x,int z,int radius) {
        for(var s:data.settlements) if(s.dimension.equals(dim) && (long)(s.x-x)*(s.x-x)+(long)(s.z-z)*(s.z-z)<(long)radius*radius) return false;
        return true;
    }
    private static void prepareExpedition(Settlement s,ServerPlayer p){
        var chunk=p.level().getChunkSource().getChunkNow(s.x>>4,s.z>>4);
        if(chunk!=null)s.y=chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,s.x,s.z)+1;
        s.expedition=true;s.autoDevelop=true;s.governorEnabled=true;s.materialMode=true;s.founder=p.getUUID().toString();
        s.population=1;s.economyPopulation=1;s.wood=128;s.stone=128;s.food=64;s.treasury=32;
        s.governorMessage="Expedition surveying for a supply camp";
    }
    private void discover(MinecraftServer server) {
        if(!data.autoFound || !DiscoveryRules.unlocked(data.settlements) || builder.busy() || data.settlements.size()>=32) return;
        var players=server.getPlayerList().getPlayers();if(players.isEmpty()) return;
        var player=players.get(Math.floorMod(autoAttempt/4,players.size()));
        int[][] offsets={{112,0},{0,112},{-112,0},{0,-112}};var offset=offsets[Math.floorMod(autoAttempt++,4)];
        String dim=player.level().dimension().identifier().toString();
        if(!dim.equals("minecraft:overworld")) return;
        int x=player.blockPosition().getX()+offset[0],z=player.blockPosition().getZ()+offset[1];
        if(data.settlements.stream().filter(s->s.automatic).count()>=LivingWorldSettings.current.maxAutomaticSettlements) return;
        if(player.level().getChunkSource().getChunkNow(x>>4,z>>4)==null) return;
        if(!separated(dim,x,z,384)) return;
        for(var colony:IColonyManager.getInstance().getColonies(player.level())) {
            var center=colony.getCenter();if((long)(center.getX()-x)*(center.getX()-x)+(long)(center.getZ()-z)*(center.getZ()-z)<384L*384L) return;
        }
        var s=new Settlement("Frontier_"+UUID.randomUUID().toString().substring(0,8),dim,x,player.blockPosition().getY(),z);
        prepareExpedition(s,player);s.automatic=true;PackGovernor.select(s,player.level());s.name=TownNames.next(s.expansionPack,data.settlements,UUID.randomUUID().hashCode());data.settlements.add(s);save();
        player.sendSystemMessage(Component.literal("An expedition is seeking a camp near "+x+", "+z+" ("+s.name+")."));
    }

    private void load(MinecraftServer server) {
        LivingWorldSettings.load();
        ready=false; tick=0; autoTicks=0; autoAttempt=0;visitedChunksDirty=false;rotationAtStop=null;VisitedChunks.resetPlayerVisits();workChunks.reset();builder.reset();builderWatchdog.reset();governor.reset();founding.reset();starters.reset();supplies.reset();roads.reset();escort.reset();quests.reset();journeys.reset();life.reset();couriers.reset(); data=new Save(); file=server.getWorldPath(LevelResource.ROOT).resolve("livingworld.json");
        try {
            if(Files.exists(file)) {
                data=GSON.fromJson(Files.readString(file),Save.class);
                if(data==null || data.version<1 || data.version>17 || data.settlements==null || data.settlements.size()>32) throw new IllegalArgumentException("Unsupported or invalid save");
                if(data.charters==null)data.charters=new HashMap<>();
                if(data.journeys==null)data.journeys=new HashMap<>();
                if(data.journeys.size()>4096)throw new IllegalArgumentException("Too many player journals");
                for(var entry:data.journeys.entrySet()){UUID.fromString(entry.getKey());if(entry.getValue()==null)throw new IllegalArgumentException("Missing player journal");entry.getValue().validate();if(entry.getValue().courier!=null && !entry.getKey().equals(entry.getValue().courier.owner))throw new IllegalArgumentException("Dispatch owner differs from journal");}
                if(data.playerVisitedChunks==null)data.playerVisitedChunks=new HashMap<>();
                VisitedChunks.loadPlayerVisits(data.playerVisitedChunks);
                if(data.workRotation==null)data.workRotation=new WorkChunkLoader.State();
                workChunks.restore(data.workRotation);
                if(data.charters.size()>256)throw new IllegalArgumentException("Too many saved village charters");
                for(var entry:data.charters.entrySet()){
                    UUID.fromString(entry.getKey());if(entry.getValue()==null)throw new IllegalArgumentException("Invalid village charter");entry.getValue().validate();
                }
                Set<String> names = new HashSet<>();
                for(var s:data.settlements) { if(data.version<11)s.distantEnabled=true;s.validate();if(s.colonyReady && s.governorEnabled)s.materialMode=true; if(!names.add(s.name.toLowerCase(Locale.ROOT))) throw new IllegalArgumentException("Duplicate settlement"); }
                if(data.version<17) {
                    var backup=file.resolveSibling("livingworld-v"+data.version+"-backup.json");
                    if(!Files.exists(backup)) Files.copy(file,backup);
                    data.version=17;
                }
            }
            ColonyBridge.restorePacks(server);
            ready=true; LOG.info("Living World loaded {} simulated settlements",data.settlements.size());
        } catch(Exception e) { LOG.error("Living World disabled to preserve unreadable save {}",file,e); }
    }
    private void save() {
        if(!ready || file==null) return;
        try {
            if(visitedChunksDirty)data.playerVisitedChunks=VisitedChunks.playerVisitSnapshot();
            data.workRotation=rotationAtStop==null?workChunks.snapshot():rotationAtStop;
            Path temp=file.resolveSibling("livingworld.json.tmp");
            Files.writeString(temp,GSON.toJson(data));
            try { Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
            catch(AtomicMoveNotSupportedException e) { Files.move(temp,file,StandardCopyOption.REPLACE_EXISTING); }
            visitedChunksDirty=false;
        } catch(Exception e) { LOG.error("Could not save Living World",e); }
    }
}

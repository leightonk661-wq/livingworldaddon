package dev.livingworld;
import java.util.function.ToIntFunction;
/** One survival-to-capital build order for local and distant settlement growth. */
public final class TownPlanner {
    public static String next(Settlement town,ToIntFunction<String> count){
        int homes=count.applyAsInt("residence"),farms=count.applyAsInt("farmer");
        if(homes==0)return "residence";
        if(farms==0)return "farmer";
        if(town.food<Economy.reserve(town)+16 && farms<3)return "farmer";
        if(homes<8 && homes*4<town.economyPopulation+town.pendingMigrants)return "residence";
        return next(count);
    }
    public static String next(ToIntFunction<String> count){
        if(count.applyAsInt("residence")<1)return "residence";
        if(count.applyAsInt("farmer")<1)return "farmer";
        if(count.applyAsInt("residence")<2)return "residence";
        if(count.applyAsInt("lumberjack")<1)return "lumberjack";
        if(count.applyAsInt("miner")<1)return "miner";
        if(count.applyAsInt("warehouse")<1)return "warehouse";
        if(count.applyAsInt("deliveryman")<1)return "deliveryman";
        if(count.applyAsInt("residence")<3)return "residence";
        if(count.applyAsInt("farmer")<2)return "farmer";
        if(count.applyAsInt("hospital")<1)return "hospital";
        if(count.applyAsInt("guardtower")<1)return "guardtower";
        if(count.applyAsInt("residence")<6)return "residence";
        if(count.applyAsInt("school")<1)return "school";
        if(count.applyAsInt("university")<1)return "university";
        if(count.applyAsInt("barracks")<1)return "barracks";
        if(count.applyAsInt("farmer")<3)return "farmer";
        if(count.applyAsInt("residence")<8)return "residence";
        return null;
    }
}

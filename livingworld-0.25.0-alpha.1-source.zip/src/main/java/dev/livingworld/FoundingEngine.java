package dev.livingworld;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.storage.StructurePacks;
import com.ldtteam.structurize.placement.StructurePlacer;
import com.ldtteam.structurize.placement.structure.CreativeStructureHandler;
import com.ldtteam.structurize.api.RotationMirror;
import com.ldtteam.structurize.util.BlockInfo;
import com.minecolonies.api.colony.IColonyManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.io.InputStreamReader;

/** One global survey/placement job. Never loads chunks to discover or construct a settlement. */
public final class FoundingEngine {
    private static final Map<String,Map<String,String>> STARTERS;
    static{try(var in=new InputStreamReader(Objects.requireNonNull(FoundingEngine.class.getResourceAsStream("/livingworld-starter-catalog.json")),java.nio.charset.StandardCharsets.UTF_8)){
        STARTERS=new Gson().fromJson(in,new TypeToken<Map<String,Map<String,String>>>(){}.getType());
    }catch(Exception e){throw new IllegalStateException(e);}}
    private int clock,turn;
    private Job job;
    private final CampWildlife wildlife=new CampWildlife();
    private static final class Job {
        Settlement s;ServerLevel level;ServerPlayer player;SitePlan site;Blueprint bp;CompletableFuture<Blueprint> future;
        int columns,volume,low=Integer.MAX_VALUE,high=Integer.MIN_VALUE,ticks;
        int anchorGround;
        int[] surfaces;int gradeScan;List<CampTerrain.Cell> gradePlan;
        Map<BlockPos,BlockState> graded=new HashMap<>();
        boolean placing;StructurePlacer placer;AccessSurvey access;
    }
    public void reset(){job=null;clock=turn=0;wildlife.reset();}
    public SitePlan workSite(Settlement s){return job!=null && job.s==s?job.site:null;}
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save,WorkChunkLoader chunks){
        if(job!=null){try{work(save,chunks);}catch(Exception e){job.s.autoDevelop=false;job.s.governorEnabled=false;job.s.governorMessage="Expedition paused: "+DashboardData.clip(e.getMessage());org.slf4j.LoggerFactory.getLogger("livingworld").error("Expedition stopped",e);job=null;save.run();}return;}
        if(++clock<LivingWorldSettings.current.surveyIntervalTicks || towns.isEmpty())return;clock=0;
        var s=towns.get(Math.floorMod(turn++,towns.size()));if(!s.expedition || !s.autoDevelop || s.colonyReady)return;
        for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(s.dimension)){
            ServerPlayer player=null;for(var p:level.players())if(p.distanceToSqr(s.x,s.y,s.z)<192*192 && TownAutonomyRules.mayWitnessFounding(s,p.getUUID().toString())){player=p;break;}
            if(player==null && !(BackgroundProgress.eligible(s) && chunks.activeFor(s))){s.governorMessage=s.automatic?"Waiting for a player near the expedition":"Waiting for the founding player nearby";return;}
            try{
                if(level.getGameTime()<s.nextSurveyTick){s.governorMessage="Survey resting after unsuccessful sites; retries automatically within one minute";return;}
                PackGovernor.select(s,level);
                if(!STARTERS.containsKey(s.expansionPack)){s.governorMessage="Waiting for supported blueprint packs";return;}
                if(s.camp!=null && s.camp.complete){
                    if(!s.founderSpawned && !PioneerEscort.arrived(s,level)){
                        s.governorMessage="Waiting for escorted pioneer at the camp. "+s.journeyMessage;return;
                    }
                    ColonyBridge.startExpedition(s,level,player,save);
                    boolean joining=!s.recruitId.isEmpty() && !s.journeyComplete;
                    if(!PioneerEscort.finish(s,level)){s.governorMessage="Waiting for the pioneer to join the camp settler. "+s.journeyMessage;return;}
                    if(joining)save.run();
                    if(!s.starterSites.isEmpty()){ColonyBridge.activateExpedition(s,level,player,save);if(s.colonyReady)return;}
                }
                if(player==null && s.starterSites.stream().anyMatch(p->!p.complete)){s.governorMessage="Background starter assembly continuing";return;}
                var j=new Job();j.s=s;j.level=level;j.player=player;j.site=new SitePlan();
                if(s.camp!=null && !s.camp.complete){j.site=s.camp;j.placing=true;}
                else{
                    var p=j.site;p.pack=s.expansionPack;p.kind=s.camp==null?"camp":BackgroundProgress.nextStarter(s);
                    p.path=p.kind.equals("camp")?"decorations/supplies/camp.blueprint":STARTERS.get(p.pack).get(p.kind);
                    int limit=s.camp==null?48:TerrainRules.SEARCH_SITES;boolean found=false;
                    for(int n=0;n<limit;n++){
                        int attempt=s.siteAttempt++;var offset=s.camp==null?CampSafety.candidate(attempt):TerrainRules.candidate(attempt);
                        p.x=(s.camp==null?s.x:s.camp.x)+offset[0];p.z=(s.camp==null?s.z:s.camp.z)+offset[1];
                        if(player==null && !chunks.matchesTarget(s,p.x,p.z))continue;
                        if(!SurveyMemory.blocked(s,p.pack,p.kind,p.x,p.z,level.getGameTime())){found=true;break;}
                    }
                    if(!found){s.nextSurveyTick=level.getGameTime()+100;s.governorMessage="Waiting for failed-site cooldowns; retry/resume clears them";return;}
                }
                j.future=StructurePacks.getBlueprintFuture(j.site.pack,j.site.path,level.registryAccess());job=j;
                s.governorMessage=(j.placing?"Establishing ":"Finding terrain for ")+j.site.kind;
            }catch(IllegalArgumentException e){s.governorMessage=DashboardData.clip(e.getMessage());}
            catch(Exception e){s.autoDevelop=false;s.governorEnabled=false;s.governorMessage="Expedition paused: "+DashboardData.clip(e.getMessage());org.slf4j.LoggerFactory.getLogger("livingworld").error("Expedition setup failed",e);}
            return;
        }
    }
    private void reject(String reason){
        var s=job.s;s.governorMessage="Seeking another site: "+reason;
        if(!job.placing)SurveyMemory.reject(s,job.site.pack,job.site.kind,job.site.x,job.site.z,job.level.getGameTime(),reason);
        s.failedSites++;
        job=null;
    }
    public static boolean soft(BlockState b){return b.getFluidState().isEmpty() && (b.isAir()||b.is(Blocks.SHORT_GRASS)||b.is(Blocks.TALL_GRASS)||b.is(Blocks.FERN)||b.is(Blocks.LARGE_FERN)||b.is(Blocks.SNOW)||b.is(net.minecraft.tags.BlockTags.SMALL_FLOWERS)||b.is(Blocks.SUNFLOWER)||b.is(Blocks.LILAC)||b.is(Blocks.ROSE_BUSH)||b.is(Blocks.PEONY)||b.is(Blocks.PINK_PETALS)||b.is(Blocks.WILDFLOWERS)||b.is(Blocks.LEAF_LITTER));}
    public static boolean natural(BlockState b){return soft(b)||b.is(Blocks.DIRT)||b.is(Blocks.GRASS_BLOCK)||b.is(Blocks.COARSE_DIRT)||b.is(Blocks.PODZOL)||b.is(Blocks.ROOTED_DIRT)||b.is(Blocks.MOSS_BLOCK)||b.is(Blocks.STONE)||b.is(Blocks.ANDESITE)||b.is(Blocks.DIORITE)||b.is(Blocks.GRANITE)||b.is(Blocks.DEEPSLATE)||b.is(Blocks.SAND)||b.is(Blocks.RED_SAND)||b.is(Blocks.GRAVEL)||b.is(Blocks.SANDSTONE)||b.is(Blocks.RED_SANDSTONE);}
    private boolean loaded(Job j){var p=j.site;for(int x=(p.minX-16)>>4;x<=(p.minX+p.width+16)>>4;x++)for(int z=(p.minZ-16)>>4;z<=(p.minZ+p.depth+16)>>4;z++)if(j.level.getChunkSource().getChunkNow(x,z)==null)return false;return true;}
    private static boolean overlap(SitePlan a,SitePlan b){return PackGovernor.overlap(a.minX,a.minX+a.width-1,a.minZ,a.minZ+a.depth-1,b.minX,b.minX+b.width-1,b.minZ,b.minZ+b.depth-1,6);}
    private void work(Runnable save,WorkChunkLoader chunks)throws Exception{
        var j=job;var p=j.site;
        boolean nearby=j.player!=null && !j.player.hasDisconnected() && j.player.level()==j.level && j.player.distanceToSqr(j.s.x,j.s.y,j.s.z)<=192*192;
        boolean background=BackgroundProgress.eligible(j.s) && chunks.activeFor(j.s);
        if((!j.placing && !p.pack.equals(j.s.expansionPack)) || !j.s.autoDevelop || !j.s.governorEnabled || !(nearby || background)){job=null;return;}
        if(++j.ticks>12000){reject("operation timed out; will resume");return;}
        if(j.bp==null){
            if(!j.future.isDone())return;j.bp=j.future.join();
            if(j.bp==null)throw new IllegalArgumentException("Blueprint unavailable: "+p.path);
            if(j.bp.getSizeX()>48 || j.bp.getSizeZ()>48 || j.bp.getSizeY()>64)throw new IllegalArgumentException("Starter blueprint exceeds safe size limit");
            // Camp artwork only. Do not duplicate decorative entities on resume.

            if(!j.placing){
                p.width=j.bp.getSizeX();p.height=j.bp.getSizeY();p.depth=j.bp.getSizeZ();
                j.surfaces=new int[p.width*p.depth];
                p.minX=p.x-j.bp.getPrimaryBlockOffset().getX();p.minZ=p.z-j.bp.getPrimaryBlockOffset().getZ();
                if(p.kind.equals("camp") && CampSafety.nearFootprint(j.s.x+.5,j.s.z+.5,p,8)){reject("camp footprint too close to the founding point");return;}
                if(j.s.camp!=null && overlap(p,j.s.camp)){reject("camp clearance");return;}
                for(var other:j.s.starterSites)if(overlap(p,other)){reject("another reserved hut");return;}
                for(var road:j.s.roads)if(road.intersects(p.minX,p.minX+p.width-1,p.minZ,p.minZ+p.depth-1)){reject("reserved approach path");return;}
            }else{
                if(p.width!=j.bp.getSizeX() || p.height!=j.bp.getSizeY() || p.depth!=j.bp.getSizeZ())throw new IllegalArgumentException("Camp blueprint dimensions changed");
                j.placer=new StructurePlacer(new CreativeStructureHandler(j.level,ColonyBridge.sitePos(p),j.bp,RotationMirror.NONE,false)){
                    @Override public com.ldtteam.structurize.placement.BlockPlacementResult handleEntitySpawn(net.minecraft.world.level.Level level,BlockPos world,BlockPos local,com.ldtteam.structurize.util.ChangeStorage storage,boolean check){
                        return new com.ldtteam.structurize.placement.BlockPlacementResult(world,com.ldtteam.structurize.placement.BlockPlacementResult.Result.SUCCESS);
                    }
                };
            }
        }
        if(!loaded(j) && BackgroundProgress.eligible(j.s) && chunks.activeFor(j.s)){j.s.governorMessage="Background survey waiting for its full work area";return;}
        if(!loaded(j)){if(j.placing){j.s.governorMessage="Camp paused: load surrounding chunks";job=null;}else reject("unloaded chunks");return;}
        if(j.placing){place(j,save);return;}
        int budget=LivingWorldSettings.current.surveyCellsPerTick;
        while(j.columns<p.width*p.depth && budget-->0){
            int x=p.minX+j.columns%p.width,z=p.minZ+j.columns/p.width;j.columns++;
            var chunk=j.level.getChunkSource().getChunkNow(x>>4,z>>4);int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,x,z);
            for(int n=0;n<4 && soft(chunk.getBlockState(new BlockPos(x,y,z)));n++)y--;
            var ground=new BlockPos(x,y,z);var state=chunk.getBlockState(ground);
            if(!natural(state) || soft(state) || chunk.getBlockEntity(ground)!=null){reject("surface obstacle: "+net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(state.getBlock())+" at "+ground.toShortString());return;}
            var claim=IColonyManager.getInstance().getColonyByPosFromDim(j.level.dimension(),ground);
            if((j.s.colonyId>0 && claim==null) || (claim!=null && claim.getID()!=j.s.colonyId)){reject("site is outside this colony's available land");return;}
            if(x==p.x && z==p.z)j.anchorGround=y;
            j.surfaces[j.columns-1]=y;
            j.low=Math.min(j.low,y);j.high=Math.max(j.high,y);if(j.high-j.low>(p.kind.equals("camp")?CampTerrain.MAX_RELIEF:TerrainRules.MAX_RELIEF)){reject("slope rises "+(j.high-j.low)+" blocks; excavation limit is six");return;}
        }
        if(j.columns<p.width*p.depth)return;
        if(!p.kind.equals("camp") && !TerrainRules.buildable(j.low,j.high,j.anchorGround,j.bp.getPrimaryBlockOffset().getY())){reject("foundation would be too exposed; looking for a lower entrance");return;}
        p.y=(p.kind.equals("camp")?CampTerrain.elevation(j.surfaces):j.anchorGround)+1;p.minY=p.y-j.bp.getPrimaryBlockOffset().getY();
        if(p.minY<j.level.getMinY() || p.minY+p.height>=j.level.getMaxY()){reject("world height limit");return;}
        if(p.kind.equals("camp")){
            if(j.gradePlan==null)j.gradePlan=CampTerrain.plan(j.surfaces,p.width,p.depth,p.y-1);
            while(j.gradeScan<j.gradePlan.size() && budget-->0){
                var cell=j.gradePlan.get(j.gradeScan++);var pos=new BlockPos(p.minX+cell.x(),cell.y(),p.minZ+cell.z());
                var current=j.level.getBlockState(pos);var desired=(cell.fill()?Blocks.DIRT:Blocks.AIR).defaultBlockState();
                if(!natural(current) || j.level.getBlockEntity(pos)!=null){reject("protected block in camp groundwork at "+pos.toShortString());return;}
                j.graded.put(pos,desired);
                if(!current.equals(desired))p.groundwork.add(new CampTerrain.Change(pos.getX(),pos.getY(),pos.getZ(),cell.fill(),current.toString()));
            }
            if(j.gradeScan<j.gradePlan.size())return;
            if(!campExit(j)){reject("camp terrace has no walkable edge at this height");return;}
        }
        while(j.volume<p.width*p.height*p.depth && budget-->0){
            int index=j.volume++;var pos=new BlockPos(p.minX+index%p.width,p.minY+index/(p.width*p.depth),p.minZ+(index/p.width)%p.depth);
            var chunk=j.level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);var state=chunk.getBlockState(pos);
            if(!natural(state) || chunk.getBlockEntity(pos)!=null){reject("existing blocks inside footprint");return;}
            if(p.kind.equals("camp"))p.before.add(j.graded.getOrDefault(pos,state).toString());
        }
        if(j.volume<p.width*p.height*p.depth)return;
        if(p.kind.equals("camp") && j.level.players().stream().anyMatch(player->CampSafety.nearFootprint(player.getX(),player.getZ(),p,8))){reject("camp footprint too close to a player");return;}
        if(p.kind.equals("camp") && !IColonyManager.getInstance().isFarEnoughFromColonies(j.level,ColonyBridge.sitePos(p))){reject("too close to an existing colony");return;}
        if(!p.kind.equals("camp")){
            if(j.access==null)j.access=new AccessSurvey(j.level,j.s,p,j.bp);
            j.access.tick();j.s.governorMessage=j.access.reason;
            if(!j.access.done)return;if(j.access.result==null){reject(j.access.reason);return;}
            j.s.roads.add(j.access.result);
        }
        j.s.failedSites=0;j.s.nextSurveyTick=0;
        if(p.kind.equals("camp"))j.s.camp=p;else j.s.starterSites.add(p);
        j.s.governorMessage="Reserved "+p.kind+" from "+p.pack;save.run();job=null;
    }
    private void place(Job j,Runnable save){
        var p=j.site;
        if(j.level.players().stream().anyMatch(player->CampSafety.nearFootprint(player.getX(),player.getZ(),p,3))){
            j.s.governorMessage="Camp paused for player safety: move at least 3 blocks beyond its edges (X "+p.minX+" to "+(p.minX+p.width-1)+", Z "+p.minZ+" to "+(p.minZ+p.depth-1)+").";job=null;return;
        }
        if(p.groundworkCursor<p.groundwork.size()){
            int count=0;
            while(p.groundworkCursor<p.groundwork.size() && count++<4){
                var cell=p.groundwork.get(p.groundworkCursor);var pos=new BlockPos(cell.x,cell.y,cell.z);
                var current=j.level.getBlockState(pos);var desired=(cell.fill?Blocks.DIRT:Blocks.AIR).defaultBlockState();
                var claim=IColonyManager.getInstance().getColonyByPosFromDim(j.level.dimension(),pos);
                if(j.level.getBlockEntity(pos)!=null || (claim!=null && claim.getID()!=j.s.colonyId))throw new IllegalArgumentException("Camp groundwork now protected at "+pos.toShortString());
                if(!current.equals(desired)){
                    if(!current.toString().equals(cell.before) && !CampTerrain.sameSurfaceSoil(cell.before,current.toString()) && !soft(current))throw new IllegalArgumentException("Camp groundwork changed at "+pos.toShortString());
                    if((cell.fill || !soft(current)) && occupied(j,pos,true)){job=null;return;}
                    if(!j.level.setBlock(pos,desired,3))throw new IllegalArgumentException("Groundwork could not change "+pos.toShortString());
                }
                p.groundworkCursor++;
            }
            j.s.governorMessage="Preparing camp terrace: "+p.groundworkCursor+" / "+p.groundwork.size()+" earthwork blocks";
            if(p.groundworkCursor==p.groundwork.size())save.run();return;
        }
        int volume=p.width*p.height*p.depth,checks=0,placed=0;
        while(p.cursor<volume*2 && checks++<64 && placed<LivingWorldSettings.current.campBlocksPerTick){
            int index=p.cursor%volume;var local=new BlockPos(index%p.width,index/(p.width*p.depth),(index/p.width)%p.depth);var pos=new BlockPos(p.minX,p.minY,p.minZ).offset(local);
            var desired=j.bp.getBlockState(local);var current=j.level.getBlockState(pos);
            // Substitutions keep existing natural terrain; never expose schematic marker blocks.
            String id=net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(desired.getBlock()).toString();
            if(id.equals("structurize:blocksubstitution") || id.equals("structurize:blocksolidsubstitution")){p.cursor++;continue;}
            if(current.equals(desired) || (p.cursor>=volume && current.is(desired.getBlock()))){p.cursor++;continue;}
            if(!current.toString().equals(p.before.get(index)) && !CampTerrain.sameSurfaceSoil(p.before.get(index),current.toString()) && !soft(current))throw new IllegalArgumentException("Unexpected camp block change at "+pos.toShortString()+"; block preserved");
            if(j.level.getBlockEntity(pos)!=null)throw new IllegalArgumentException("Existing container at camp site");
            var claim=IColonyManager.getInstance().getColonyByPosFromDim(j.level.dimension(),pos);
            if(claim!=null && claim.getID()!=j.s.colonyId)throw new IllegalArgumentException("Camp site was claimed by another colony");
            if(!desired.isAir() && occupied(j,pos,false)){job=null;return;}
            var info=j.bp.getBlockInfoAsMap().get(local);if(info==null){p.cursor++;continue;}
            var result=j.placer.handleBlockPlacement(j.level,pos,null,info).getResult();
            if(result==com.ldtteam.structurize.placement.BlockPlacementResult.Result.FAIL || result==com.ldtteam.structurize.placement.BlockPlacementResult.Result.BREAK_BLOCK){
                if(p.cursor>=volume)throw new IllegalArgumentException("Camp block could not be placed at "+pos.toShortString());
            }
            p.cursor++;placed++;
        }
        j.s.governorMessage="Establishing supply camp: "+(100L*p.cursor/(volume*2))+"%";
        if(p.cursor>=volume*2){p.complete=true;p.before.clear();p.groundwork.clear();p.groundworkCursor=0;j.s.governorMessage="Camp ready; first settler arriving";save.run();job=null;}
    }
    private boolean occupied(Job j,BlockPos pos,boolean groundwork){
        var box=new net.minecraft.world.phys.AABB(pos);if(groundwork)box=box.expandTowards(0,1,0);
        var blockers=j.level.getEntities((net.minecraft.world.entity.Entity)null,box,ConstructionSafety::blocksWork);if(blockers.isEmpty())return false;
        var blocker=blockers.getFirst();boolean guided=wildlife.guide(j.level,j.site,blocker);
        j.s.governorMessage=(guided?"Guiding ":"Waiting for ")+blocker.getName().getString()+(guided?" out of the camp at ":" to leave the work block at ")+pos.toShortString();
        return true;
    }
    private boolean campExit(Job j){
        var p=j.site;int localY=p.y-p.minY;
        if(localY<1 || localY+1>=p.height)return false;
        for(int x=0;x<p.width;x++)for(int z=0;z<p.depth;z++){
            if(x!=0 && z!=0 && x!=p.width-1 && z!=p.depth-1)continue;
            var feet=j.bp.getBlockState(new BlockPos(x,localY,z));var head=j.bp.getBlockState(new BlockPos(x,localY+1,z));
            if(!soft(feet) || !soft(head))continue;
            var floor=j.bp.getBlockState(new BlockPos(x,localY-1,z));
            String id=net.minecraft.core.registries.BuiltInRegistries.BLOCK.getKey(floor.getBlock()).toString();
            if(!floor.isSolidRender() && !id.equals("structurize:blocksubstitution") && !id.equals("structurize:blocksolidsubstitution"))continue;
            for(var d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}}){
                int nx=x+d[0],nz=z+d[1];if(nx>=0 && nx<p.width && nz>=0 && nz<p.depth)continue;
                int wx=p.minX+nx,wz=p.minZ+nz;var chunk=j.level.getChunkSource().getChunkNow(wx>>4,wz>>4);if(chunk==null)continue;
                int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,wx,wz);
                for(int n=0;n<4 && soft(chunk.getBlockState(new BlockPos(wx,y,wz)));n++)y--;
                var ground=new BlockPos(wx,y,wz);var state=chunk.getBlockState(ground);
                if(Math.abs(y-(p.y-1))<=1 && natural(state) && !soft(state) && chunk.getBlockEntity(ground)==null && soft(chunk.getBlockState(ground.above())) && soft(chunk.getBlockState(ground.above(2))))return true;
            }
        }
        return false;
    }
}

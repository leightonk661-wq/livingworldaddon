package dev.livingworld;
import java.util.*;
/** Short pages suitable for the narrow vanilla book screen. */
public final class BookPages {
    private BookPages(){}
    public static List<String> fit(List<String> sections){
        var pages=new ArrayList<String>();
        for(String section:sections){
            String rest=section.strip();
            while(rest.length()>180 || rest.chars().filter(c->c==10).count()>10){
                int lineCut=-1;for(int line=0,pos=-1;line<11;line++){pos=rest.indexOf('\n',pos+1);if(pos<0)break;if(line==10)lineCut=pos;}
                int cut=rest.lastIndexOf(' ',180);int newline=rest.lastIndexOf('\n',180);cut=Math.max(cut,newline);if(cut<40)cut=Math.min(180,rest.length());if(lineCut>=0)cut=Math.min(cut,lineCut);
                pages.add(rest.substring(0,cut).strip());rest=rest.substring(cut).strip();
            }
            if(!rest.isEmpty())pages.add(rest);
        }
        return pages;
    }
}

package dev.livingworld;

/** Abstract town ledger. Never accesses chunks, entities or MineColonies inventories. */
public final class Economy {
    public record Cost(int wood,int stone,int food,int coins) { @Override public String toString(){return MaterialCosts.describe(new MaterialCosts.Price(wood,stone,food,coins));} }
    public static int count(Settlement s,String kind) {
        return (int)s.expansions.stream().filter(e->e.complete && kind.equals(e.kind)).count();
    }
    public static Cost cost(String kind) {
        return switch(kind) {
            case "residence" -> new Cost(64,32,8,4);
            case "farmer" -> new Cost(80,24,8,6);
            case "warehouse" -> new Cost(112,64,16,12);
            case "deliveryman" -> new Cost(48,24,8,6);
            case "lumberjack" -> new Cost(72,32,8,6);
            case "miner" -> new Cost(88,64,12,8);
            case "hospital" -> new Cost(96,64,16,12);
            case "guardtower" -> new Cost(80,80,12,12);
            case "school" -> new Cost(112,64,16,16);
            case "university", "barracks" -> new Cost(160,128,24,24);
            default -> throw new IllegalArgumentException("Unsupported economic building: "+kind);
        };
    }
    public static Cost planningCost(Settlement s,String kind){return s.materialMode?new Cost(0,0,4,2):cost(kind);}
    public static boolean affordable(Settlement s,String kind) {
        if(kind==null)return false;
        var c=planningCost(s,kind);return s.wood>=c.wood && s.stone>=c.stone && s.food>=c.food+reserve(s) && s.treasury>=c.coins;
    }
    public static void pay(Settlement s,String kind) {
        if(!affordable(s,kind))throw new IllegalArgumentException("Insufficient construction reserves");
        var c=planningCost(s,kind);s.wood-=c.wood;s.stone-=c.stone;s.food-=c.food;s.treasury-=c.coins;
    }
    public static void refund(Settlement s,String kind) {
        var c=planningCost(s,kind);s.wood=Math.min(512,s.wood+c.wood);s.stone=Math.min(512,s.stone+c.stone);
        s.food=Math.min(512,s.food+c.food);s.treasury=Math.min(4096,s.treasury+c.coins);
    }
    public static int reserve(Settlement s){return Math.max(8,s.economyPopulation*2);}
    public static String next(Settlement s){return TownPlanner.next(s,kind->count(s,kind));}
    public static void step(Settlement s) {
        if((!s.colonyReady && !SupplyRules.bootstrapping(s)) || !s.governorEnabled || s.pendingDeparture)return;
        s.economyCycles=(s.economyCycles+1)%1000000;
        if(s.recruitmentCooldown>0)s.recruitmentCooldown--;
        int people=Math.max(0,s.economyPopulation);
        if(people==0){s.economyMessage="No citizens available for production";return;}
        // Foraging and small gathering parties bootstrap a settlement without worker huts.
        int workers=Math.min(32,people),farms=count(s,"farmer");
        boolean starter=SupplyRules.bootstrapping(s);
        int available=Math.max(0,workers-1); // One citizen remains the builder.
        int farmHands=Math.min(farms,available);available-=farmHands;
        int woodHands=Math.min(count(s,"lumberjack"),available);available-=woodHands;
        int stoneHands=Math.min(count(s,"miner"),available);
        s.wood=Math.min(512,s.wood+(starter?4:1)+woodHands*5);
        s.stone=Math.min(512,s.stone+(starter?3:1)+stoneHands*4);
        int harvest=(starter?4:2)+farmHands*8;
        s.food=Math.min(512,s.food+harvest);
        int eaten=Math.max(1,(workers+1)/2);
        boolean hungry=s.food<eaten;s.food=Math.max(0,s.food-eaten);
        if(!hungry && s.economyCycles%(starter?2:4)==0)s.treasury=Math.min(4096,s.treasury+Math.max(1,workers/8)+count(s,"deliveryman"));
        s.economyMessage=hungry?"Food shortage: rationing; construction and recruitment delayed":starter?"Starter gathering and rations active":"Food "+(harvest-eaten)+"/cycle; farm "+farmHands+", wood "+woodHands+", stone "+stoneHands+" workers";
    }
    public static int price(Settlement s,String kind,boolean buying) {
        int stock=s.stock(kind);if(stock<0)throw new IllegalArgumentException("Use wood, stone or food.");
        // The town's purchase price remains below every sale price, preventing round-trip profit.
        return buying?(stock<32?4:stock<96?3:2):1;
    }
    public static void trade(Settlement s,String kind,boolean buying) {
        int price=price(s,kind,buying),stock=s.stock(kind);
        if(buying){
            int floor=kind.equals("food")?reserve(s):0;
            if(stock-8<floor)throw new IllegalArgumentException("Town is keeping its remaining "+kind+" in reserve.");
            if(s.treasury>4096-price)throw new IllegalArgumentException("Town treasury is full.");
            s.add(kind,-8);s.treasury+=price;
        }else{
            if(stock>504 || s.treasury<price)throw new IllegalArgumentException("Town cannot afford or store this delivery.");
            s.add(kind,8);s.treasury-=price;
        }
    }
    public static String status(Settlement s){
        String next=next(s);var c=next==null?null:planningCost(s,next);
        return "Town ledger: wood "+s.wood+", stone "+s.stone+", food "+s.food+", coins "+s.treasury+
            " | last counted citizens "+s.economyPopulation+" | "+s.economyMessage+
            " | next "+(next==null?"capital complete":next+" costs "+c)+"; food reserve "+reserve(s);
    }
}

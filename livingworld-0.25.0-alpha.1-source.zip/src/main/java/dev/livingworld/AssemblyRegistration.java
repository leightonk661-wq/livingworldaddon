package dev.livingworld;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.storage.StructurePacks;
import com.minecolonies.api.colony.IColony;
import com.minecolonies.api.colony.IColonyManager;
import com.minecolonies.api.tileentities.AbstractTileEntityColonyBuilding;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
/** Crash-recoverable registration for a paid project, after its full terrain journal was saved. */
public final class AssemblyRegistration {
    public static void ensure(Settlement s,Expansion e,ServerLevel level,Blueprint bp,IColony colony,Runnable save){
        if(!e.registrationPending)return;
        var p=e.assembly;var pos=ColonyBridge.sitePos(p);
        var claim=IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),pos);
        if(claim==null || claim.getID()!=s.colonyId)throw new IllegalArgumentException("Reserved distant hut is no longer in this colony");
        var desired=bp.getBlockState(bp.getPrimaryBlockOffset());
        var building=colony.getServerBuildingManager().getBuildings().get(pos);
        if(building==null){
            var current=level.getBlockState(pos);int index=(p.y-p.minY)*p.width*p.depth+(p.z-p.minZ)*p.width+(p.x-p.minX);
            if(!current.is(desired.getBlock())){
                if(level.getBlockEntity(pos)!=null || !current.toString().equals(p.before.get(index)))throw new IllegalArgumentException("Reserved distant hut anchor changed; preserved");
                if(!level.setBlock(pos,desired,3))throw new IllegalArgumentException("Could not place distant hut anchor");
            }
            if(!(level.getBlockEntity(pos) instanceof AbstractTileEntityColonyBuilding tile))throw new IllegalArgumentException("Distant hut tile missing");
            var pack=StructurePacks.getStructurePack(p.pack);if(pack==null)throw new IllegalArgumentException("Distant project pack unavailable");
            tile.setStructurePack(pack);tile.setBlueprintPath(p.path);tile.setSchematicName(p.kind+"0");
            var min=new BlockPos(p.minX,p.minY,p.minZ);var max=min.offset(p.width-1,p.height-1,p.depth-1);
            tile.setSchematicCorners(min.subtract(pos),max.subtract(pos));
            building=colony.getServerBuildingManager().addNewBuilding(tile,level);
            if(building==null)throw new IllegalArgumentException("Distant hut registration refused");
            building.setBuildingLevel(0);building.setStructurePack(p.pack);building.setBlueprintPath(p.path);building.setCorners(min,max);building.markDirty();
        }
        if(!level.getBlockState(pos).is(desired.getBlock()) || !p.path.equals(building.getBlueprintPath()))throw new IllegalArgumentException("Another building occupies the distant reservation");
        e.registrationPending=false;save.run();
    }
}

package dev.livingworld;
/** Explicit conversion prices for the abstract economy, not vanilla crafting recipes. */
public final class MaterialCosts {
    public static String describe(Price p){
        var parts=new java.util.ArrayList<String>();
        if(p.wood()>0)parts.add(p.wood()+" wood");if(p.stone()>0)parts.add(p.stone()+" stone");
        if(p.food()>0)parts.add(p.food()+" food");if(p.coins()>0)parts.add(p.coins()+" emeralds");
        return String.join(", ",parts);
    }
    public record Price(int wood,int stone,int food,int coins) {}
    public static Price quote(String id,int count){
        if(count<1 || count>64)throw new IllegalArgumentException("Invalid delivery size");
        String name=id.substring(id.indexOf(':')+1);
        if(id.equals("minecraft:bread"))return new Price(0,0,count,0);
        if(name.endsWith("_pickaxe") || name.endsWith("_axe") || name.endsWith("_shovel") || name.endsWith("_hoe")){
            if(name.startsWith("wooden_"))return new Price(3*count,0,0,0);
            if(name.startsWith("stone_"))return new Price(2*count,3*count,0,0);
            if(name.startsWith("iron_"))return new Price(2*count,0,0,3*count);
            return null;
        }
        if(id.startsWith("domum_ornamentum:"))return new Price((count+3)/4,(count+3)/4,0,0);
        if(id.equals("minecolonies:blockminecoloniesrack"))return new Price(2*count,0,0,0);
        if(id.equals("minecraft:bookshelf"))return new Price(count,0,0,count);
        if(!id.startsWith("minecraft:"))return null;
        if(name.endsWith("_log") || name.endsWith("_wood") || name.endsWith("_stem") || name.endsWith("_hyphae"))return new Price(count,0,0,0);
        if(name.contains("oak") || name.contains("spruce") || name.contains("birch") || name.contains("jungle") || name.contains("acacia") || name.contains("mangrove") || name.contains("cherry") || name.contains("bamboo") || name.contains("crimson") || name.contains("warped") || name.equals("stick") || name.equals("ladder") || name.equals("barrel") || name.equals("chest") || name.equals("crafting_table"))return new Price((count+3)/4,0,0,0);
        if(name.contains("stone") || name.contains("brick") || name.contains("deepslate") || name.contains("andesite") || name.contains("diorite") || name.contains("granite") || name.contains("terracotta") || name.contains("glass") || name.equals("sand") || name.equals("gravel") || name.endsWith("dirt") || name.equals("grass_block") || name.equals("furnace"))return new Price(0,count,0,0);
        if(name.endsWith("_wool") || name.endsWith("_carpet") || name.endsWith("_bed") || name.endsWith("_banner") || name.contains("lantern") || name.equals("torch") || name.equals("chain") || name.equals("iron_bars") || name.equals("flower_pot") || name.equals("campfire"))return new Price(0,0,0,(count+7)/8);
        if(name.endsWith("_leaves") || name.endsWith("_sapling") || name.endsWith("_flower") || name.equals("dandelion") || name.equals("poppy") || name.equals("fern") || name.equals("vine") || name.equals("short_grass") || name.equals("tall_grass") || name.equals("hay_block") || name.equals("lily_pad") || name.equals("moss_block") || name.equals("moss_carpet") || name.equals("wheat_seeds"))return new Price(0,0,0,(count+7)/8);
        return null; // Never silently conjure arbitrary valuable or modded items.
    }
    public static boolean canPay(Settlement s,Price p){return p!=null && s.wood>=p.wood && s.stone>=p.stone && s.food>=p.food && s.treasury>=p.coins;}
    public static void pay(Settlement s,Price p){if(!canPay(s,p))throw new IllegalArgumentException("Insufficient delivery stock");s.wood-=p.wood;s.stone-=p.stone;s.food-=p.food;s.treasury-=p.coins;}
}

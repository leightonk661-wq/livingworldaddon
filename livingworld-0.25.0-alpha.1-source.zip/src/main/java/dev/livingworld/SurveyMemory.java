package dev.livingworld;
public final class SurveyMemory {
    private static String key(String pack,String kind,int x,int z){return pack+"|"+kind+"|"+x+"|"+z;}
    public static boolean blocked(Settlement s,String pack,String kind,int x,int z,long now){return s.rejectedSites.getOrDefault(key(pack,kind,x,z),0L)>now;}
    public static void reject(Settlement s,String pack,String kind,int x,int z,long now,String reason){
        s.rejectedSites.entrySet().removeIf(e->e.getValue()<=now);
        if(s.rejectedSites.size()>=384)s.rejectedSites.remove(s.rejectedSites.keySet().iterator().next());
        s.rejectedSites.put(key(pack,kind,x,z),now+1200);
        s.siteReports.add(kind+" at "+x+", "+z+": "+reason);while(s.siteReports.size()>16)s.siteReports.removeFirst();
    }
}

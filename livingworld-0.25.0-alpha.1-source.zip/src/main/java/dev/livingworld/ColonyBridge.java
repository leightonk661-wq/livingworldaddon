package dev.livingworld;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import com.minecolonies.api.IMinecoloniesAPI;
import com.minecolonies.api.colony.IColony;
import com.minecolonies.api.colony.IColonyManager;
import com.minecolonies.api.colony.buildings.IBuilding;
import com.minecolonies.api.colony.savedata.IServerColonySaveData;
import com.minecolonies.api.eventbus.events.colony.ColonyCreatedModEvent;
import com.minecolonies.api.tileentities.AbstractTileEntityColonyBuilding;
import com.minecolonies.core.colony.Colony;
import com.minecolonies.core.colony.buildings.modules.WorkerBuildingModule;
import com.minecolonies.core.util.ChunkDataHelper;
import com.ldtteam.structurize.blueprints.v1.BlueprintUtil;
import com.ldtteam.structurize.storage.StructurePacks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.*;
import java.util.*;

/** Opt-in bridge. Real construction is managed by MineColonies; the addon maintains a separate abstract budget. */
public final class ColonyBridge {
    private static final List<String> MODS=List.of("minecraft","minecolonies","structurize","livingworld");
    private static Path root(MinecraftServer server) {return server.getWorldPath(LevelResource.ROOT).resolve("livingworld-structures");}
    private static String packName(Settlement s) {return "LivingWorld_"+s.colonyOwner.substring(0,8);}
    public static BlockPos hut(HousePlan p) {return new BlockPos(p.x,p.y+1,p.z+1);}

    public static BlockPos builderHut(Settlement s){return s.expedition?sitePos(s.starterSites.stream().filter(p->p.kind.equals("builder")).findFirst().orElseThrow(()->new IllegalArgumentException("Builder site not reserved yet"))):hut(s.plots.get(1));}
    public static BlockPos sitePos(SitePlan p){return new BlockPos(p.x,p.y,p.z);}
    public static BlockPos spawnAtCamp(Settlement s,ServerLevel level){
        var camp=s.camp;if(camp==null)return null;
        for(int dy=0;dy<=4;dy++)for(int dx=-4;dx<=4;dx++)for(int dz=-4;dz<=4;dz++){
            var pos=new BlockPos(camp.x+dx,camp.y+dy,camp.z+dz);
            var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
            if(chunk!=null && chunk.getBlockState(pos).isAir() && chunk.getBlockState(pos.above()).isAir()
                && chunk.getBlockState(pos.below()).isCollisionShapeFullBlock(level,pos.below())
                && level.getEntities(null,new net.minecraft.world.phys.AABB(pos).expandTowards(0,1,0)).isEmpty())return pos;
        }
        return null;
    }
    public static void startExpedition(Settlement s,ServerPlayer player,Runnable checkpoint){
        startExpedition(s,player.level(),player,checkpoint);
    }
    public static void startExpedition(Settlement s,ServerLevel level,ServerPlayer player,Runnable checkpoint){
        IColony c;
        if(s.colonyId==0){
            if(!IColonyManager.getInstance().isFarEnoughFromColonies(level,sitePos(s.camp)))throw new IllegalArgumentException("Camp is too close to another colony");
            for(int x=(s.camp.x-80)>>4;x<=(s.camp.x+80)>>4;x++)for(int z=(s.camp.z-80)>>4;z<=(s.camp.z+80)>>4;z++)
                if(level.getChunkSource().getChunkNow(x,z)==null)throw new IllegalArgumentException("Load the terrain within 80 blocks of the camp");
            if(s.colonyOwner==null)s.colonyOwner=UUID.randomUUID().toString();
            c=IServerColonySaveData.getOrComputeSaveData(level).createColony(level,s.name,sitePos(s.camp));
            var owner=new ServerPlayer(level.getServer(),level,new GameProfile(UUID.fromString(s.colonyOwner),"LW_Council"),ClientInformation.createDefault());
            c.getPermissions().setOwner(owner);s.colonyId=c.getID();checkpoint.run();
            c.setStructurePack(s.expansionPack);ChunkDataHelper.claimColonyChunks(level,true,(Colony)c,sitePos(s.camp));
            IMinecoloniesAPI.getInstance().getEventBus().post(new ColonyCreatedModEvent(c));
        }else c=colony(s,level);
        c.getSettings().getSetting(com.minecolonies.core.colony.buildings.workerbuildings.BuildingTownHall.MOVE_IN).copyValue(new com.minecolonies.core.colony.buildings.modules.settings.BoolSetting(false));
        ((Colony)c).setFreeMode(false);c.markDirty();
        if(player!=null && TownAutonomyRules.grantOfficer(s,player.getUUID().toString()))
            c.getPermissions().addPlayer(player.getUUID(),player.getName().getString(),c.getPermissions().getRankOfficer());
        if(!s.founderSpawned){
            var citizen=c.getCitizenManager().getCitizens().stream().min(java.util.Comparator.comparingInt(com.minecolonies.api.colony.ICitizenData::getId)).orElse(null);
            if(citizen==null){
                BlockPos pos=spawnAtCamp(s,level);
                if(pos==null)throw new IllegalArgumentException("Waiting for a clear spot at the camp for the first settler");
                citizen=c.getCitizenManager().<com.minecolonies.api.colony.ICitizenData>spawnOrCreateCivilian(null,level,List.of(pos),true);
                if(citizen==null)throw new IllegalArgumentException("First settler could not spawn yet");
                citizen.setSaturation(20);
            }
            s.pioneerCitizenId=citizen.getId();s.founderSpawned=true;
            s.population=1;s.economyPopulation=c.getCitizenManager().getCurrentCitizenCount();checkpoint.run();
        }
    }

    public static void activateExpedition(Settlement s,ServerPlayer player,Runnable checkpoint){
        activateExpedition(s,player.level(),player,checkpoint);
    }
    public static void activateExpedition(Settlement s,ServerLevel level,ServerPlayer player,Runnable checkpoint){
        if(s.camp==null || !s.camp.complete || s.starterSites.isEmpty())throw new IllegalArgumentException("Waiting for the camp and first builder site");
        startExpedition(s,level,player,checkpoint);var c=colony(s,level);
        for(var plan:s.starterSites){
            var pos=sitePos(plan);var b=c.getServerBuildingManager().getBuildings().get(pos);
            if(b!=null)continue;
            var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
            if(chunk==null)throw new IllegalArgumentException("Starter site is not loaded");
            var block=BuiltInRegistries.BLOCK.getValue(Identifier.parse("minecolonies:blockhut"+plan.kind));
            if(!FoundingEngine.soft(chunk.getBlockState(pos)) && !chunk.getBlockState(pos).is(block))throw new IllegalArgumentException("Starter anchor was changed at "+pos.toShortString());
            if(!chunk.getBlockState(pos).is(block))level.setBlock(pos,block.defaultBlockState(),3);
            if(!(level.getBlockEntity(pos) instanceof AbstractTileEntityColonyBuilding tile))throw new IllegalArgumentException("Starter hut block entity unavailable");
            tile.setStructurePack(StructurePacks.getStructurePack(plan.pack));tile.setBlueprintPath(plan.path);tile.setSchematicName(plan.kind+"0");
            var min=new BlockPos(plan.minX,plan.minY,plan.minZ);var max=min.offset(plan.width-1,plan.height-1,plan.depth-1);tile.setSchematicCorners(min.subtract(pos),max.subtract(pos));
            b=c.getServerBuildingManager().addNewBuilding(tile,level);if(b==null)throw new IllegalArgumentException("Starter building registration failed");
            b.setBuildingLevel(0);b.setStructurePack(plan.pack);b.setBlueprintPath(plan.path);b.setCorners(min,max);b.markDirty();checkpoint.run();
        }
        var builder=c.getServerBuildingManager().getBuildings().get(builderHut(s));var worker=builder.getFirstModuleOccurance(WorkerBuildingModule.class);
        if(builder.getAllAssignedCitizen().isEmpty()){
            var citizen=c.getCitizenManager().getJoblessCitizen();if(worker==null || citizen==null || !worker.assignCitizen(citizen))throw new IllegalArgumentException("Waiting to assign the expedition builder");
        }
        s.colonyReady=s.starterSites.size()==2;s.governorEnabled=true;s.materialMode=true;
        trainPioneer(s,c);
        s.governorMessage="Starter huts assemble automatically; builder assigned for later construction";checkpoint.run();
    }
    public static void trainPioneer(Settlement s,IColony colony){
        if(!s.expedition || !s.founderSpawned || s.pioneerTrained)return;
        var citizen=s.pioneerCitizenId>0?colony.getCitizenManager().getCivilian(s.pioneerCitizenId):colony.getCitizenManager().getCitizens().stream().min(java.util.Comparator.comparingInt(com.minecolonies.api.colony.ICitizenData::getId)).orElse(null);if(citizen==null)return;
        var skills=citizen.getCitizenSkillHandler();
        for(var skill:com.minecolonies.api.entity.citizen.Skill.values()){
            int increase=StarterRules.trainingIncrease(skills.getLevel(skill));if(increase>0)skills.incrementLevel(skill,increase);
        }
        citizen.markDirty(0);colony.markDirty();s.pioneerTrained=true;
    }
    public static void restorePacks(MinecraftServer server) throws Exception {
        Path root=root(server);if(!Files.isDirectory(root)) return;
        try(var paths=Files.list(root)) {
            for(var path:paths.filter(Files::isDirectory).toList())
                StructurePacks.discoverPackAtPath(path,false,MODS,false,"livingworld");
        }
    }
    public static IColony colony(Settlement s,ServerLevel level) {
        if(s.colonyId<=0) throw new IllegalArgumentException("This settlement has not been activated.");
        var colony=IColonyManager.getInstance().getColonyByWorld(s.colonyId,level);
        if(colony==null) throw new IllegalArgumentException("Linked colony is missing. It will not be recreated automatically.");
        if(s.colonyOwner==null || !UUID.fromString(s.colonyOwner).equals(colony.getPermissions().getOwner()))
            throw new IllegalArgumentException("The linked colony's owner changed. Automatic management is disabled.");
        return colony;
    }
    public static String activate(Settlement s,ServerPlayer player,Runnable checkpoint) throws Exception {
        if(s.expedition){activateExpedition(s,player,checkpoint);return status(s,player.level());}
        var level=player.level();
        if(!s.dimension.equals(level.dimension().identifier().toString())) throw new IllegalArgumentException("Visit the settlement's dimension first.");
        if(s.colonyReady) return status(s,level);
        if(s.plots.size()<2) throw new IllegalArgumentException("Two completed cottage plots are needed. Survey and advance the settlement first.");
        var first=s.plots.get(0);var second=s.plots.get(1);
        for(var p:List.of(first,second)) {
            if(p.cursor!=p.cells.size() || !p.blocked.isEmpty()) throw new IllegalArgumentException("Wait for both first cottages to finish placing.");
            // Check the full normal initial claim area before MineColonies claims it.
            for(int cx=(first.x-80)>>4;cx<=(first.x+80)>>4;cx++)
                for(int cz=(first.z-80)>>4;cz<=(first.z+80)>>4;cz++)
                    if(level.getChunkSource().getChunkNow(cx,cz)==null) throw new IllegalArgumentException("Load more surrounding terrain before activation (about 80 blocks around the first cottage).");
            if(s.colonyId==0) {
                for(var cell:p.cells) {
                    var pos=new BlockPos(cell.x(),cell.y(),cell.z());
                    var current=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4).getBlockState(pos);
                    var desired=BuiltInRegistries.BLOCK.getValue(Identifier.parse(cell.block())).defaultBlockState();
                    if(!current.equals(desired)) throw new IllegalArgumentException("Cottage changed at "+pos.toShortString()+". Restore it before activation.");
                }
            }
        }
        if(s.colonyId==0 && !IColonyManager.getInstance().isFarEnoughFromColonies(level,hut(first)))
            throw new IllegalArgumentException("Too close to an existing MineColonies colony.");
        if(s.colonyOwner==null) {s.colonyOwner=UUID.randomUUID().toString();checkpoint.run();}
        var path=root(player.level().getServer()).resolve(packName(s));Files.createDirectories(path);
        JsonObject meta=new JsonObject();meta.addProperty("name",packName(s));meta.addProperty("version","1");meta.addProperty("pack-format","1");
        meta.addProperty("desc","Living World experimental cottage colony");meta.addProperty("icon","");
        JsonArray authors=new JsonArray();authors.add("Living World");meta.add("authors",authors);
        JsonArray mods=new JsonArray();mods.add("minecolonies");mods.add("structurize");meta.add("mods",mods);
        Files.writeString(path.resolve("pack.json"),meta.toString());
        StructurePacks.discoverPackAtPath(path,false,MODS,false,"livingworld");
        if(StructurePacks.getStructurePack(packName(s))==null) throw new IllegalArgumentException("Could not register the cottage blueprint pack.");
        IColony colony;
        if(s.colonyId==0) {
            var save=IServerColonySaveData.getOrComputeSaveData(level);
            colony=save.createColony(level,s.name,hut(first));
            // This identity is only an owner record, never spawned or connected as a player.
            var owner=new ServerPlayer(level.getServer(),level,new GameProfile(UUID.fromString(s.colonyOwner),"LW_Council"),ClientInformation.createDefault());
            colony.getPermissions().setOwner(owner);
            s.colonyId=colony.getID();checkpoint.run();
            colony.setStructurePack(packName(s));
            ChunkDataHelper.claimColonyChunks(level,true,(Colony)colony,hut(first));
            IMinecoloniesAPI.getInstance().getEventBus().post(new ColonyCreatedModEvent(colony));
        } else colony=colony(s,level);
        colony.getPermissions().addPlayer(player.getUUID(),player.getName().getString(),colony.getPermissions().getRankOfficer());
        colony.getPackageManager().addImportantColonyPlayer(player);
        colony.getPackageManager().addCloseSubscriber(player);
        // Explicit test mode: avoids starvation and material requests obscuring the integration test.
        ((Colony)colony).setFreeMode(true);
        prepareBuilding(s,level,colony,first,"townhall",path);
        var builder=prepareBuilding(s,level,colony,second,"builder",path);
        colony.getCitizenManager().calculateMaxCitizens();
        int missing=Math.max(0,4-colony.getCitizenManager().getCurrentCitizenCount());
        for(int i=0;i<missing;i++) {
            var spawn=new BlockPos(first.x-1+(i%3),first.y+1,first.z-1);
            var citizen=colony.getCitizenManager().spawnOrCreateCitizen(null,level,spawn);
            if(citizen==null) break;
            citizen.setSaturation(20);
        }
        var worker=builder.getFirstModuleOccurance(WorkerBuildingModule.class);
        if(worker==null) throw new IllegalArgumentException("Builder's worker module is unavailable; activation can be retried.");
        if(builder.getAllAssignedCitizen().isEmpty()) {
            var candidate=colony.getCitizenManager().getJoblessCitizen();
            if(candidate==null || !worker.assignCitizen(candidate)) throw new IllegalArgumentException("No available citizen to appoint builder. Retry activation after citizens arrive.");
        }
        s.colonyReady=true;s.pendingDeparture=false;checkpoint.run();
        colony.getPackageManager().sendColonyViewPackets();
        colony.getPackageManager().sendPermissionsPackets();
        return "Activated "+s.name+" as MineColonies #"+s.colonyId+". Four initial citizens, a town hall and a builder hut. Builder free mode ON; enable governor for the abstract economy and funded expansions. You are a test officer.";
    }
    private static IBuilding prepareBuilding(Settlement s,ServerLevel level,IColony colony,HousePlan plan,String type,Path folder) throws Exception {
        var pos=hut(plan);var block=BuiltInRegistries.BLOCK.getValue(Identifier.parse("minecolonies:blockhut"+type));
        if(block==null || block.defaultBlockState().isAir()) throw new IllegalArgumentException("Missing MineColonies "+type+" block.");
        var existing=colony.getServerBuildingManager().getBuildings().get(pos);
        if(existing!=null && !existing.isMatchingBlock(block)) throw new IllegalArgumentException("A different colony building occupies the hut anchor.");
        var current=level.getBlockState(pos);
        if(!current.isAir() && !current.is(block)) throw new IllegalArgumentException("Hut anchor occupied at "+pos.toShortString());
        if(current.isAir() && !level.setBlock(pos,block.defaultBlockState(),3)) throw new IllegalArgumentException("Could not place hut block.");
        if(!(level.getBlockEntity(pos) instanceof AbstractTileEntityColonyBuilding tile)) throw new IllegalArgumentException("Hut block entity is not ready.");
        String file=type+"1.blueprint";
        tile.setStructurePack(StructurePacks.getStructurePack(packName(s)));tile.setBlueprintPath(file);tile.setSchematicName(type+"1");
        var min=new BlockPos(plan.x-3,plan.y-2,plan.z-3);var max=new BlockPos(plan.x+3,plan.y+6,plan.z+3);
        tile.setSchematicCorners(min.subtract(pos),max.subtract(pos));
        var blueprint=Files.exists(folder.resolve(file)) ? StructurePacks.getBlueprint(packName(s),file,level.registryAccess()) : null;
        if(blueprint==null) {
            blueprint=BlueprintUtil.createBlueprint(level,min,false,(short)7,(short)9,(short)7,type+"1",Optional.of(pos));
            try(var out=Files.newOutputStream(folder.resolve(file))) {BlueprintUtil.writeToStream(out,blueprint);}
        }
        // Structurize's scanner replaces the tile's path with its display name.
        // Restore the real filename before the building copies its schematic settings.
        tile.setBlueprintPath(file);
        var building=existing!=null ? existing : colony.getServerBuildingManager().addNewBuilding(tile,level);
        if(building==null) throw new IllegalArgumentException("Could not register "+type+"; activation may be retried.");
        building.setStructurePack(packName(s));building.setBlueprintPath(file);building.setBuildingLevel(1);
        building.setCorners(min,max);building.onUpgradeComplete(blueprint,1);building.markDirty();
        return building;
    }
    public static String status(Settlement s,ServerLevel level) {
        var c=colony(s,level);
        return "MineColonies #"+c.getID()+" | citizens "+c.getCitizenManager().getCurrentCitizenCount()+" | buildings "+c.getServerBuildingManager().getBuildings().size()+" | active "+c.isActive()+" | test free mode "+((Colony)c).isFreeMode()+" | activation complete "+s.colonyReady;
    }
    public static String repair(Settlement s,ServerLevel level,int plot) {
        if(!s.colonyReady) throw new IllegalArgumentException("Finish activation first.");
        var c=colony(s,level);var target=c.getServerBuildingManager().getBuildings().get(s.expedition?sitePos(s.starterSites.stream().filter(p->p.kind.equals(plot==1?"townhall":"builder")).findFirst().orElseThrow()):hut(s.plots.get(plot-1)));
        var builder=c.getServerBuildingManager().getBuildings().get(builderHut(s));
        if(target==null || builder==null) throw new IllegalArgumentException("Town hall or builder hut is missing.");
        if(target.isPendingConstruction()) throw new IllegalArgumentException("A work order already exists for that building.");
        var result=target.requestRepair(builder.getPosition(),true);
        return "MineColonies repair result for plot "+plot+": "+result+". Check the builder hut's work orders; the worker needs daylight and loaded terrain.";
    }
}

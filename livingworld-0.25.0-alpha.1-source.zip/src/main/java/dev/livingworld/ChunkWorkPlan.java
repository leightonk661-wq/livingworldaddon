package dev.livingworld;
import net.minecraft.world.level.ChunkPos;
import java.util.*;
/** Bounded chunk corridor around a hut and its active worksite. */
public final class ChunkWorkPlan {
    public static java.nio.file.Path overworldRegion(java.nio.file.Path worldRoot){return worldRoot.resolve("region");}
    public static List<Integer> rotationOrder(int count,int next){
        if(count<=0)return List.of();
        var order=new ArrayList<Integer>(count);
        for(int i=0;i<count;i++)order.add(Math.floorMod(next+i,count));
        return order;
    }
    /** Keep a narrow travel route and enough terrain around both the builder and worksite. */
    public static Set<ChunkPos> workArea(int builderX,int builderZ,int targetX,int targetZ,boolean construction,int cap){
        var path=route(builderX,builderZ,targetX,targetZ,1,cap);
        if(path.isEmpty())return Set.of();
        var result=new LinkedHashSet<>(path);
        int bx=builderX>>4,bz=builderZ>>4,tx=targetX>>4,tz=targetZ>>4;
        for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)result.add(new ChunkPos(bx+dx,bz+dz));
        int radius=construction?2:1;
        for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++)result.add(new ChunkPos(tx+dx,tz+dz));
        return result.size()<=cap?result:Set.of();
    }
    /** Exact reserved footprint plus the same safety border checked by placement. */
    public static Set<ChunkPos> siteArea(int anchorX,int anchorZ,SitePlan site,int cap){
        if(site==null || site.width<1 || site.depth<1 || site.width>48 || site.depth>48)return Set.of();
        var route=route(anchorX,anchorZ,site.x,site.z,1,cap);if(route.isEmpty())return Set.of();
        var result=new LinkedHashSet<>(route);
        for(int x=(site.minX-16)>>4;x<=(site.minX+site.width+16)>>4;x++)for(int z=(site.minZ-16)>>4;z<=(site.minZ+site.depth+16)>>4;z++){
            result.add(new ChunkPos(x,z));if(result.size()>cap)return Set.of();
        }
        return result;
    }
    /** Player simulation can replace tickets only when every work chunk is covered. */
    public static boolean covered(Set<ChunkPos> work,Collection<ChunkPos> players,int simulationDistance){
        if(work.isEmpty() || players.isEmpty() || simulationDistance<2)return false;
        int radius=simulationDistance-1;
        return work.stream().allMatch(chunk->players.stream().anyMatch(player->
            Math.abs(chunk.x()-player.x())<=radius && Math.abs(chunk.z()-player.z())<=radius));
    }
    public static Set<ChunkPos> route(int startX,int startZ,int endX,int endZ,int margin,int cap){
        if(margin<0 || margin>2 || cap<1)return Set.of();
        int ax=startX>>4,az=startZ>>4,bx=endX>>4,bz=endZ>>4;
        int steps=Math.max(Math.abs(ax-bx),Math.abs(az-bz));
        var result=new LinkedHashSet<ChunkPos>();
        for(int i=0;i<=steps;i++){
            int x=ax+(int)Math.round((bx-ax)*(i/(double)Math.max(1,steps)));
            int z=az+(int)Math.round((bz-az)*(i/(double)Math.max(1,steps)));
            for(int dx=-margin;dx<=margin;dx++)for(int dz=-margin;dz<=margin;dz++){
                result.add(new ChunkPos(x+dx,z+dz));if(result.size()>cap)return Set.of();
            }
        }
        return result;
    }
}

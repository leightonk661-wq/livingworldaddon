package dev.livingworld;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
public final class DashboardNetwork {
    public record Request(String action,String town,String value) implements CustomPacketPayload {
        public static final Type<Request> TYPE=new Type<>(net.minecraft.resources.Identifier.parse("livingworld:dashboard_request_v1"));
        public static final StreamCodec<FriendlyByteBuf,Request> CODEC=StreamCodec.of((b,p)->{b.writeUtf(p.action,24);b.writeUtf(p.town,24);b.writeUtf(p.value,80);},b->new Request(b.readUtf(24),b.readUtf(24),b.readUtf(80)));
        public Type<Request> type(){return TYPE;}
    }
    public record Snapshot(String json,boolean open) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE=new Type<>(net.minecraft.resources.Identifier.parse("livingworld:dashboard_snapshot_v1"));
        public static final StreamCodec<FriendlyByteBuf,Snapshot> CODEC=StreamCodec.of((b,p)->{b.writeUtf(p.json,262144);b.writeBoolean(p.open);},b->new Snapshot(b.readUtf(262144),b.readBoolean()));
        public Type<Snapshot> type(){return TYPE;}
    }
    public record Hint(String title,String detail) implements CustomPacketPayload {
        public static final Type<Hint> TYPE=new Type<>(net.minecraft.resources.Identifier.parse("livingworld:journey_hint_v1"));
        public static final StreamCodec<FriendlyByteBuf,Hint> CODEC=StreamCodec.of((b,p)->{b.writeUtf(p.title,160);b.writeUtf(p.detail,512);},b->new Hint(b.readUtf(160),b.readUtf(512)));
        public Type<Hint> type(){return TYPE;}
    }
    public record Journal(String json,boolean open) implements CustomPacketPayload {
        public static final Type<Journal> TYPE=new Type<>(net.minecraft.resources.Identifier.parse("livingworld:journal_v1"));
        public static final StreamCodec<FriendlyByteBuf,Journal> CODEC=StreamCodec.of((b,p)->{b.writeUtf(p.json,32768);b.writeBoolean(p.open);},b->new Journal(b.readUtf(32768),b.readBoolean()));
        public Type<Journal> type(){return TYPE;}
    }
    public static void register(){PayloadTypeRegistry.clientboundPlay().register(Journal.TYPE,Journal.CODEC);PayloadTypeRegistry.clientboundPlay().register(Hint.TYPE,Hint.CODEC);PayloadTypeRegistry.serverboundPlay().register(Request.TYPE,Request.CODEC);PayloadTypeRegistry.clientboundPlay().register(Snapshot.TYPE,Snapshot.CODEC);}
}


package dev.livingworld;

import java.util.ArrayList;
import java.util.List;

/** Persistent block-level construction journal; completed entries are never repaired. */
public final class HousePlan {
    public int x, y, z, cursor;
    public String blocked = "";
    public List<Cell> cells = new ArrayList<>();
    public record Cell(int x, int y, int z, String before, String block) {}
    public int target(int houseIndex, int completedHomes, int progress) {
        if (houseIndex < completedHomes) return cells.size();
        if (houseIndex == completedHomes) return cells.size() * progress / 40;
        return 0;
    }
    public void validate() {
        if(cells == null || cells.size() > 600 || cursor < 0 || cursor > cells.size() || blocked == null)
            throw new IllegalArgumentException("Invalid building journal");
        for(var c:cells) if(c == null || c.before()==null || c.block()==null ||
            Math.abs((long)c.x()-x)>3 || Math.abs((long)c.z()-z)>3 || c.y()<y-2 || c.y()>y+6)
            throw new IllegalArgumentException("Invalid building cell");
    }
    /** Small original test cottage, not a MineColonies blueprint or functional worker hut. */
    public static String blockAt(int dx,int dy,int dz) {
        if(dy<0) return "minecraft:cobblestone";
        if(dy==0) return "minecraft:oak_planks";
        if(dy<=3) {
            if(dz==-3 && dx==0 && dy<=2) return "minecraft:air";
            if(Math.abs(dx)==3 && Math.abs(dz)==3) return "minecraft:oak_log";
            if(Math.abs(dx)==3 || Math.abs(dz)==3) {
                if(dy==2 && (dx==0 || dz==0)) return "minecraft:glass";
                return "minecraft:oak_planks";
            }
            return "minecraft:air";
        }
        return Math.abs(dx)<=6-dy ? "minecraft:oak_planks" : "minecraft:air";
    }
}

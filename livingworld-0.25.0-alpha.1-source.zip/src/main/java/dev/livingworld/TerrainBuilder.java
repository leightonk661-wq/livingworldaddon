package dev.livingworld;

import com.minecolonies.api.colony.IColonyManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.*;
import java.util.function.Consumer;

public final class TerrainBuilder {
    private static final int[][] OFFSETS={{-12,-12},{12,-12},{-12,12},{12,12},{-36,-12},{36,-12},{-12,36},{12,36}};
    private int turn;
    private Survey job;
    private record Survey(Settlement settlement, ServerLevel level, Consumer<String> done, int[] next) {}
    public boolean busy() { return job!=null; }
    public void survey(Settlement s, ServerLevel level, Consumer<String> done) {
        if(job!=null) throw new IllegalArgumentException("A survey is already running. Try again shortly.");
        if(!s.plots.isEmpty()) throw new IllegalArgumentException("This settlement already has reserved plots.");
        job=new Survey(s,level,done,new int[]{0});
    }
    public void reset() { job=null; turn=0; }
    public void tick(MinecraftServer server, List<Settlement> settlements) {
        if(job!=null) {
            var j=job; int index=j.next()[0]++;
            var offset=OFFSETS[index];
            var plot=surveyPlot(j.level(),j.settlement().x+offset[0],j.settlement().z+offset[1]);
            if(plot!=null) j.settlement().plots.add(plot);
            if(j.next()[0]==OFFSETS.length) {
                j.settlement().surveyed=true;
                job=null;
                j.done().accept("Survey finished: " + j.settlement().plots.size()+" suitable plots. Use /livingworld plots "+j.settlement().name);
            }
            return; // Survey work and placement never run in the same tick.
        }
        if(settlements.isEmpty()) return;
        var s=settlements.get(Math.floorMod(turn++,settlements.size()));
        if(s.expedition || s.colonyId>0) return;
        ServerLevel level=null;
        for(var candidate:server.getAllLevels()) if(candidate.dimension().identifier().toString().equals(s.dimension)) {level=candidate;break;}
        if(level==null) return;
        if(s.pendingDeparture) {
            if(!nearPlayer(level,s.x,s.z,112)) s.pendingDeparture=false;
            return;
        }
        if(!nearPlayer(level,s.x,s.z,112)) return;
        // One plot per tick, at most 32 inspected entries and four placed blocks globally.
        for(int i=0;i<s.plots.size();i++) {
            var p=s.plots.get(i); int target=p.target(i,s.homes,s.progress);
            if(p.cursor>=target || !p.blocked.isEmpty() || !loadedHalo(level,p.x,p.z)) continue;
            int changes=0,reads=0;
            while(p.cursor<target && changes<4 && reads++<32) {
                var cell=p.cells.get(p.cursor); var pos=new BlockPos(cell.x(),cell.y(),cell.z());
                if(IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),pos)!=null) {p.blocked="MineColonies claim at "+pos.toShortString();break;}
                var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
                if(chunk==null) break;
                var current=chunk.getBlockState(pos);
                var desired=BuiltInRegistries.BLOCK.getValue(Identifier.parse(cell.block())).defaultBlockState();
                // A matching target also handles a world save ahead of our construction journal.
                if(current.equals(desired)) {p.cursor++;continue;}
                if((!current.isAir() && !current.toString().equals(cell.before())) || chunk.getBlockEntity(pos)!=null) {
                    p.blocked="Terrain changed at "+pos.toShortString()+"; preserved the new block."; break;
                }
                // Never place a solid block through a player, animal or other entity.
                if(!desired.isAir() && !level.getEntities(null,new net.minecraft.world.phys.AABB(pos)).isEmpty()) break;
                if(!level.setBlock(pos,desired,3)) break;
                changes++;p.cursor++;
            }
            break;
        }
    }
    private static boolean nearPlayer(ServerLevel level,int x,int z,int radius) {
        for(var p:level.players()) if((p.getX()-x)*(p.getX()-x)+(p.getZ()-z)*(p.getZ()-z)<radius*radius) return true;
        return false;
    }
    private static boolean loadedHalo(ServerLevel level,int x,int z) {
        // Neighbour chunks are required too, so normal placement updates don't request new terrain.
        for(int cx=(x-19)>>4;cx<=(x+19)>>4;cx++)
            for(int cz=(z-19)>>4;cz<=(z+19)>>4;cz++)
                if(level.getChunkSource().getChunkNow(cx,cz)==null) return false;
        return true;
    }
    private static boolean soft(BlockState b) {
        return b.isAir() || b.is(Blocks.SHORT_GRASS) || b.is(Blocks.TALL_GRASS) || b.is(Blocks.FERN) || b.is(Blocks.LARGE_FERN) || b.is(Blocks.SNOW);
    }
    private static boolean ground(BlockState b) {
        return b.is(Blocks.GRASS_BLOCK) || b.is(Blocks.DIRT) || b.is(Blocks.COARSE_DIRT) || b.is(Blocks.PODZOL) || b.is(Blocks.STONE) || b.is(Blocks.SAND) || b.is(Blocks.GRAVEL);
    }
    private static HousePlan surveyPlot(ServerLevel level,int x,int z) {
        if(!nearPlayer(level,x,z,112) || !loadedHalo(level,x,z)) return null;
        int[][] heights=new int[7][7]; int low=Integer.MAX_VALUE,high=Integer.MIN_VALUE;
        for(int dx=-3;dx<=3;dx++) for(int dz=-3;dz<=3;dz++) {
            var chunk=level.getChunkSource().getChunkNow((x+dx)>>4,(z+dz)>>4);
            int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,x+dx,z+dz);
            for(int n=0;n<4 && soft(chunk.getBlockState(new BlockPos(x+dx,y,z+dz)));n++) y--;
            var pos=new BlockPos(x+dx,y,z+dz);
            if(!ground(chunk.getBlockState(pos)) || chunk.getBlockEntity(pos)!=null ||
                IColonyManager.getInstance().getColonyByPosFromDim(level.dimension(),pos)!=null) return null;
            heights[dx+3][dz+3]=y;low=Math.min(low,y);high=Math.max(high,y);
        }
        if(high-low>2 || high+8>=level.getMaxY()) return null;
        var p=new HousePlan();p.x=x;p.y=high+1;p.z=z;
        // Bottom-to-top order makes foundations and floors appear before walls and roofs.
        for(int y=low+1;y<=p.y+6;y++) for(int dx=-3;dx<=3;dx++) for(int dz=-3;dz<=3;dz++) {
            if(y<=heights[dx+3][dz+3]) continue;
            var pos=new BlockPos(x+dx,y,z+dz);
            var chunk=level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4);
            var state=chunk.getBlockState(pos);
            if(!soft(state) || chunk.getBlockEntity(pos)!=null) return null;
            p.cells.add(new HousePlan.Cell(pos.getX(),pos.getY(),pos.getZ(),state.toString(),HousePlan.blockAt(dx,y-p.y,dz)));
        }
        return p;
    }
}

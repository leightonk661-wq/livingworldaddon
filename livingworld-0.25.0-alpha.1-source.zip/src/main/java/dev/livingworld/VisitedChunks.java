package dev.livingworld;
import net.minecraft.world.level.ChunkPos;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.*;
/** Exact player-entry ledger plus Anvil header checks; neither operation generates terrain. */
public final class VisitedChunks {
    private static final Map<Long,BitSet> PLAYER_ENTERED=new HashMap<>();
    private static long regionKey(int x,int z){return ((long)x<<32) | (z&0xffffffffL);}
    private static long regionKey(ChunkPos pos){return regionKey(Math.floorDiv(pos.x(),32),Math.floorDiv(pos.z(),32));}
    private static int bit(ChunkPos pos){return Math.floorMod(pos.x(),32)+32*Math.floorMod(pos.z(),32);}
    public static synchronized void resetPlayerVisits(){PLAYER_ENTERED.clear();}
    /** Returns true only for a newly entered chunk, so the caller can schedule a save. */
    public static synchronized boolean recordPlayerEntry(ChunkPos pos){
        if(PLAYER_ENTERED.size()>=65536 && !PLAYER_ENTERED.containsKey(regionKey(pos)))return false;
        var bits=PLAYER_ENTERED.computeIfAbsent(regionKey(pos),unused->new BitSet(1024));
        int bit=bit(pos);if(bits.get(bit))return false;bits.set(bit);return true;
    }
    public static synchronized boolean playerEntered(ChunkPos pos){
        var bits=PLAYER_ENTERED.get(regionKey(pos));return bits!=null && bits.get(bit(pos));
    }
    public static synchronized Map<String,String> playerVisitSnapshot(){
        var out=new TreeMap<String,String>();
        for(var entry:PLAYER_ENTERED.entrySet()){
            long key=entry.getKey();String name=((int)(key>>32))+","+((int)key);
            out.put(name,Base64.getEncoder().encodeToString(entry.getValue().toByteArray()));
        }
        return out;
    }
    public static synchronized void loadPlayerVisits(Map<String,String> saved){
        PLAYER_ENTERED.clear();if(saved==null)return;
        if(saved.size()>65536)throw new IllegalArgumentException("Too many visited regions");
        for(var entry:saved.entrySet()){
            if(entry.getKey()==null || !entry.getKey().matches("-?\\d+,-?\\d+") || entry.getValue()==null)
                throw new IllegalArgumentException("Invalid visited region entry");
            var parts=entry.getKey().split(",",2);
            int x=Integer.parseInt(parts[0]),z=Integer.parseInt(parts[1]);
            byte[] bytes=Base64.getDecoder().decode(entry.getValue());
            if(bytes.length>128)throw new IllegalArgumentException("Visited region bitmap exceeds 1024 chunks");
            var bits=BitSet.valueOf(bytes);if(!bits.isEmpty())PLAYER_ENTERED.put(regionKey(x,z),bits);
        }
    }
    private record Header(long size,FileTime modified,byte[] locations){}
    private static final LinkedHashMap<Path,Header> CACHE=new LinkedHashMap<>(128,0.75f,true){
        @Override protected boolean removeEldestEntry(java.util.Map.Entry<Path,Header> entry){return size()>128;}
    };
    public static synchronized boolean stored(Path regionDir,ChunkPos pos){
        Path file=regionDir.resolve("r."+Math.floorDiv(pos.x(),32)+"."+Math.floorDiv(pos.z(),32)+".mca");
        int index=Math.floorMod(pos.x(),32)+32*Math.floorMod(pos.z(),32);
        try{
            var attrs=Files.readAttributes(file,BasicFileAttributes.class);
            if(!attrs.isRegularFile() || attrs.size()<4096){CACHE.remove(file);return false;}
            var modified=attrs.lastModifiedTime();
            var cached=CACHE.get(file);
            if(cached==null || cached.size()!=attrs.size() || !cached.modified().equals(modified)){
                var header=ByteBuffer.allocate(4096);
                try(var channel=FileChannel.open(file,StandardOpenOption.READ)){
                    while(header.hasRemaining() && channel.read(header)>0){}
                }
                if(header.hasRemaining())return false;
                cached=new Header(attrs.size(),modified,header.array());CACHE.put(file,cached);
            }
            int location=ByteBuffer.wrap(cached.locations()).getInt(4*index);
            int offset=(location>>>8),sectors=location&255;
            return offset>=2 && sectors>0 && cached.size()>=(long)(offset+sectors)*4096;
        }catch(IOException e){CACHE.remove(file);return false;}
    }
}

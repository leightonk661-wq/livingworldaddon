package dev.livingworld;
import com.minecolonies.api.colony.ICitizenData;
import com.minecolonies.api.colony.requestsystem.requestable.IDeliverable;
import com.minecolonies.core.colony.Colony;
import com.minecolonies.core.colony.buildings.modules.WorkerBuildingModule;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.*;

/** Budgeted procurement: real items in loaded citizens' inventories, paid from the town ledger. */
public final class SupplyController {
    private int clock,turn,citizenTurn;
    public void reset(){clock=turn=citizenTurn=0;}
    public void tick(MinecraftServer server,List<Settlement> towns,WorkChunkLoader chunks){
        if(++clock<10 || towns.isEmpty())return;clock=0;
        var s=towns.get(Math.floorMod(turn++,towns.size()));if((!s.colonyReady && !(s.expedition && s.founderSpawned)) || !s.governorEnabled)return;
        try{
            for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(s.dimension)){
                if(level.players().stream().noneMatch(p->p.distanceToSqr(s.x,s.y,s.z)<192*192) && !chunks.activeFor(s))return;
                var c=ColonyBridge.colony(s,level);s.materialMode=true;if(((Colony)c).isFreeMode())((Colony)c).setFreeMode(false);
                ColonyBridge.trainPioneer(s,c);
                // Feed one loaded citizen before materials when their portable food reserve is low.
                var people=c.getCitizenManager().getCitizens();
                if(!people.isEmpty()){
                    var citizen=people.get(Math.floorMod(citizenTurn++,people.size()));
                    if(citizen.getEntity().isPresent() && count(citizen,new ItemStack(Items.BREAD))<2 && s.food>=2){
                        if(deliver(s,citizen,new ItemStack(Items.BREAD),2))return;
                    }
                }
                if(s.starterSites.stream().anyMatch(StarterRules::automatic) || DistantProgress.assembling(s)){s.supplyMessage="Automatic assembly uses its prepaid or starter budget; food still supplied";return;}
                if(!s.colonyReady && s.starterSites.stream().noneMatch(p->p.kind.equals("builder")))return;
                var builder=c.getServerBuildingManager().getBuildings().get(ColonyBridge.builderHut(s));
                if(builder==null){s.supplyMessage="Builder hut missing";return;}
                if(level.getChunkSource().getChunkNow(builder.getPosition().getX()>>4,builder.getPosition().getZ()>>4)==null){s.supplyMessage="Waiting for loaded builder hut";return;}
                if(builder.getAllAssignedCitizen().isEmpty()){
                    var worker=builder.getFirstModuleOccurance(WorkerBuildingModule.class);var candidate=c.getCitizenManager().getJoblessCitizen();
                    if(worker!=null && candidate!=null)worker.assignCitizen(candidate);
                }
                var storage=SettlementStorage.sources(s,builder,level);
                for(var worker:builder.getAllAssignedCitizen()){
                    if(worker.getEntity().isEmpty())continue;
                    var seeds=new ItemStack(Items.WHEAT_SEEDS);
                    if(builder.getOpenRequests(worker.getId()).stream().noneMatch(r->r.getRequest() instanceof IDeliverable d && d.matches(seeds))){
                        int cleared=SettlementStorage.offload(worker,seeds,storage,level);
                        if(cleared>0){s.supplyMessage="Stored "+cleared+" loose seeds from builder inventory";return;}
                    }
                    // A level-zero builder supports wooden tools; provide the toolkit before requests stall.
                    for(var tool:List.of(Items.WOODEN_SHOVEL,Items.WOODEN_PICKAXE,Items.WOODEN_AXE)){
                        if(count(worker,new ItemStack(tool))==0 && (SettlementStorage.supply(s,worker,new ItemStack(tool),1,storage,level) || deliver(s,worker,new ItemStack(tool),1)))return;
                    }
                    if(LivingWorldSettings.current.builderWorksiteSupply && builder instanceof com.minecolonies.core.colony.buildings.AbstractBuildingStructureBuilder structure
                        && BuilderLogistics.prefetch(s,structure,worker,storage,level))return;
                    for(var request:new ArrayList<>(builder.getOpenRequests(worker.getId()))){
                        if(!(request.getRequest() instanceof IDeliverable demand))continue;
                        // A native request can accept a small minimum. Fill a useful portable batch
                        // before confirming it, otherwise the builder returns to the hut repeatedly.
                        ItemStack heldActual=ItemStack.EMPTY;
                        if(request.getState()==com.minecolonies.api.colony.requestsystem.request.RequestState.IN_PROGRESS){
                            var inv=worker.getInventory();
                            for(int slot=0;slot<inv.getSlots();slot++){
                                var actual=inv.getStackInSlot(slot);
                                if(!actual.isEmpty() && demand.matches(actual)){heldActual=actual.copy();break;}
                            }
                            if(!heldActual.isEmpty() && count(worker,heldActual)>=SupplyRules.batchTarget(demand.getCount(),heldActual.getMaxStackSize(),LivingWorldSettings.current.supplyBatchSize)){
                                confirm(c,request,demand,worker,heldActual,s);return;
                            }
                        }
                        var choices=new ArrayList<ItemStack>();
                        if(demand.matches(new ItemStack(Items.BREAD)))choices.add(new ItemStack(Items.BREAD));
                        for(var tool:List.of(Items.WOODEN_PICKAXE,Items.WOODEN_AXE,Items.WOODEN_SHOVEL,Items.WOODEN_HOE,Items.STONE_PICKAXE,Items.STONE_AXE,Items.STONE_SHOVEL,Items.IRON_PICKAXE)){
                            var stack=new ItemStack(tool);if(demand.matches(stack))choices.add(stack);
                        }
                        if(!demand.getResult().isEmpty())choices.add(demand.getResult());
                        choices.addAll(request.getDisplayStacks());
                        boolean supported=false;
                        for(var choice:choices){
                            if(choice.isEmpty() || !demand.matches(choice))continue;
                            String id=BuiltInRegistries.ITEM.getKey(choice.getItem()).toString();
                            int held=count(worker,choice),needed=SupplyRules.batchTarget(demand.getCount(),choice.getMaxStackSize(),LivingWorldSettings.current.supplyBatchSize)-held;
                            if(needed<=0)continue;
                            if(SettlementStorage.supply(s,worker,choice,needed,storage,level))return;
                            if(MaterialCosts.quote(id,1)==null)continue;supported=true;
                            if(deliver(s,worker,choice,needed))return;
                        }
                        if(!heldActual.isEmpty() && request.getState()==com.minecolonies.api.colony.requestsystem.request.RequestState.IN_PROGRESS
                            && confirm(c,request,demand,worker,heldActual,s))return;
                        if(!supported)s.supplyMessage="Manual item needed: "+DashboardData.clip(request.getShortDisplayString().getString());
                    }
                }
                return;
            }
        }catch(Exception e){s.governorEnabled=false;s.supplyMessage="Supply paused: "+DashboardData.clip(e.getMessage());org.slf4j.LoggerFactory.getLogger("livingworld").error("Supply controller stopped for {}",s.name,e);}
    }
    static int count(ICitizenData citizen,ItemStack wanted){
        var inv=citizen.getInventory();int total=0;
        for(int i=0;i<inv.getSlots();i++){var stack=inv.getStackInSlot(i);if(wanted.isDamageableItem()?stack.is(wanted.getItem()):ItemStack.isSameItemSameComponents(stack,wanted))total+=stack.getCount();}return total;
    }
    private static boolean confirm(com.minecolonies.api.colony.IColony colony,com.minecolonies.api.colony.requestsystem.request.IRequest<?> request,IDeliverable demand,ICitizenData worker,ItemStack actual,Settlement s){
        int supplied=SupplyRules.acknowledged(demand.getCount(),demand.getMinimumCount(),count(worker,actual),actual.getMaxStackSize());
        if(supplied==0)return false;
        colony.getRequestManager().overruleRequest(request.getId(),actual.copyWithCount(supplied));
        s.supplyMessage="Confirmed "+supplied+" "+actual.getHoverName().getString()+" in builder inventory";
        return true;
    }
    private static boolean deliver(Settlement s,ICitizenData citizen,ItemStack wanted,int limit){
        var inv=citizen.getInventory();String id=BuiltInRegistries.ITEM.getKey(wanted.getItem()).toString();
        int amount=limit;while(amount>0 && !MaterialCosts.canPay(s,MaterialCosts.quote(id,amount)))amount--;
        if(amount==0){s.supplyMessage="Waiting for supplies to obtain "+id;return false;}
        // Simulate first; pay only for the quantity the real inventory accepted.
        var offer=wanted.copyWithCount(amount);var remaining=offer;
        for(int slot=0;slot<inv.getSlots() && !remaining.isEmpty();slot++)remaining=inv.insertItem(slot,remaining,true);
        int fitting=amount-remaining.getCount();if(fitting==0){s.supplyMessage="Builder inventory full; waiting for space";return false;}
        var charge=MaterialCosts.quote(id,fitting);if(!MaterialCosts.canPay(s,charge))return false;
        remaining=wanted.copyWithCount(fitting);
        for(int slot=0;slot<inv.getSlots() && !remaining.isEmpty();slot++)remaining=inv.insertItem(slot,remaining,false);
        int inserted=fitting-remaining.getCount();if(inserted<=0)return false;
        MaterialCosts.pay(s,MaterialCosts.quote(id,inserted));inv.markDirty();s.deliveredItems+=inserted;
        s.supplyMessage="Delivered "+inserted+" "+DashboardData.friendly(id)+"; spent "+MaterialCosts.describe(MaterialCosts.quote(id,inserted));return true;
    }
}

package dev.livingworld;
import java.util.*;
/** Stable identities and observed relationships, keyed by the native citizen ID. */
public final class CitizenLife {
    public int id;public String uuid="";public String name="",role="Settler",trait="",activity="Settling in";public boolean present=true;
    public Map<Integer,Integer> acquaintances=new LinkedHashMap<>();
    public Map<Integer,Long> metDays=new HashMap<>();
    public Map<String,Integer> visitors=new LinkedHashMap<>();public Map<String,Long> spokeDays=new HashMap<>();
    public void validate(){
        if(uuid==null)uuid="";if(!uuid.isEmpty())UUID.fromString(uuid);
        if(id<=0 || name==null || name.length()>80 || role==null || role.length()>80 || trait==null || trait.length()>32 || activity==null || activity.length()>80
            || acquaintances==null || metDays==null || visitors==null || spokeDays==null || acquaintances.size()>32 || metDays.size()>32 || visitors.size()>32 || spokeDays.size()>32)throw new IllegalArgumentException("Invalid resident memory");
        for(var e:acquaintances.entrySet())if(e.getKey()==null || e.getKey()<=0 || e.getKey()==id || e.getValue()==null || e.getValue()<1 || e.getValue()>100)throw new IllegalArgumentException("Invalid resident acquaintance");
        for(var e:metDays.entrySet())if(e.getKey()==null || e.getKey()<=0 || e.getValue()==null || e.getValue()<0)throw new IllegalArgumentException("Invalid meeting day");
        for(var e:visitors.entrySet())if(e.getKey()==null || e.getKey().length()>64 || e.getValue()==null || e.getValue()<1 || e.getValue()>100)throw new IllegalArgumentException("Invalid visitor memory");
        for(var e:spokeDays.entrySet())if(e.getKey()==null || e.getKey().length()>64 || e.getValue()==null || e.getValue()<0)throw new IllegalArgumentException("Invalid conversation day");
    }
    public boolean meet(CitizenLife other,long day){
        if(other.id==id || day<0 || metDays.getOrDefault(other.id,-1L)>=day || acquaintances.size()>=32 && !acquaintances.containsKey(other.id))return false;
        acquaintances.merge(other.id,1,(a,b)->Math.min(100,a+b));metDays.put(other.id,day);return true;
    }
    public boolean remember(String player,long day){
        if(day<0 || spokeDays.getOrDefault(player,-1L)>=day || visitors.size()>=32 && !visitors.containsKey(player))return false;
        visitors.merge(player,1,(a,b)->Math.min(100,a+b));spokeDays.put(player,day);return true;
    }
    public static String activity(long clock,boolean working,boolean asleep){
        long time=Math.floorMod(clock,24000);if(asleep)return "Resting at home";
        if(working)return "At work";if(time>=13000)return "Resting at home";if(time<2000)return "Morning at the town hall";if(time<9000)return "Walking through town";if(time<12000)return "Meeting the neighbours";return "Heading home";
    }
    public String familiar(Settlement town){return acquaintances.entrySet().stream().filter(e->town.residents.containsKey(e.getKey()) && town.residents.get(e.getKey()).present)
        .max(Map.Entry.<Integer,Integer>comparingByValue().thenComparing(Map.Entry.comparingByKey()))
        .map(e->town.residents.get(e.getKey()).name+(e.getValue()>=3?" (friend)":" (acquaintance)")).orElse("Still getting to know everyone");}
}

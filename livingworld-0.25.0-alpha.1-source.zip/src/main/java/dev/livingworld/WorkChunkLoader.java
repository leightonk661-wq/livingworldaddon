package dev.livingworld;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.storage.LevelResource;
import java.nio.file.Path;
import java.util.*;
/** Fair, bounded two-town rotation over player-visited and saved work chunks. */
public final class WorkChunkLoader {
    public static final class State {
        public int nextTown;
        public long rotationEnd;
        public List<String> assigned=new ArrayList<>();
        public void validate(){
            if(nextTown<0 || rotationEnd<0 || assigned==null || assigned.size()>2 || new HashSet<>(assigned).size()!=assigned.size()
                || assigned.stream().anyMatch(name->name==null || !name.matches("[A-Za-z0-9_-]{1,24}")))
                throw new IllegalArgumentException("Invalid work rotation state");
        }
    }
    private static final TicketType WORK=Registry.register(BuiltInRegistries.TICKET_TYPE,Identifier.parse("livingworld:work"),
        new TicketType(TicketType.NO_TIMEOUT,TicketType.FLAG_LOADING|TicketType.FLAG_SIMULATION|TicketType.FLAG_KEEP_DIMENSION_ACTIVE));
    private record Target(Settlement town,ServerLevel level,int x,int z,String kind,SitePlan site){}
    private static final class Session {
        Target target;Set<ChunkPos> tickets=Set.of();
        Session(Target target){this.target=target;}
    }
    private final LinkedHashMap<Settlement,Session> sessions=new LinkedHashMap<>();
    private final Map<ChunkPos,Integer> ticketReferences=new HashMap<>();
    private long rotationEnd;
    private int nextTown,clock;
    private List<String> resumeNames=List.of();
    private final Map<String,Long> cooldown=new HashMap<>();
    public State snapshot(){
        var state=new State();state.nextTown=Math.max(0,nextTown);state.rotationEnd=rotationEnd;
        state.assigned=new ArrayList<>(sessions.isEmpty()?resumeNames:sessions.keySet().stream().map(s->s.name).toList());return state;
    }
    public String rotationStatus(MinecraftServer server){
        var names=sessions.isEmpty()?resumeNames:sessions.keySet().stream().map(s->s.name).toList();
        if(names.isEmpty())return "No towns currently in the background rotation";
        long remaining=Math.max(0,rotationEnd-server.overworld().getGameTime());
        return "Rotation: "+String.join(" + ",names)+" | "+ticketReferences.size()+" / "+LivingWorldSettings.current.maxWorkChunks+
            " chunks ticketed | "+String.format(java.util.Locale.ROOT,"%.1f",remaining/24000.0)+" Minecraft days until switch";
    }
    public void restore(State state){
        if(state==null)return;state.validate();nextTown=state.nextTown;rotationEnd=state.rotationEnd;resumeNames=List.copyOf(state.assigned);
    }
    private static boolean covered(MinecraftServer server,ServerLevel level,Set<ChunkPos> work){
        return ChunkWorkPlan.covered(work,level.players().stream().map(p->p.chunkPosition()).toList(),
            server.getPlayerList().getSimulationDistance());
    }
    public boolean activeFor(Settlement s){
        var session=sessions.get(s);
        return session!=null && !session.tickets.isEmpty() && session.tickets.stream().allMatch(p->session.target.level.getChunkSource().getChunkNow(p.x(),p.z())!=null);
    }
    public void reset(){releaseAll("Work chunks idle");cooldown.clear();clock=nextTown=0;rotationEnd=0;resumeNames=List.of();}
    public void rotateNow(){releaseAll("Rotation advanced; awaiting next pair");}
    private void releaseTickets(Session session){
        for(var chunk:session.tickets){
            int count=ticketReferences.getOrDefault(chunk,0);
            if(count<=1){ticketReferences.remove(chunk);session.target.level.getChunkSource().removeTicketWithRadius(WORK,chunk,0);}
            else ticketReferences.put(chunk,count-1);
        }
        session.tickets=Set.of();
    }
    private void releaseAll(String message){
        for(var entry:sessions.entrySet()){releaseTickets(entry.getValue());entry.getKey().chunkMessage=message;}
        sessions.clear();ticketReferences.clear();rotationEnd=0;resumeNames=List.of();
    }
    public void tick(MinecraftServer server,List<Settlement> towns,PackGovernor governor,FoundingEngine founding,Runnable checkpoint){
        try{step(server,towns,governor,founding,checkpoint);}catch(Exception e){
            org.slf4j.LoggerFactory.getLogger("livingworld").error("Rotating work chunks failed",e);
            try{releaseAll("Work chunk loading paused: "+DashboardData.clip(e.getMessage()));}catch(Exception ignored){}
        }
    }
    private static boolean eligible(Settlement s){return BackgroundProgress.eligible(s);}
    public boolean matchesTarget(Settlement s,int x,int z){
        var session=sessions.get(s);return session!=null && session.target.x==x && session.target.z==z && session.tickets.contains(new ChunkPos(x>>4,z>>4));
    }
    private static Set<ChunkPos> area(Target target){
        int[] hut=builder(target.town);if(hut==null)return Set.of();
        var cfg=LivingWorldSettings.current;int budget=Math.min(64,cfg.maxWorkChunks/cfg.maxConcurrentWorkTowns);
        return target.site!=null && target.site.width>0?ChunkWorkPlan.siteArea(hut[0],hut[1],target.site,budget):
            ChunkWorkPlan.workArea(hut[0],hut[1],target.x,target.z,!target.kind.equals("town upkeep"),budget);
    }
    private static ServerLevel level(MinecraftServer server,Settlement s){
        for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(s.dimension))return level;
        return null;
    }
    private boolean acquire(MinecraftServer server,Session session,long now){
        var cfg=LivingWorldSettings.current;var target=session.target;var s=target.town;
        if(cooldown.getOrDefault(s.name,0L)>now)return false;
        int[] hut=builder(s);if(hut==null){s.chunkMessage="Builder hut unavailable for background work";return false;}
        var needed=area(target);
        if(needed.isEmpty()){s.chunkMessage="Work area exceeds the per-town chunk budget";cooldown.put(s.name,now+200);return false;}
        if(covered(server,target.level,needed)){s.chunkMessage="Players are simulating this town's work area";return false;}
        var unvisited=needed.stream().filter(chunk->!VisitedChunks.playerEntered(chunk)).toList();
        if(!unvisited.isEmpty()){
            var first=unvisited.getFirst();s.chunkMessage=unvisited.size()+" / "+needed.size()+" work chunks unvisited; enter chunk near "+(first.x()*16+8)+", "+(first.z()*16+8);
            cooldown.put(s.name,now+200);return false;
        }
        Path region=ChunkWorkPlan.overworldRegion(server.getWorldPath(LevelResource.ROOT));
        if(needed.stream().anyMatch(chunk->!VisitedChunks.stored(region,chunk))){s.chunkMessage="Visited work chunks are not saved to disk yet; save the world";cooldown.put(s.name,now+200);return false;}
        long extra=needed.stream().filter(chunk->!ticketReferences.containsKey(chunk)).count();
        if(ticketReferences.size()+extra>cfg.maxWorkChunks){s.chunkMessage="Waiting for the global "+cfg.maxWorkChunks+"-chunk budget";return false;}
        var added=new LinkedHashSet<ChunkPos>();
        try{
            for(var chunk:needed){
                if(!ticketReferences.containsKey(chunk))target.level.getChunkSource().addTicketWithRadius(WORK,chunk,0);
                ticketReferences.merge(chunk,1,Integer::sum);added.add(chunk);
            }
            session.tickets=needed;
            s.chunkMessage="Simulating "+needed.size()+" player-visited chunks for "+target.kind+" (2-town rotation)";
            return true;
        }catch(Exception e){
            session.tickets=added;releaseTickets(session);
            s.chunkMessage="Work chunk load failed: "+DashboardData.clip(e.getMessage());
            cooldown.put(s.name,now+1200);return false;
        }
    }
    private void step(MinecraftServer server,List<Settlement> towns,PackGovernor governor,FoundingEngine founding,Runnable checkpoint){
        if(++clock<20)return;clock=0;
        var cfg=LivingWorldSettings.current;
        if(!cfg.workChunkLoading || !cfg.distantProgression || towns.isEmpty()){
            if(!sessions.isEmpty() || rotationEnd>0){releaseAll("Background work chunks disabled");checkpoint.run();}return;
        }
        long now=server.overworld().getGameTime();
        boolean changed=false;
        if(rotationEnd>0 && now>=rotationEnd){releaseAll("Rotation finished; waiting for next turn");changed=true;}
        if(!resumeNames.isEmpty() && rotationEnd>now){
            for(var name:resumeNames){
                var s=towns.stream().filter(t->t.name.equals(name)).findFirst().orElse(null);
                if(s==null || !eligible(s))continue;
                var level=level(server,s);if(level==null)continue;
                var target=target(s,level,governor,founding);if(target==null)continue;
                var session=new Session(target);
                if(acquire(server,session,now))sessions.put(s,session);
            }
            resumeNames=List.of();changed=true;
        }
        for(var entry:new ArrayList<>(sessions.entrySet())){
            var s=entry.getKey();var session=entry.getValue();
            if(!eligible(s)){
                releaseTickets(session);sessions.remove(s);s.chunkMessage="Background rotation paused for this town";changed=true;continue;
            }
            var next=target(s,session.target.level,governor,founding);
            if(next==null){releaseTickets(session);sessions.remove(s);s.chunkMessage="No background work target";changed=true;continue;}
            if(next.x!=session.target.x || next.z!=session.target.z || !next.kind.equals(session.target.kind) || !session.tickets.isEmpty() && !session.tickets.equals(area(next))){
                releaseTickets(session);
            }
            session.target=next;
            if(!session.tickets.isEmpty() && covered(server,session.target.level,session.tickets)){
                releaseTickets(session);s.chunkMessage="Players are simulating this town's work area";
            }
            if(session.tickets.isEmpty() && !acquire(server,session,now)){
                sessions.remove(s);changed=true;
            }
        }
        if(sessions.isEmpty())rotationEnd=0;
        for(int index:ChunkWorkPlan.rotationOrder(towns.size(),nextTown)){
            if(sessions.size()>=cfg.maxConcurrentWorkTowns)break;
            nextTown=(index+1)%towns.size();
            var s=towns.get(index);
            if(sessions.containsKey(s) || !eligible(s))continue;
            var level=level(server,s);if(level==null)continue;
            var target=target(s,level,governor,founding);if(target==null)continue;
            var session=new Session(target);
            if(acquire(server,session,now)){
                sessions.put(s,session);
                if(rotationEnd==0)rotationEnd=now+cfg.workWindowTicks;
                changed=true;
            }
        }
        if(changed)checkpoint.run();
    }
    private static int[] builder(Settlement s){
        var hut=s.starterSites.stream().filter(p->p.kind.equals("builder") && p.complete).findFirst().orElse(null);
        return hut==null?(s.camp!=null && BackgroundProgress.startersPending(s)?new int[]{s.camp.x,s.camp.z}:null):new int[]{hut.x,hut.z};
    }
    private static Target target(Settlement s,ServerLevel level,PackGovernor governor,FoundingEngine founding){
        if(BackgroundProgress.startersPending(s)){
            var reserved=s.starterSites.stream().filter(p->!p.complete).findFirst().orElse(null);
            if(reserved!=null)return new Target(s,level,reserved.x,reserved.z,"starter "+reserved.kind,reserved);
            var current=founding.workSite(s);
            if(current!=null)return new Target(s,level,current.x,current.z,"starter "+current.kind,current);
            String kind=BackgroundProgress.nextStarter(s);Target fallback=null;
            for(int n=0;n<TerrainRules.SEARCH_SITES;n++){
                var offset=TerrainRules.candidate(s.siteAttempt+n);int x=s.camp.x+offset[0],z=s.camp.z+offset[1];
                if(SurveyMemory.blocked(s,s.expansionPack,kind,x,z,level.getGameTime()))continue;
                var candidate=new Target(s,level,x,z,"starter "+kind,null);if(fallback==null)fallback=candidate;
                var needed=area(candidate);
                if(!needed.isEmpty() && needed.stream().allMatch(VisitedChunks::playerEntered))return candidate;
            }
            return fallback;
        }
        for(var e:s.expansions)if(!e.complete)return new Target(s,level,e.x,e.z,e.kind,e.assembly);
        var project=DistantProgress.ready(s);
        if(project!=null){
            int[] offset=governor.workTarget(s);if(offset!=null)return new Target(s,level,offset[0],offset[1],project.kind,null);
            for(int n=0;n<TerrainRules.SEARCH_SITES+16;n++){
                offset=PackGovernor.candidate(s.siteAttempt+n);
                int x=s.camp.x+offset[0],z=s.camp.z+offset[1];
                if(!SurveyMemory.blocked(s,project.pack,project.kind,x,z,level.getGameTime()))return new Target(s,level,x,z,project.kind,null);
            }
        }
        return s.camp==null?null:new Target(s,level,s.camp.x,s.camp.z,"town upkeep",null);
    }
}

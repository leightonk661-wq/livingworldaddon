package dev.livingworld;
import java.util.*;
public final class StyleRules {
    public static String choose(String biome,Map<String,Integer> wood,Set<String> available) {
        String b=biome.toLowerCase(Locale.ROOT), group="oak";
        if(b.contains("desert") || b.contains("badlands")) group="sandstone";
        else if(b.contains("savanna")) group="acacia";
        else if(b.contains("jungle") || b.contains("bamboo")) group="jungle";
        else if(b.contains("dark_forest")) group="dark";
        else if(b.contains("birch")) group="birch";
        else if(b.contains("taiga") || b.contains("snow") || b.contains("frozen") || b.contains("grove")) group="spruce";
        else if(!wood.isEmpty()) group=wood.entrySet().stream().sorted(Comparator.<Map.Entry<String,Integer>>comparingInt(Map.Entry::getValue).reversed().thenComparing(Map.Entry::getKey)).findFirst().get().getKey();
        List<String> preferred=switch(group) {
            case "sandstone" -> List.of("Desert Oasis","Lost Mesa City");
            case "acacia" -> List.of("Urban Savanna");
            case "jungle" -> List.of("Jungle Treehouse","Incan");
            case "dark" -> List.of("Medieval Dark Oak","Dark Oak Treehouse");
            case "birch" -> List.of("Medieval Birch","Urban Birch");
            case "spruce" -> List.of("Medieval Spruce","Nordic Spruce");
            default -> List.of("Medieval Oak","Minecolonies Original");
        };
        for(var name:preferred) if(available.contains(name)) return name;
        for(var name:List.of("Medieval Oak","Minecolonies Original","Medieval Birch")) if(available.contains(name)) return name;
        return available.stream().sorted().findFirst().orElse("");
    }
    public static String next(int completed) {
        return switch(completed) {case 0,1 -> "residence";case 2 -> "farmer";case 3 -> "warehouse";case 4 -> "deliveryman";default -> "residence";};
    }
}

package dev.livingworld;
import java.util.Locale;
/** Player-facing summaries; raw diagnostic strings stay in the optional details view. */
public final class TownPresentation {
    public static String building(String kind){return switch(kind){case "residence"->"Home";case "farmer"->"Farm";case "deliveryman"->"Courier hut";case "lumberjack"->"Forester's hut";case "miner"->"Mine";case "builder"->"Builder's hut";case "townhall"->"Town hall";case "guardtower"->"Watchtower";default->DashboardData.friendly(kind);};}
    public static String relationship(int rep,boolean allied){return allied?"Trusted ally":rep>=40?"Trusted friend":rep>=20?"Friend of the town":rep>=5?"Known traveller":"New acquaintance";}
    public static String news(String event){
        if(event.startsWith("Settlement stage: "))return "The settlement has become a "+event.substring(18).toLowerCase(Locale.ROOT)+".";
        if(event.startsWith("Funded distant "))return "The council set aside supplies for new construction.";
        if(event.startsWith("Distant project finished: "))return "Plans and supplies are ready for the next building.";
        if(event.startsWith("Reserved "))return "A new building site was chosen.";
        if(event.startsWith("Completed "))return "The "+building(event.substring(10)).toLowerCase(Locale.ROOT)+" is complete.";
        if(event.startsWith("Assigned citizen to "))return "A settler has started work at the "+building(event.substring(20)).toLowerCase(Locale.ROOT)+".";
        if(event.startsWith("Distant project placed: "))return "The "+building(event.substring(24).replace(" complete","")).toLowerCase(Locale.ROOT)+" is complete.";
        if(event.startsWith("Native builder stalled;"))return "The building crew is finding a way to finish an interrupted project.";
        if(event.equals("A migrant reserved a place; arrival pending real housing capacity"))return "A traveller hopes to settle here once a home is ready.";
        if(event.equals("A reserved migrant arrived"))return "A new resident has arrived.";
        if(event.startsWith("Recovery requested:"))return "The builders are trying another approach.";
        return event.replace("Starter builder complete","The builder's hut is ready").replace("Starter townhall complete","The town hall is ready")
            .replace("Distant project placed: ","Completed ").replace("joined MineColonies as the first settler","became the town's first settler");
    }
    private static int percent(SitePlan p){return p.complete?100:(int)Math.min(99,100L*p.cursor/Math.max(1,2L*p.width*p.height*p.depth));}
    public static void apply(DashboardData.Town t,Settlement s){
        t.tier=TownProgress.stage(s);t.nextMilestone=TownProgress.next(s);t.relationship=relationship(t.reputation,t.allied);
        if(!t.enabled){t.headline="Taking a breather";t.summary="The council has paused new development. Resume it from Council when you are ready.";}
        else if(s.food<Economy.reserve(s)){t.headline="The pantry needs attention";t.summary="Food stores are low. Bring bread or speak to the Quest Master about helping.";}
        else if(s.away && t.chunkStatus.toLowerCase(Locale.ROOT).contains("unvisited")){t.headline="New ground to explore";t.summary="The builders need surveyed surroundings. Visit the work area listed in Details before they can build there.";}
        else if(!s.founderSpawned){t.headline="A place to call home";t.summary="Stay nearby while camp takes shape and your pioneer settles in.";}
        else if(BackgroundProgress.startersPending(s)){t.headline="Raising the first rooftops";t.summary="The builder's hut and town hall are taking shape. Once the pioneer has joined camp, explored work areas can progress while you travel.";}
        else if(!t.requests.isEmpty()){t.headline="The builder needs a hand";t.summary="A few supplies are missing. Open Works to see what is needed, or stock the builder's linked chests.";}
        else{t.headline=s.away?"Life carries on":"A growing community";t.summary="Homes, food and useful workplaces come first. The town grows as supplies and working space allow.";}
        t.region=RegionRules.name(s.x,s.z);t.residents.clear();
        for(var person:s.residents.values())if(person.present)t.residents.add(new DashboardData.Resident(person.name,person.role,person.activity,person.trait,person.familiar(s)));
        t.townRelations.clear();for(var relation:s.regionalTrust.entrySet())t.townRelations.add(relation.getKey()+": "+(relation.getValue()>=9?"Familiar neighbours":"Exchanging news"));
        t.projects.clear();
        if(s.camp!=null)t.projects.add(new DashboardData.Project("Supply camp",s.camp.complete?"Established":"Preparing camp",percent(s.camp),s.camp.complete));
        for(var p:s.starterSites)t.projects.add(new DashboardData.Project(building(p.kind),p.complete?"Complete":"Taking shape",percent(p),p.complete));
        for(var e:s.expansions)t.projects.add(new DashboardData.Project(building(e.kind),e.complete?"Complete":e.assembly!=null?"Taking shape":"Builder at work",e.complete?100:e.assembly!=null?percent(e.assembly):-1,e.complete));
        for(var p:s.distantProjects)t.projects.add(new DashboardData.Project(building(p.kind),p.ready()?"Ready for a building site":"Preparing supplies and plans",p.ready()?100:(int)Math.min(99,100L*p.progress/Math.max(1,p.required)),false));
        t.news.clear();for(int i=s.history.size()-1;i>=0 && t.news.size()<8;i--)t.news.add(news(s.history.get(i)));
    }
}

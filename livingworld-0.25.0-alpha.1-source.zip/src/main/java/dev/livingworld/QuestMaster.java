package dev.livingworld;

import com.minecolonies.api.entity.citizen.AbstractEntityCitizen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.List;

/** Reserves a real, jobless MineColonies citizen as a stationary town-hall clerk. */
public final class QuestMaster {
    private int clock=99;
    public void reset(){clock=99;}
    public static SitePlan hall(Settlement town){
        if(!town.expedition || town.starterSites==null)return null;
        return town.starterSites.stream().filter(site->"townhall".equals(site.kind) && site.complete).findFirst().orElse(null);
    }
    public static BlockPos post(Settlement town,ServerLevel level){
        var hall=hall(town);if(hall==null)return null;
        for(int radius=2;radius<=5;radius++)for(int x=hall.minX-radius;x<=hall.minX+hall.width+radius;x++)
            for(int z=hall.minZ-radius;z<=hall.minZ+hall.depth+radius;z++){
                if(x>=hall.minX && x<hall.minX+hall.width && z>=hall.minZ && z<hall.minZ+hall.depth)continue;
                if(x!=hall.minX-radius && x!=hall.minX+hall.width+radius-1 && z!=hall.minZ-radius && z!=hall.minZ+hall.depth+radius-1)continue;
                var chunk=level.getChunkSource().getChunkNow(x>>4,z>>4);if(chunk==null)continue;
                int y=chunk.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,x,z);
                var pos=new BlockPos(x,y,z);
                if(y>=level.getMinY()+1 && y<level.getMaxY()-2 && chunk.getBlockState(pos).isAir() && chunk.getBlockState(pos.above()).isAir()
                    && chunk.getBlockState(pos.below()).isCollisionShapeFullBlock(level,pos.below()))return pos;
            }
        return null;
    }
    public static boolean matches(Settlement town,AbstractEntityCitizen citizen){
        return town.questMasterCitizenId>0 && citizen.getCitizenColonyHandler().getColonyId()==town.colonyId
            && citizen.getCitizenData()!=null && citizen.getCitizenData().getId()==town.questMasterCitizenId;
    }
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save){
        if(++clock<100)return;clock=0;
        for(var town:towns){
            if(!town.colonyReady || hall(town)==null)continue;
            for(var level:server.getAllLevels())if(level.dimension().identifier().toString().equals(town.dimension)){
                var post=post(town,level);if(post==null)break;
                try{
                    var manager=ColonyBridge.colony(town,level).getCitizenManager();
                    var data=town.questMasterCitizenId==0?null:manager.getCivilian(town.questMasterCitizenId);
                    if(data==null || data.getJob()!=null){
                        if(data!=null){var previous=data.getEntity().orElse(null);if(previous!=null){previous.setNoAi(false);previous.setCustomName(null);previous.setCustomNameVisible(false);}}
                        int old=town.questMasterCitizenId;
                        town.questMasterCitizenId=0;
                        if(manager.getCurrentCitizenCount()>1){
                            var spare=manager.getCitizens().stream().filter(c->c.getJob()==null && c.getId()!=old)
                                .max(java.util.Comparator.comparingInt(com.minecolonies.api.colony.ICitizenData::getId)).orElse(null);
                            if(spare!=null){town.questMasterCitizenId=spare.getId();TownProgress.record(town,"Appointed a quest master at the town hall");}
                        }
                        if(town.questMasterCitizenId==0 && manager.getCurrentCitizenCount()==1 && town.food>=16){
                            var newcomer=manager.<com.minecolonies.api.colony.ICitizenData>spawnOrCreateCivilian(null,level,List.of(post),true);
                            if(newcomer!=null){newcomer.setSaturation(20);town.food-=16;town.questMasterCitizenId=newcomer.getId();
                                town.economyPopulation=manager.getCurrentCitizenCount();TownProgress.record(town,"A quest master arrived at the town hall");}
                        }
                        if(old!=town.questMasterCitizenId)save.run();
                        data=town.questMasterCitizenId==0?null:manager.getCivilian(town.questMasterCitizenId);
                    }
                    if(data==null)break;
                    var citizen=data.getEntity().orElse(null);if(citizen==null || !citizen.isAlive())break;
                    citizen.setCustomName(Component.literal(data.getName()+" / Steward"));citizen.setCustomNameVisible(true);
                    citizen.setNoAi(true);
                    if(citizen.distanceToSqr(post.getX()+0.5,post.getY(),post.getZ()+0.5)>9*9)
                        citizen.setPos(post.getX()+0.5,post.getY(),post.getZ()+0.5);
                }catch(Exception e){org.slf4j.LoggerFactory.getLogger("livingworld").warn("Could not maintain quest master at {}",town.name,e);}
                break;
            }
        }
    }
}

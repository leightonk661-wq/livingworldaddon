package dev.livingworld;
public final class TownProgress {
    public static String stage(Settlement s){
        if(!s.expedition)return s.colonyReady?"Established colony":"Simulated settlement";
        if(s.camp==null || !s.camp.complete)return "Expedition";
        if(s.starterSites.size()<2 || s.starterSites.stream().anyMatch(p->!p.complete))return "Outpost";
        if(s.economyPopulation>=32 && Economy.count(s,"residence")>=8 && Economy.count(s,"farmer")>=3 && Economy.count(s,"school")>=1 && Economy.count(s,"university")>=1 && Economy.count(s,"barracks")>=1)return "Capital";
        if(s.economyPopulation>=24 && Economy.count(s,"residence")>=6 && Economy.count(s,"farmer")>=2 && Economy.count(s,"lumberjack")>=1 && Economy.count(s,"miner")>=1 && Economy.count(s,"hospital")>=1 && Economy.count(s,"guardtower")>=1)return "City";
        if(s.economyPopulation>=12 && Economy.count(s,"residence")>=3 && Economy.count(s,"farmer")>=1 && Economy.count(s,"warehouse")>=1 && Economy.count(s,"deliveryman")>=1)return "Town";
        if(s.economyPopulation>=4 && Economy.count(s,"residence")>=2 && Economy.count(s,"farmer")>=1)return "Village";
        return "Hamlet";
    }
    public static String next(Settlement s){return switch(stage(s)){
        case "Expedition"->"Outpost: complete the supply camp";
        case "Outpost"->"Hamlet: complete both automatic starter huts";
        case "Hamlet"->"Village: 4 residents, 2 completed homes and 1 farm";
        case "Village"->"Town: 12 residents, 3 homes, a farm, warehouse and courier hut";
        case "Town"->"City: 24 residents, 6 homes, 2 farms, wood and stone jobs, hospital and guard tower";
        case "City"->"Capital: 32 residents, 8 homes, 3 farms, school, university and barracks";
        case "Capital"->"Maintain food, housing, health and working supplies";
        default->"Maintain food, housing and working supplies";
    };}
    public static void record(Settlement s,String event){
        if(s.history==null)s.history=new java.util.ArrayList<>();
        String text=DashboardData.clip(event);if(!s.history.isEmpty() && s.history.getLast().equals(text))return;
        s.history.add(text);while(s.history.size()>24)s.history.removeFirst();
    }
    public static void update(Settlement s){String stage=stage(s);if(!stage.equals(s.lifecycleStage)){s.lifecycleStage=stage;record(s,"Settlement stage: "+stage);}}
    public static void recover(Settlement s){
        s.nextSurveyTick=0;s.failedSites=0;s.rejectedSites.clear();s.governorEnabled=true;if(s.expedition)s.autoDevelop=true;
        for(var road:s.roads)if(!road.complete){road.issued=false;road.retryAt=0;road.status="Recovery requested; existing orders and terrain will be checked";}
        record(s,"Recovery requested: searches and unfinished work resumed");s.governorMessage="Retrying safely; existing structures and protection checks retained";
    }
}

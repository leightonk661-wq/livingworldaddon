package dev.livingworld;
import com.minecolonies.api.colony.IColony;
import com.minecolonies.core.colony.buildings.modules.WorkerBuildingModule;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import java.util.List;
/** Assign one available citizen to the most essential completed workplace per governor turn. */
public final class ColonyWorkforce {
    private static final List<String> PRIORITY=List.of("farmer","lumberjack","miner","deliveryman","warehouse","hospital","guardtower","school","university","barracks");
    public static boolean assign(Settlement s,IColony colony,ServerLevel level){
        var available=colony.getCitizenManager().getCitizens().stream()
            .filter(c->c.getId()!=s.questMasterCitizenId && c.getJob()==null).findFirst().orElse(null);
        if(available==null)return false;
        for(String kind:PRIORITY)for(var e:s.expansions){
            if(!e.complete || !kind.equals(e.kind))continue;
            var pos=new BlockPos(e.x,e.y,e.z);
            if(level.getChunkSource().getChunkNow(e.x>>4,e.z>>4)==null)continue;
            var building=colony.getServerBuildingManager().getBuildings().get(pos);
            if(building==null || !building.getAllAssignedCitizen().isEmpty())continue;
            var module=building.getFirstModuleOccurance(WorkerBuildingModule.class);
            if(module!=null && module.assignCitizen(available)){
                TownProgress.record(s,"Assigned citizen to "+kind);return true;
            }
        }
        return false;
    }
}

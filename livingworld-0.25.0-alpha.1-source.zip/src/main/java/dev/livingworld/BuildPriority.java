package dev.livingworld;
/** Buildings and survival always outrank optional paving. */
public final class BuildPriority {
    public static String roadDelay(Settlement s){
        if(s.starterSites.stream().anyMatch(p->!p.complete))return "Starter buildings first";
        if(s.expansions.stream().anyMatch(e->!e.complete))return "Finish buildings before roads";
        if(!s.distantProjects.isEmpty())return "Distant building projects first";
        if(Economy.count(s,"residence")==0)return "Build housing before roads";
        if(Economy.count(s,"farmer")==0)return "Build food production before roads";
        if(s.food<Economy.reserve(s)+8)return "Preserve food reserves before paving";
        if(s.expansions.size()<LivingWorldSettings.current.maxExpansions && Economy.next(s)!=null && Economy.affordable(s,Economy.next(s)))return "Next building has priority";
        if(s.stone<80)return "Preserve construction stone before paving";
        return "";
    }
}

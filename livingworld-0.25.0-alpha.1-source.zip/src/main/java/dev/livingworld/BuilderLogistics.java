package dev.livingworld;
import com.minecolonies.api.colony.ICitizenData;
import com.minecolonies.api.inventory.api.IItemHandler;
import com.minecolonies.core.colony.buildings.AbstractBuildingStructureBuilder;
import com.minecolonies.core.colony.buildings.modules.BuildingResourcesModule;
import com.minecolonies.core.entity.ai.workers.AbstractEntityAIStructure;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import java.util.*;
/** Real linked-storage transfers into the builder's portable inventory, never free placement. */
public final class BuilderLogistics {
    public static int portableTarget(int remaining,int maxStack){return Math.min(Math.max(0,remaining),Math.min(64,Math.max(1,maxStack)));}
    public static int prefetchAmount(int remaining,int held,int maxStack,long emptySlots){
        if(held<=0 && emptySlots<=6)return 0;
        return Math.max(0,portableTarget(remaining,maxStack)-Math.max(0,held));
    }
    public static boolean mayResume(boolean managed,boolean workOrder,boolean inventoryFull){return managed && workOrder && !inventoryFull;}
    public static boolean bucketReady(AbstractEntityAIStructure<?,?> ai){
        var worker=ai.getWorker();var building=ai.building;
        if(!building.hasWorkOrder() || LivingWorld.builderTown(worker,building.getPosition())==null)return false;
        var bucket=building.getRequiredResources();var module=building.getFirstModuleOccurance(BuildingResourcesModule.class);
        if(bucket==null || module==null || bucket.getResourceMap().isEmpty() || bucket.getResourceMap().size()>64)return false;
        boolean any=false;
        for(var need:bucket.getResourceMap().entrySet()){
            if(need.getValue()<=0)continue;any=true;
            var resource=module.getResourceFromIdentifier(need.getKey());
            if(resource==null || resource.getItemStack().isEmpty() || SupplyController.count(worker.getCitizenData(),resource.getItemStack())<need.getValue())return false;
        }
        return any;
    }
    public static boolean prefetchAtWorksite(AbstractEntityAIStructure<?,?> ai){
        var worker=ai.getWorker();var town=LivingWorld.builderTown(worker,ai.building.getPosition());
        if(town==null || !(worker.level() instanceof ServerLevel level) || worker.getCitizenData()==null)return false;
        try{return prefetch(town,ai.building,worker.getCitizenData(),SettlementStorage.sources(town,ai.building,level),level);}
        catch(RuntimeException e){
            town.governorEnabled=false;town.supplyMessage="Linked storage supply paused: "+DashboardData.clip(e.getMessage());
            org.slf4j.LoggerFactory.getLogger("livingworld").warn("Builder worksite supply failed for {}",town.name,e);return false;
        }
    }
    public static boolean prefetch(Settlement town,AbstractBuildingStructureBuilder building,ICitizenData worker,List<IItemHandler> storage,ServerLevel level){
        if(!building.hasWorkOrder())return false;
        var module=building.getFirstModuleOccurance(BuildingResourcesModule.class);if(module==null)return false;
        var priorities=new LinkedHashSet<String>();
        if(building.getRequiredResources()!=null)priorities.addAll(building.getRequiredResources().getResourceMap().keySet());
        if(building.getNextBucket()!=null)priorities.addAll(building.getNextBucket().getResourceMap().keySet());
        priorities.addAll(building.getNeededResources().keySet());
        int inspected=0;
        for(String key:priorities){
            if(inspected++>=32)break;
            var resource=building.getNeededResources().get(key);if(resource==null)resource=module.getResourceFromIdentifier(key);
            if(resource==null)continue;ItemStack wanted=resource.getItemStack();if(wanted.isEmpty())continue;
            int held=SupplyController.count(worker,wanted);
            int needed=prefetchAmount(resource.getAmount(),held,wanted.getMaxStackSize(),com.minecolonies.api.util.InventoryUtils.openSlotCount(worker.getInventory()));
            if(needed>0 && SettlementStorage.supply(town,worker,wanted,needed,storage,level))return true;
        }
        return false;
    }
}

package dev.livingworld;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Bounded requests based on real town stocks. No chunk, citizen or inventory access. */
public final class TownQuests {
    private TownQuests() {}
    public static final long COOLDOWN_TICKS=24000;
    public static final int REPUTATION_REWARD=5;

    public static TownQuest offer(Settlement town,long now){
        if(town.quest!=null || now<town.nextQuestTick || !town.expedition
            || !town.colonyReady && (town.camp==null || !town.camp.complete || !town.founderSpawned))return null;
        record Need(String resource,int shortage) {}
        var needs=new ArrayList<Need>();
        int foodTarget=Economy.reserve(town)+64;
        if(town.food<foodTarget && town.food<=496)needs.add(new Need("food",foodTarget-town.food+40));
        if(town.wood<192 && town.wood<=488)needs.add(new Need("wood",192-town.wood));
        if(town.stone<192 && town.stone<=488)needs.add(new Need("stone",192-town.stone));
        if(needs.isEmpty())return null;
        int highest=needs.stream().mapToInt(Need::shortage).max().orElse(0);
        List<Need> eligible=needs.stream().filter(n->n.shortage()>=highest-48).sorted(Comparator.comparing(Need::resource)).toList();
        int pick=Math.floorMod(java.util.Objects.hash(town.name,town.questSerial,now/COOLDOWN_TICKS),eligible.size());
        String resource=eligible.get(pick).resource();
        var q=new TownQuest();q.id=town.name+":"+(++town.questSerial);q.resource=resource;
        q.amount=resource.equals("food")?16:24;q.issuedAt=now;
        String next=Economy.next(town);
        switch(resource){
            case "food" -> {q.title="Rations for "+town.name;q.reason="Our stores are running low. Bring bread so the settlers can keep working and welcoming new people.";}
            case "wood" -> {q.title="Timber for "+town.name;q.reason="The workshops and builder need a stronger timber reserve"+(next==null?".":" before the next "+DashboardData.friendly(next)+".");}
            default -> {q.title="Stone for "+town.name;q.reason="The builders need cobblestone for foundations and repairs"+(next==null?".":" before the next "+DashboardData.friendly(next)+".");}
        }
        town.quest=q;return q;
    }

    public static int acceptableDrop(Settlement town,int available){
        var q=town.quest;
        if(q==null)throw new IllegalArgumentException("This town has no open request.");
        q.validate();
        return Math.max(0,Math.min(available,Math.min(q.amount-q.progress,512-town.stock(q.resource))));
    }

    /** Caller must remove exactly accepted items from the world before applying this change. */
    public static int acceptDrop(Settlement town,String player,int accepted,long now){
        var q=town.quest;
        if(q==null)throw new IllegalArgumentException("This request was already completed.");
        if(accepted<=0 || accepted>acceptableDrop(town,accepted))throw new IllegalArgumentException("Invalid quest delivery quantity");
        town.add(q.resource,accepted);q.progress+=accepted;q.contributions.merge(player,accepted,Integer::sum);
        if(q.progress<q.amount)return 0;
        String recipient=rewardRecipient(q,player);int distributed=0;
        for(var contribution:q.contributions.entrySet()){
            int reputation=REPUTATION_REWARD*contribution.getValue()/q.amount;distributed+=reputation;
            town.reputation.put(contribution.getKey(),Math.min(100,town.relation(contribution.getKey())+reputation));
        }
        town.reputation.put(recipient,Math.min(100,town.relation(recipient)+REPUTATION_REWARD-distributed));
        int coins=town.treasury>0 && town.questRewards.getOrDefault(recipient,0)<4096 && (town.questRewards.containsKey(recipient) || town.questRewards.size()<4096)?1:0;
        town.treasury-=coins;if(coins>0)town.questRewards.merge(recipient,coins,Integer::sum);
        TownProgress.record(town,"A traveller delivered "+q.amount+" "+q.resource+" for the town's request");
        town.quest=null;town.nextQuestTick=now+COOLDOWN_TICKS;
        return coins;
    }
    public static String rewardRecipient(TownQuest quest,String fallback){
        return quest.contributions.entrySet().stream().sorted(java.util.Map.Entry.<String,Integer>comparingByValue().reversed().thenComparing(java.util.Map.Entry.comparingByKey()))
            .map(java.util.Map.Entry::getKey).findFirst().orElse(fallback);
    }

    public static String itemName(String resource){return switch(resource){case "food"->"bread";case "wood"->"oak logs";case "stone"->"cobblestone";default->"items";};}
    public static net.minecraft.world.item.Item item(String resource){return switch(resource){case "food"->net.minecraft.world.item.Items.BREAD;case "wood"->net.minecraft.world.item.Items.OAK_LOG;case "stone"->net.minecraft.world.item.Items.COBBLESTONE;default->throw new IllegalArgumentException("Unknown quest item");};}
}

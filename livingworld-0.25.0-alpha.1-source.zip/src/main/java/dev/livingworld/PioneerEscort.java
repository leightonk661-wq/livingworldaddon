package dev.livingworld;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.Villager;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Keeps one real villager following the founder through loaded terrain; never teleports or loads chunks. */
public final class PioneerEscort {
    public static final String TAG="livingworld.pioneer";
    public static final String MARKER="Living World Pioneer";
    private int clock;
    public void reset(){clock=0;}
    public static boolean isPioneer(Villager v){return v.entityTags().contains(TAG) || v.getCustomName()!=null && MARKER.equals(v.getCustomName().getString());}
    public static void mark(Villager villager){
        if(villager.entityTags().contains(TAG))return;
        villager.addTag(TAG);villager.setPersistenceRequired();
        if(villager.isSleeping())villager.stopSleeping();
        if(villager.level() instanceof ServerLevel level)villager.getBrain().stopAll(level,villager);
        villager.getNavigation().stop();
        var brain=villager.getBrain();
        for(var memory:java.util.List.of(net.minecraft.world.entity.ai.memory.MemoryModuleType.JOB_SITE,net.minecraft.world.entity.ai.memory.MemoryModuleType.POTENTIAL_JOB_SITE,net.minecraft.world.entity.ai.memory.MemoryModuleType.HOME,net.minecraft.world.entity.ai.memory.MemoryModuleType.MEETING_POINT)){
            villager.releasePoi(memory);brain.eraseMemory(memory);
        }
        brain.eraseMemory(net.minecraft.world.entity.ai.memory.MemoryModuleType.WALK_TARGET);
        brain.eraseMemory(net.minecraft.world.entity.ai.memory.MemoryModuleType.LOOK_TARGET);
        brain.eraseMemory(net.minecraft.world.entity.ai.memory.MemoryModuleType.PATH);
        // Keep Humanoid Villagers' generated name. Legacy unnamed villagers retain the old backpack marker.
        if(villager.getCustomName()==null){villager.setCustomName(Component.literal(MARKER));villager.setCustomNameVisible(false);}
    }
    public static void release(Villager villager){
        villager.removeTag(TAG);villager.getNavigation().stop();
        if(villager.getCustomName()!=null && MARKER.equals(villager.getCustomName().getString()))villager.setCustomName(null);
        if(villager.level() instanceof ServerLevel level)villager.refreshBrain(level);
    }
    public static Villager find(ServerLevel level,String uuid){
        if(uuid==null || uuid.isEmpty())return null;
        Entity entity=level.getEntity(UUID.fromString(uuid));
        return entity instanceof Villager villager && villager.isAlive()?villager:null;
    }
    public static boolean nearPlayer(VillageCharter charter,ServerPlayer player,int radius){
        var recruit=find(player.level(),charter.villagerId);
        return recruit!=null && recruit.distanceToSqr(player)<=radius*radius;
    }
    public static boolean arrived(Settlement town,ServerLevel level){
        if(town.recruitId.isEmpty())return true; // Older expeditions and naturally discovered towns.
        if(town.camp==null || !town.camp.complete)return false;
        var recruit=find(level,town.recruitId);
        return recruit!=null && recruit.distanceToSqr(town.camp.x+.5,town.camp.y,town.camp.z+.5)<=12*12;
    }
    public static void capture(Settlement town,Villager recruit){
        var name=recruit.getCustomName();
        if(name!=null && !MARKER.equals(name.getString()))town.pioneerName=name.getString().substring(0,Math.min(64,name.getString().length()));
    }
    public static boolean finish(Settlement town,ServerLevel level){
        if(town.recruitId.isEmpty() || town.journeyComplete)return true;
        if(!town.founderSpawned || town.pioneerCitizenId<=0)return false;
        var recruit=find(level,town.recruitId);
        if(recruit==null)return false;
        var colony=ColonyBridge.colony(town,level);
        var citizen=colony.getCitizenManager().getCivilian(town.pioneerCitizenId);
        var entity=citizen==null?null:citizen.getEntity().orElse(null);
        if(!PioneerHandoff.ready(town,arrived(town,level),entity!=null && entity.isAlive()))return false;
        capture(town,recruit);
        var gender=level.getScoreboard().getObjective("humvil.transform.gender");
        var score=gender==null?null:level.getScoreboard().getPlayerScoreInfo(recruit,gender);
        if(score!=null)citizen.setGender(score.value()==1);
        if(!town.pioneerName.isBlank()){citizen.setName(town.pioneerName);entity.setCustomName(Component.literal(town.pioneerName));}
        citizen.setLastPosition(recruit.blockPosition());citizen.setNextRespawnPosition(recruit.blockPosition());
        citizen.markDirty(0);colony.markDirty();
        entity.setPos(recruit.getX(),recruit.getY(),recruit.getZ());entity.setYRot(recruit.getYRot());
        // Remove the visual proxy only after the real MineColonies citizen exists.
        HumanoidVillagers.removeVisual(recruit,level);recruit.discard();
        town.journeyComplete=true;town.journeyMessage=(town.pioneerName.isBlank()?"Your pioneer":town.pioneerName)+" joined MineColonies as the first settler";
        TownProgress.record(town,town.journeyMessage);return true;
    }
    public void tick(MinecraftServer server,Map<String,VillageCharter> charters,List<Settlement> towns,Runnable save){
        if(++clock<20)return;clock=0;
        for(var player:server.getPlayerList().getPlayers()){
            var charter=charters.get(player.getUUID().toString());
            if(charter!=null && !charter.villagerId.isEmpty()){
                var villager=find(player.level(),charter.villagerId);
                if(villager!=null){mark(villager);charter.lastX=villager.blockPosition().getX();charter.lastZ=villager.blockPosition().getZ();follow(villager,player.blockPosition(),player);}
            }
        }
        for(var town:towns){
            if(town.recruitId.isEmpty() || town.journeyComplete)continue;
            ServerPlayer founder;
            try{founder=server.getPlayerList().getPlayer(UUID.fromString(town.founder));}catch(IllegalArgumentException e){continue;}
            if(founder==null || !founder.level().dimension().identifier().toString().equals(town.dimension))continue;
            if(town.founderSpawned && finish(town,founder.level())){save.run();continue;}
            var villager=find(founder.level(),town.recruitId);
            if(villager==null){town.journeyMessage="Recruit is outside loaded terrain. Return toward "+town.recruitX+", "+town.recruitZ+" and escort them.";continue;}
            mark(villager);town.recruitX=villager.blockPosition().getX();town.recruitZ=villager.blockPosition().getZ();
            BlockPos target=town.camp!=null && town.camp.complete?new BlockPos(town.camp.x,town.camp.y,town.camp.z):founder.blockPosition();
            town.journeyMessage=follow(villager,target,founder)?"Pioneer walking toward "+target.getX()+", "+target.getZ():
                "Pioneer at "+town.recruitX+", "+town.recruitZ+" needs a walkable route or a nearby founder";
        }
    }
    private static boolean follow(Villager villager,BlockPos target,ServerPlayer founder){
        if(villager.distanceToSqr(founder)>64*64 && villager.distanceToSqr(target.getX()+.5,target.getY(),target.getZ()+.5)>32*32)return false;
        if(villager.distanceToSqr(target.getX()+.5,target.getY(),target.getZ()+.5)<3*3){villager.getNavigation().stop();return true;}
        if(villager.isSleeping())villager.stopSleeping();
        double x=target.getX()+.5,z=target.getZ()+.5,y=target.getY();
        double dx=x-villager.getX(),dz=z-villager.getZ(),horizontal=Math.hypot(dx,dz);
        if(horizontal>16){
            x=villager.getX()+dx*16/horizontal;z=villager.getZ()+dz*16/horizontal;
            var chunk=villager.level().getChunkSource().getChunkNow((int)Math.floor(x)>>4,(int)Math.floor(z)>>4);
            if(chunk==null)return false;
            y=chunk.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,(int)Math.floor(x),(int)Math.floor(z))+1;
        }
        villager.getLookControl().setLookAt(x,y+1,z);
        return villager.getNavigation().moveTo(x,y,z,1.2);
    }
}

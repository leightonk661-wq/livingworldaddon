package dev.livingworld;
import com.ldtteam.structurize.blueprints.v1.Blueprint;
import com.ldtteam.structurize.storage.StructurePacks;
import com.ldtteam.structurize.placement.StructurePlacer;
import com.ldtteam.structurize.placement.structure.CreativeStructureHandler;
import com.ldtteam.structurize.api.RotationMirror;
import com.ldtteam.structurize.util.BlockInfo;
import com.minecolonies.api.colony.IColonyManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/** One bounded placement job for bootstrap huts and fully funded distant projects. */
public final class StarterAssembly {
    private Job job;private int clock,turn;private final CampWildlife wildlife=new CampWildlife();
    private static final class Job {
        Expansion expansion;Settlement town;SitePlan site;ServerLevel level;Blueprint bp;StructurePlacer placer;
        CompletableFuture<Blueprint> future;List<String> snapshot=new ArrayList<>();int registered;
    }
    public void reset(){job=null;clock=turn=0;wildlife.reset();}
    public void tick(MinecraftServer server,List<Settlement> towns,Runnable save,WorkChunkLoader chunks){
        try{
            if(job==null){
                if(++clock<20 || towns.isEmpty())return;clock=0;
                var s=towns.get(Math.floorMod(turn++,towns.size()));if(!s.expedition || !s.governorEnabled || s.colonyId==0)return;
                var p=s.starterSites.stream().filter(StarterRules::automatic).findFirst().orElse(null);
                Expansion expansion=null;if(p==null){expansion=s.expansions.stream().filter(e->!e.complete && e.assembly!=null).findFirst().orElse(null);if(expansion!=null)p=expansion.assembly;}if(p==null)return;
                ServerLevel level=null;for(var l:server.getAllLevels())if(l.dimension().identifier().toString().equals(s.dimension)){level=l;break;}if(level==null)return;
                if(level.players().stream().noneMatch(player->player.distanceToSqr(s.x,s.y,s.z)<192*192) && !chunks.activeFor(s))return;
                job=new Job();job.expansion=expansion;job.town=s;job.site=p;job.level=level;job.future=StructurePacks.getBlueprintFuture(p.pack,p.path,level.registryAccess());
            }
            work(save,chunks);
        }catch(Exception e){
            if(job!=null){job.town.governorEnabled=false;job.town.autoDevelop=false;job.town.governorMessage="Automatic assembly paused: "+DashboardData.clip(e.getMessage());}
            org.slf4j.LoggerFactory.getLogger("livingworld").error("Automatic assembly stopped",e);job=null;save.run();
        }
    }
    private void work(Runnable save,WorkChunkLoader chunks){
        var j=job;var s=j.town;var p=j.site;var level=j.level;
        if(!s.governorEnabled || p.complete || (j.expansion==null && !StarterRules.automatic(p))){job=null;return;}
        if(level.players().stream().noneMatch(player->player.distanceToSqr(s.x,s.y,s.z)<192*192) && !chunks.activeFor(s)){s.governorMessage="Automatic assembly waiting for a nearby player";job=null;return;}
        for(int x=(p.minX-16)>>4;x<=(p.minX+p.width+16)>>4;x++)for(int z=(p.minZ-16)>>4;z<=(p.minZ+p.depth+16)>>4;z++)
            if(level.getChunkSource().getChunkNow(x,z)==null){s.governorMessage="Automatic assembly waiting for loaded chunks";job=null;return;}
        var colony=ColonyBridge.colony(s,level);
        if(!j.future.isDone())return;
        var blueprint=j.future.join();if(blueprint==null)throw new IllegalArgumentException("Assembly blueprint unavailable");
        if(p.width!=blueprint.getSizeX() || p.depth!=blueprint.getSizeZ() || p.height!=blueprint.getSizeY())throw new IllegalArgumentException("Reserved blueprint dimensions changed");
        if(j.expansion!=null)AssemblyRegistration.ensure(s,j.expansion,level,blueprint,colony,save);
        var building=colony.getServerBuildingManager().getBuildings().get(ColonyBridge.sitePos(p));
        if(building==null){s.governorMessage="Waiting for hut registration; missing existing huts are protected";job=null;return;}
        if(building.isBuilt() && building.getBuildingLevel()>=1){if(j.expansion!=null)j.expansion.complete=true;p.complete=true;p.before.clear();save.run();job=null;return;}
        if(j.bp==null){
            j.bp=blueprint;
            for(var order:new ArrayList<>(colony.getWorkManager().getWorkOrders().values()))if(order.getLocation().equals(ColonyBridge.sitePos(p)))colony.getWorkManager().removeWorkOrder(order);
            j.placer=new StructurePlacer(new CreativeStructureHandler(level,ColonyBridge.sitePos(p),j.bp,RotationMirror.NONE,false)){
                @Override public com.ldtteam.structurize.placement.BlockPlacementResult handleEntitySpawn(net.minecraft.world.level.Level world,BlockPos pos,BlockPos local,com.ldtteam.structurize.util.ChangeStorage storage,boolean check){return new com.ldtteam.structurize.placement.BlockPlacementResult(pos,com.ldtteam.structurize.placement.BlockPlacementResult.Result.SUCCESS);}
            };
        }
        int volume=p.width*p.height*p.depth;
        if(p.before.isEmpty()){
            for(int n=0;n<128 && j.snapshot.size()<volume;n++){
                int index=j.snapshot.size();var local=local(p,index);var pos=new BlockPos(p.minX,p.minY,p.minZ).offset(local);
                var current=level.getBlockState(pos);var desired=desired(j,local);
                checkClaim(j,pos);
                if(!current.is(desired.getBlock()) && (!FoundingEngine.natural(current)||level.getBlockEntity(pos)!=null))throw new IllegalArgumentException("Existing block protected at "+pos.toShortString());
                j.snapshot.add(current.toString());
            }
            s.governorMessage="Checking automatic "+p.kind+" footprint: "+j.snapshot.size()+" / "+volume;
            if(j.snapshot.size()<volume)return;
            p.before.addAll(j.snapshot);p.autoAssembly=true;save.run();return;
        }
        if(p.before.size()!=volume)throw new IllegalArgumentException("Incomplete starter protection journal");
        if(level.players().stream().anyMatch(player->CampSafety.nearFootprint(player.getX(),player.getZ(),p,3))){s.governorMessage="Automatic "+p.kind+" paused: stand beyond its three-block safety buffer";job=null;return;}
        int checked=0,placed=0;
        while(p.cursor<volume*2 && checked++<128 && placed<LivingWorldSettings.current.starterBlocksPerTick){
            int index=p.cursor%volume;var local=local(p,index);var pos=new BlockPos(p.minX,p.minY,p.minZ).offset(local);
            var original=j.bp.getBlockState(local);String id=BuiltInRegistries.BLOCK.getKey(original.getBlock()).toString();
            if(id.equals("structurize:blocksubstitution")){p.cursor++;continue;}
            var desired=desired(j,local);var current=level.getBlockState(pos);
            // Keep the registered hut and existing matching blocks/containers, including their inventories.
            if(current.is(desired.getBlock())){p.cursor++;continue;}
            checkClaim(j,pos);
            if(level.getBlockEntity(pos)!=null || (!current.toString().equals(p.before.get(index)) && !CampTerrain.sameSurfaceSoil(p.before.get(index),current.toString()) && !FoundingEngine.soft(current)))throw new IllegalArgumentException("Changed block protected at "+pos.toShortString());
            var blockers=level.getEntities((net.minecraft.world.entity.Entity)null,new net.minecraft.world.phys.AABB(pos).expandTowards(0,1,0),ConstructionSafety::blocksWork);
            if(!blockers.isEmpty() && (!desired.isAir() || !FoundingEngine.soft(current))){
                wildlife.guide(level,p,blockers.getFirst());
                var builder=colony.getServerBuildingManager().getBuildings().get(ColonyBridge.builderHut(s));var exit=ColonyBridge.spawnAtCamp(s,level);
                if(builder!=null && exit!=null)for(var citizen:builder.getAllAssignedCitizen())citizen.getEntity().ifPresent(entity->{if(blockers.contains(entity))entity.getNavigation().moveTo(exit.getX()+.5,exit.getY(),exit.getZ()+.5,1.1);});
                s.governorMessage="Automatic "+p.kind+" waiting for "+blockers.getFirst().getName().getString()+" at "+pos.toShortString();job=null;return;
            }
            var info=id.equals("structurize:blocksolidsubstitution")?new BlockInfo(local,desired,null):j.bp.getBlockInfoAsMap().get(local);
            if(info==null){p.cursor++;continue;}
            var result=j.placer.handleBlockPlacement(level,pos,null,info).getResult();
            if(p.cursor>=volume && (result==com.ldtteam.structurize.placement.BlockPlacementResult.Result.FAIL || result==com.ldtteam.structurize.placement.BlockPlacementResult.Result.BREAK_BLOCK))throw new IllegalArgumentException("Could not place starter block at "+pos.toShortString());
            p.cursor++;placed++;
        }
        s.governorMessage="Automatically assembling "+p.kind+": "+(100L*p.cursor/(volume*2))+"%";
        if(p.cursor<volume*2)return;
        for(int n=0;n<128 && j.registered<volume;n++,j.registered++){
            var pos=new BlockPos(p.minX,p.minY,p.minZ).offset(local(p,j.registered));building.registerBlockPosition(level.getBlockState(pos),pos,level);
        }
        if(j.registered<volume)return;
        building.setBuildingLevel(1);building.onUpgradeComplete(j.bp,1);building.markDirty();
        var tile=building.getTileEntity();if(tile!=null)tile.setSchematicName(p.kind+"1");
        p.complete=true;if(j.expansion!=null)j.expansion.complete=true;p.before.clear();s.governorMessage=(j.expansion==null?"Starter ":"Distant project placed: ")+p.kind+" complete";TownProgress.record(s,s.governorMessage);save.run();job=null;
    }
    private static BlockPos local(SitePlan p,int index){return new BlockPos(index%p.width,index/(p.width*p.depth),(index/p.width)%p.depth);}
    private static BlockState desired(Job j,BlockPos local){var state=j.bp.getBlockState(local);return BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString().equals("structurize:blocksolidsubstitution")?Blocks.COBBLESTONE.defaultBlockState():state;}
    private static void checkClaim(Job j,BlockPos pos){var claim=IColonyManager.getInstance().getColonyByPosFromDim(j.level.dimension(),pos);if(claim==null || claim.getID()!=j.town.colonyId)throw new IllegalArgumentException("Starter footprint is no longer in this colony");}
}

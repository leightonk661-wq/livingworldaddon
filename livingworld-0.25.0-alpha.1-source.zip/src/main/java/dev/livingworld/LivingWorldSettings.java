package dev.livingworld;
import com.google.gson.GsonBuilder;
import java.nio.file.*;
public final class LivingWorldSettings {
    public static LivingWorldSettings current=new LivingWorldSettings();
    public int campBlocksPerTick=4,starterBlocksPerTick=8,surveyCellsPerTick=128,surveyIntervalTicks=5,supplyBatchSize=32;
    public boolean distantProgression=true;
    public boolean builderWorksiteSupply=true;
    public int maxExpansions=24,distantQueueLimit=8,distantProjectCycles=40,maxAutomaticSettlements=8;
    public boolean workChunkLoading=true;
    public int maxWorkChunks=96,maxConcurrentWorkTowns=2,workWindowTicks=48000;
    public void validate(){
        maxExpansions=bound(maxExpansions,12,48);distantQueueLimit=bound(distantQueueLimit,1,16);distantProjectCycles=bound(distantProjectCycles,2,240);
        maxAutomaticSettlements=bound(maxAutomaticSettlements,0,16);
        maxConcurrentWorkTowns=bound(maxConcurrentWorkTowns,1,2);
        // A normal construction corridor needs up to 48 chunks per active town.
        maxWorkChunks=bound(maxWorkChunks,48*maxConcurrentWorkTowns,128);
        workWindowTicks=bound(workWindowTicks,48000,120000);
        campBlocksPerTick=bound(campBlocksPerTick,1,16);starterBlocksPerTick=bound(starterBlocksPerTick,1,32);
        surveyCellsPerTick=bound(surveyCellsPerTick,32,256);surveyIntervalTicks=bound(surveyIntervalTicks,1,40);supplyBatchSize=bound(supplyBatchSize,8,64);
    }
    private static int bound(int value,int min,int max){return Math.max(min,Math.min(max,value));}
    public static void load(){
        var file=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("livingworld.json");var gson=new GsonBuilder().setPrettyPrinting().create();
        try{
            if(Files.exists(file)){
                String json=Files.readString(file);var settings=gson.fromJson(json,LivingWorldSettings.class);
                if(settings==null)throw new IllegalArgumentException("Empty settings");
                if(!com.google.gson.JsonParser.parseString(json).getAsJsonObject().has("maxConcurrentWorkTowns"))
                    settings.maxWorkChunks=Math.max(settings.maxWorkChunks,96);
                settings.validate();current=settings;
            }
            else{current=new LivingWorldSettings();Files.createDirectories(file.getParent());Files.writeString(file,gson.toJson(current));}
        }catch(Exception e){current=new LivingWorldSettings();org.slf4j.LoggerFactory.getLogger("livingworld").warn("Using default Living World settings; config left untouched",e);}
    }
}

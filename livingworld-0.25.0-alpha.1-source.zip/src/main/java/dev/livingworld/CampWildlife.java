package dev.livingworld;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.*;

/** Ask ordinary wildlife to walk out of the construction area. Never teleports or removes entities. */
public final class CampWildlife {
    private final Map<UUID,Long> nextAttempt=new HashMap<>();
    public void reset(){nextAttempt.clear();}
    public boolean guide(ServerLevel level,SitePlan camp,Entity entity){
        if(!(entity instanceof Animal animal) || animal.hasCustomName() || animal.isLeashed() || animal.isPassenger() || animal.isVehicle()
            || (animal instanceof TamableAnimal tame && tame.isTame()))return false;
        long now=level.getGameTime();
        if(nextAttempt.getOrDefault(animal.getUUID(),0L)>now)return !animal.getNavigation().isDone();
        nextAttempt.entrySet().removeIf(e->e.getValue()<=now);nextAttempt.put(animal.getUUID(),now+60);
        int mx=camp.minX+camp.width/2,mz=camp.minZ+camp.depth/2;
        var candidates=new ArrayList<int[]>();
        for(var p:new int[][]{{camp.minX-5,mz},{camp.minX+camp.width+4,mz},{mx,camp.minZ-5},{mx,camp.minZ+camp.depth+4},
            {camp.minX-5,camp.minZ-5},{camp.minX-5,camp.minZ+camp.depth+4},{camp.minX+camp.width+4,camp.minZ-5},{camp.minX+camp.width+4,camp.minZ+camp.depth+4}})candidates.add(p);
        candidates.sort(Comparator.comparingDouble(p->animal.distanceToSqr(p[0],animal.getY(),p[1])));
        int paths=0;
        for(var p:candidates){
            var chunk=level.getChunkSource().getChunkNow(p[0]>>4,p[1]>>4);if(chunk==null)continue;
            int y=chunk.getHeight(Heightmap.Types.WORLD_SURFACE,p[0],p[1]);
            for(int n=0;n<4 && FoundingEngine.soft(chunk.getBlockState(new BlockPos(p[0],y,p[1])));n++)y--;
            var pos=new BlockPos(p[0],y,p[1]);var floor=chunk.getBlockState(pos);
            if(!FoundingEngine.natural(floor) || FoundingEngine.soft(floor) || !floor.getFluidState().isEmpty() || chunk.getBlockEntity(pos)!=null
                || !FoundingEngine.soft(chunk.getBlockState(pos.above())) || !FoundingEngine.soft(chunk.getBlockState(pos.above(2))))continue;
            if(animal.getNavigation().moveTo(p[0]+.5,y+1,p[1]+.5,1.1))return true;
            if(++paths>=2)break;
        }
        return false;
    }
}

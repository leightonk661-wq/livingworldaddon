package dev.livingworld;
import java.util.*;

/** Bounded cut-and-fill for the initial camp only. Coordinates are relative horizontally, absolute vertically. */
public final class CampTerrain {
    public static final int MAX_RELIEF=6,MAX_CUT=3,MAX_FILL=3;
    public static boolean sameSurfaceSoil(String before,String after){
        return surfaceSoil(before) && surfaceSoil(after);
    }
    private static boolean surfaceSoil(String state){
        return "Block{minecraft:dirt}".equals(state) || (state!=null && (state.equals("Block{minecraft:grass_block}[snowy=false]") || state.equals("Block{minecraft:grass_block}[snowy=true]")));
    }
    public record Cell(int x,int y,int z,boolean fill) {}
    public static int elevation(int[] heights){
        if(heights.length==0)throw new IllegalArgumentException("Empty terrain survey");
        int[] sorted=heights.clone();Arrays.sort(sorted);
        int low=sorted[0],high=sorted[sorted.length-1];
        if(high-low>MAX_RELIEF)throw new IllegalArgumentException("Camp slope exceeds six blocks");
        return Math.max(high-MAX_CUT,Math.min(low+MAX_FILL,sorted[sorted.length/2]));
    }
    public static List<Cell> plan(int[] heights,int width,int depth,int elevation){
        if(width<1 || width>48 || depth<1 || depth>48 || heights.length!=width*depth)throw new IllegalArgumentException("Invalid camp area");
        var cells=new ArrayList<Cell>();
        for(int i=0;i<heights.length;i++){
            int ground=heights[i];if(ground-elevation>MAX_CUT || elevation-ground>MAX_FILL)throw new IllegalArgumentException("Earthwork depth exceeded");
            for(int y=ground+1;y<=elevation;y++)cells.add(new Cell(i%width,y,i/width,true));
            // Cut downwards so gravel and sand above the excavation do not fall into unfinished work.
            for(int y=Math.max(ground+2,elevation+2);y>elevation;y--)cells.add(new Cell(i%width,y,i/width,false));
        }
        return cells;
    }
    public static final class Change {
        public int x,y,z;public boolean fill;public String before;
        public Change(int x,int y,int z,boolean fill,String before){this.x=x;this.y=y;this.z=z;this.fill=fill;this.before=before;}
    }
}
